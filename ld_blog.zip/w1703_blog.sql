-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2018-01-10 07:51:54
-- 服务器版本： 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `w1703_blog`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `aname` varchar(255) DEFAULT NULL,
  `apass` varchar(255) DEFAULT NULL,
  `level` tinyint(2) DEFAULT NULL,
  `atime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`aid`, `aname`, `apass`, `level`, `atime`) VALUES
(1, 'zhangsan', 'e10adc3949ba59abbe56e057f20f883e', 1, '2017-10-30 06:02:54'),
(5, '李四', 'e10adc3949ba59abbe56e057f20f883e', 1, '2017-10-30 06:57:21'),
(7, 'lisizz0.0', 'e10adc3949ba59abbe56e057f20f883e', 29, '2017-10-30 13:38:51'),
(11, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 1, '2017-11-02 07:05:49'),
(12, 'abc', 'e10adc3949ba59abbe56e057f20f883e', 31, '2017-11-02 08:03:30');

-- --------------------------------------------------------

--
-- 表的结构 `buy`
--

CREATE TABLE `buy` (
  `buyid` int(11) NOT NULL,
  `conid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `buydate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `car`
--

CREATE TABLE `car` (
  `carid` int(11) NOT NULL,
  `conid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL COMMENT '1-购物车 2-订单',
  `cardate` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE `category` (
  `cid` int(11) NOT NULL,
  `cname` varchar(50) DEFAULT NULL,
  `cimage` varchar(255) DEFAULT NULL,
  `cinfo` varchar(255) DEFAULT NULL,
  `pid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `category`
--

INSERT INTO `category` (`cid`, `cname`, `cimage`, `cinfo`, `pid`) VALUES
(1, '新上榜', 'upload/17-11-13/1510540049542zzt3.png', '新上榜', 0),
(5, '7日热门', 'upload/17-11-13/1510539930517zzt.png', '7日热门', 0),
(24, '30日热门', 'upload/17-11-13/1510540004848zzt2.png', '30日热门', 0),
(25, '出版新品', 'upload/17-11-13/1510539876552zzt1.png', '出版新品', 0),
(26, '年热销榜', 'upload/17-11-13/1510539820544zzt4.png', '年热销榜', 0),
(33, 'banner', NULL, '网站顶部banner', 0);

-- --------------------------------------------------------

--
-- 表的结构 `con`
--

CREATE TABLE `con` (
  `cid` int(11) NOT NULL,
  `ctitle` varchar(255) DEFAULT NULL,
  `ccon` varchar(2000) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `cquanxian` int(11) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `cateid` int(255) DEFAULT NULL COMMENT '所属分类',
  `condate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `price` int(11) DEFAULT NULL,
  `state` tinyint(2) NOT NULL COMMENT '1.保存2.审核3.发布4.禁用',
  `posid` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `con`
--

INSERT INTO `con` (`cid`, `ctitle`, `ccon`, `uid`, `cquanxian`, `thumb`, `cateid`, `condate`, `price`, `state`, `posid`) VALUES
(11, '上南宁分别是达芙妮', '<p>其实最近挺忙的，没怎么“充电”，所以不太敢提笔写文。白天忙得焦头烂额，晚上就不太想做太耗神的事情，只想安安静静地看小会儿书，或记小会儿单词什么的。 有时候会坐在来回的地</p>', 1, 1, 'upload/17-11-12/1510452449934banner.jpeg', 1, '2017-11-12 02:04:51', 5, 3, '1,4'),
(10, '阳光总在风雨后，愿你可以风雨兼程的前行', '<p>去年日本留学生江歌被杀事件再次发酵。江歌的母亲于今年11月11日、12日，在东京进行签名活动，并且发布网页上申书征集签名，要求日本法院判处凶手死刑。 我不同意签字的原因是，上</p>', 6, 1, 'upload/17-11-12/1510452449934banner.jpeg', 1, '2017-11-11 03:57:24', 2000, 3, '2,3'),
(3, '我知道你永远都不会知道', '<p>今年的北京下雪天格外多，11月就下了两场大雪。纷纷扬扬的，恣意狂妄。白雪覆盖了万物，天地瞬间变得素净晶莹。本以为还会多下一会儿，没想到地面上只是轻微打湿，像是从来没有下过雪一样。这个是你的雨伞吧，别再弄丢了。”我抬起头，正好看见一双清澈明亮的眸子。收银员提醒我，我忙应声道歉。曾经这个场景多么相似，忽然脑海里掠过一抹身影。</p><p>这个世界上大概爱情是最没有道理的吧，一个眼神，一句问候，一个笑容就让人沉沦，思绪千回百折还是与那个人有关。</p><p>有多少想说却没有说出口的话，有多少想做却没有做的事。那些唏嘘不已的憾事，那些隐昧暗晦的情愫，本以为早已消亡岁月中，猝然发现痕迹，依然能掀起波澜，卷起风浪。原来沉寂。</p>', 1, 3, 'upload/17-11-18/1510975871955img3.png', 24, '2017-11-11 01:05:36', 2, 3, '1,4,8'),
(12, '“章娘娘威武”的赞誉。 但Sir还是想说', '<p>我是一名程序员，在北京打工两个月，如今身上只剩吃碗面条的钱。昨夜在北京寒冷的公园和同事与流浪汉一起露宿一夜，因为我们被老板拖欠了工资。 我是今年七月毕业的应届生。因为上一个公</p>', 1, 1, 'upload/17-11-12/1510452314897a.jpg', 24, '2017-11-12 02:05:19', 20, 3, '1'),
(13, '为什么一定要去好学校？这个孩子把话挑明', '<p>哪有那么多说走就走的旅行，你羡慕的一切只不过是别人的有备而来的假象罢了。 向往旅行，也羡慕远方，可是最起码你得先学会出发啊。 旅行不是去遭罪，而是更好的活着。 我初次去西藏的啦啦啦拉拉啦啦啦</p><p>小溪属于第一种，她很漂亮，但是特立独行，单身主义；大白则是因为胖——1.60不到，65公斤。</p><p>大学的爱情很纯洁，大多不在意家庭背景、门当户对；大学的爱情很俗，俗到只看身高、体重、外貌。</p><p>除了胖，大白是个不错的女同学：成绩好，家庭条件好，性格开朗活泼，长相也不错，皮肤特别白。<br/></p><p>大白一直有追求者，刚刚又拒绝了两个：又瘦又小的小宇，又高又胖的蓝维。</p><p>“真是一对反义词啊！”大白跟小溪抱怨。她俩是高中同学，现在又是舍友加剩女，形影不离。</p>', 1, 1, 'upload/17-11-12/1510452314897a.jpg', 24, '2017-11-12 02:05:31', 6, 3, '2,6,8'),
(14, '别在最该增值的二十几岁，消耗自己', '<p>这句话出自我最喜欢的书籍《牧羊少年奇幻之旅》中。每每读到这句话，都觉得有某种独特的魔力，就好像是真的只要足够虔诚，所有的向往都会成真的。</p><p>以往谈过很多关于&quot;努力&quot;之类的话题，一直以来都觉得努力是一个很虚的概念，很鸡汤，不过也一如既往地坚信努力是一切瓜熟蒂落的前提。</p><p>不过现在的我，好像不是这样了。至少许久不见的朋友，说我越来越真实，越来越像自己了。</p><p>听到这样的话，虽然嘴里和他不停争辩着过去的种种，不过心里却在偷着乐。</p><p>以前花了很长的时间，也喊了很久的口号，说要做自己，可最后终究是迫于压力活得乖巧又胆小，而现在，在不知不觉中，却形成了自己鲜明而独特的个性。</p>', 1, 1, 'upload/17-11-18/1510969845151a.jpeg', 5, '2017-11-12 02:05:51', 6, 4, '2,3,4,8'),
(18, '成为一名数据分析师', '<p>是否会编程是区别初级数据分析师和高级数据分析师的分水岭。在这里，我定位的是高级数据分析师，所以编程能力尤为重要，我把它放在了第一位。有关数据分析的编程语言有Python和R语言。R语言倾向于统计分析、绘图等。统计学家或者学统计学的喜欢用R语言，而我推荐学习Python，因为Python是面向未来的语言，无论从流行度、可用性还是学习难度来讲，Python都是最好的入门语言。</p><pre><p>1：SQLite 是一个文件型轻量级数据库，它的处理速度很快，在数据量不是很大的情况下，可以使用SQLite。</p></pre><p>1：SQLite 是一个文件型轻量级数据库，它的处理速度很快，在数据量不是很大的情况下，可以使用SQLite。</p><p>2：MySQL 是一个应用极其广泛的关系型数据库，它是开源免费的，可以支持大型数据库，很多中小型企业都是用的MySQL。</p><p>3：MongoDB 是一个面向文档的非关系型数据库，它功能强大、灵活、易于拓展。</p><p>4：Redis 是一个使用ANSI C 编写的高性能key-value数据库，使用内存作为主存储器。</p>', 1, 1, 'upload/17-11-18/1510974880649zzt2.png', 25, '2017-11-12 02:07:16', 20, 2, '2,6,7,8'),
(19, '你没有变强，是因为你过得太舒服了', '<p>人生有很多种可能，我们每个人也在经历不一样的故事，不过啊，你得到的所有东西，上帝早已在暗中标好了价钱。当你刚开始学习一门新技术时，最开始的学习阶段，难度最大，因为你什么都不会，全新的接触，你会觉得很不舒服，但当你渐渐掌握的这门技术的时候，你就会觉得越来越简单。</p><p>现在的你，可能是二十岁，三十岁，四十岁......</p><p>你可能站在人群里，闪闪发光，对着梦想和未来策马扬鞭；</p><p>你可能被生活的重担磨去了棱角，却会在某个瞬间看见妻子的侧脸温柔地笑起来；</p><p>你可能在一条黢黑的路上，踩着荆棘往前走，心中依旧藏着小小的渴望；</p><p>无论你在哪里，无论你在做什么，我希望你都是清醒的，你都仍在努力着。</p>', 1, 1, 'upload/17-11-12/1510452449934banner.jpeg', 25, '2017-11-12 02:07:40', 9, 2, '1,2,3,4,7'),
(22, '做开发十年，我总结出了这些开发经验', '<p>行军打仗，你需要一个向导；如果没有向导，你需要一个地图；如果没有地图，至少要学习李广，找一匹识途的老马；如果你连老马也没有，那最好可以三个臭皮匠好好讨论，力图胜过一个诸葛亮；如果三个臭皮匠连好好讨论也做不到，那就是典型的乌合之众了，最好写代码前，点上三炷香，斟上一杯浊酒，先拜拜菩萨，再拜拜谷歌。</p><p><br/></p>', 14, 1, 'upload/17-11-14/1510623852425zzt2.png', 5, '2017-11-14 01:44:24', 20, 3, '1,4'),
(23, '情商是什么', '<p>高情商者善于控制自己的情绪，大部分时候都能做到头脑冷静，行为理智，抑制感情的冲动，克制急切的欲望，及时化解和排除自己的不良情绪，使自己始终保持良好的心境，心情开朗，胸怀豁达，心理健康</p>', 14, 1, 'upload/17-11-14/1510624028630zzt1.png', 5, '2017-11-14 01:47:12', 2, 3, '1,8'),
(24, '思念到极致是什么感觉？', '<p>殊不知，若干年后自己很有可能变成被诅咒的老婆婆或者干预孩子婚姻那个老太太了！</p>', 14, 1, 'upload/17-11-14/1510624156540zzt4.png', 26, '2017-11-14 01:49:21', 2, 3, '1'),
(25, '在奋斗与迷茫的漩涡中挣扎', '<p>几年前媒体还在说着我们90后是垮掉的一代，但是现在一转眼，90后都已经是奔三的叔叔阿姨，成了00后眼中鄙视链的一部分了。很多90后现在已经是职场上的大咖了，优秀又有创意，分分钟出现在各大公众号的头条上，成为《月入10万的90后，我是如何做到的？》《你还在打游戏，你同学都身家上亿了》这类文章的主角。</p><p>我有时挺不理解的，我们读书的时候这些人骂我们是扶不起来的一代；我们刚步入职场，连买房的首付都还没凑齐的时候，这些人又开始写这种成功学文章来鞭策我们。</p><p>90后确实是很任性的一代人，不服输不服老，充满活力与人友善；但我们同样也是压力最大的一代人，我们没有80后他们那么多的兄弟姐妹来一起养老，家里有事需要一人扛；我们面对着暴涨到疯狂的房价，拿着微薄的薪水还要饱受各种自媒体账号的嘲讽，你买不起房子你活该......</p>', 17, 1, 'upload/17-11-20/1511146568138dt1.jpg', 33, '2017-11-20 02:56:22', 33, 2, '4,7,8'),
(26, '你还在原地徘徊等待', '<p>我儿时的一位伙伴，和我同一所小学，一个初中，高中时，他考上了重点高中的理科实验班，而我则直接升入了本校的高中部。顺理成章的是，他考上了985，而我上了专科。</p><p>前几天，我们聊了天，他目前在美国读博士，还有一年毕业回国。</p><p>我问了他一些在美国的情况，他和我说：“从大学开始，才知道应试教育下的我们有多悲凉。大学四年，我为了出国准备了很多，那年去美国做交换生，我更加坚定了自己出国生造的决心。你也知道，我的家境，所以，我只能不停地努力，争取到了公费留学的机会。”</p><p>他在美国已经三年，从他的朋友圈里可以看到他的生活。赶论文到凌晨，经常参加各种交流会。</p><p>我们本以为，留学的生活，应该是自由的，潇洒的。旅行、趴体、交友、上课，但没有想到的是，比我们想象的要艰苦很多倍。</p>', 17, 1, 'upload/17-11-20/1511146686478dt2.jpg', 33, '2017-11-20 02:58:14', 20, 2, '3,6'),
(27, '那些年，陪我熬过抑郁症的那个女孩', '<p>我睁开眼，房里一片明亮。今日竟睡到中午了？我伸手摸到床头柜上的手机，上面显示是01:38,我轻轻起身，看一旁的乔叶面容恬静，眉眼间的憔悴显而易见.由于担心我半夜醒来房里一片黑暗，每晚睡前，乔叶都留着灯，可每一次，我都以为这是天亮了。</p><p>我站在阳台上，夜风猛烈地吹着，街上偶尔有汽车的影子一闪而过。整个城市都入眠了，只有我还在这高楼上眺望。没有风景，只有无尽的漆黑与孤独。</p><p>如果从这十八层楼上跳下去，应该不会有人在意吧。这么大的城市，我是多么渺小，微不足道。乔叶，对不起，如果有来世，我一定会在茫茫人海中找到你，加倍补偿今生我对你的亏欠。”我自言自语，打开了窗。</p><p>“王哲,你……”夜风吹起她的头发，飘到我的脸上。她从身后抱住我，伏在我的背上哭泣。</p>', 17, 1, 'upload/17-11-20/1511146784101dt3.jpg', 33, '2017-11-20 02:59:53', 20, 2, '1,2,7'),
(28, '冰冷的陶瓷餐具', '<p>我们还有简友写作群，大家发自己的文章互评，也分享经典名著中的经验。“那不是像我们的买买群，嗨，你帮我看看这件大衣怎么样，丢个链接。《林青霞30年前惊艳造型》，再丢个链接。”对，就是这么热闹友好。</p><p>简书的创始人林立说过“像淘宝让每个人都能做生意，简书的愿景和使命就是人人都能创作，我们希望做一个全民创作的平台。”</p><p>只要够特别，你就尽情写。有人写买买经的文章，简书设专题《买买买购物指南》，关注和阅读量也是嗖嗖地火箭一样升。</p><p>“写文章有钱吗？”“没。简书是免费分享平台。”“我看你在简书写文章，就是在赚钱呢，业余时间都给了简书，单位里工资奖金，不花就是赚。</p>', 17, 1, 'upload/17-11-20/151114690011dt4.jpg', 33, '2017-11-20 03:01:49', 90, 2, '3,6,7'),
(29, '醒醒吧！别总以为自己会逆袭', '<pre><p><br/></p></pre><p>大学同学阿雨最近经常给我打电话，说的最多的一句话就是，“青木，现实真特么残酷.听到她的话，我脑海中反映的是“现实难道不是一直很残酷吗！”。我没有说出心里想要说的话，只能用耳朵一遍遍的接受她负能量的洗礼.我和阿雨第一次见面，那时是院里开迎新会，我和舍友早早的去占了座位，正当我和舍友聊的热火朝天的时候。有个柔柔的声音传了过来，“同学，能往里面移一下吗？”</p><p>我转过头，看见阿雨当时羞羞涩涩的站在原地，姑娘当时看起来很青涩，我赶紧招呼着舍友往旁边移了一下，让她坐下。</p><p>我们都刚脱离高考的魔掌，就像放出笼子的鸟儿，在自由的天空中飞翔，干着以往在高中时刻禁止干的事情。所以因同样喜爱文学，同样喜欢小说，我们成了无话不谈的朋友。</p>', 17, 1, 'upload/17-11-20/1511147073310dt5.jpg', 33, '2017-11-20 03:04:40', 55, 2, '1,2,3');

-- --------------------------------------------------------

--
-- 表的结构 `good`
--

CREATE TABLE `good` (
  `gid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `conid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `guanzhu`
--

CREATE TABLE `guanzhu` (
  `gid` int(11) NOT NULL,
  `uid1` int(11) DEFAULT NULL COMMENT '关注者',
  `uid2` int(11) DEFAULT NULL COMMENT '被关注者'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `guanzhu`
--

INSERT INTO `guanzhu` (`gid`, `uid1`, `uid2`) VALUES
(28, 1, 6),
(20, 1, 1),
(21, 14, 1),
(22, 15, 1),
(23, 16, 1),
(24, 14, 6),
(25, 6, 1),
(26, 16, 6);

-- --------------------------------------------------------

--
-- 表的结构 `hits`
--

CREATE TABLE `hits` (
  `hid` int(11) NOT NULL,
  `conid` int(11) DEFAULT NULL,
  `hnum` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `hits`
--

INSERT INTO `hits` (`hid`, `conid`, `hnum`) VALUES
(1, 10, 409),
(2, 3, 35),
(3, 14, 3),
(4, 18, 6),
(5, 12, 27),
(6, 13, 23),
(7, 15, 7),
(8, 11, 8),
(9, 19, 2),
(10, 27, 1),
(11, 29, 5),
(12, 22, 2);

-- --------------------------------------------------------

--
-- 表的结构 `level`
--

CREATE TABLE `level` (
  `lid` int(11) NOT NULL,
  `lname` varchar(32) DEFAULT NULL,
  `messagenum` varchar(32) DEFAULT NULL COMMENT '留言的权限',
  `connum` varchar(11) DEFAULT NULL COMMENT '内容的权限',
  `adminnum` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `level`
--

INSERT INTO `level` (`lid`, `lname`, `messagenum`, `connum`, `adminnum`) VALUES
(1, '超级管理员', '1,2,3,4', '1,2,3,4', '1,2,3,4'),
(35, '游客', '4', '4', '4'),
(31, '编辑', '3,4', '3,4', '4'),
(32, '管理员', '3,4', '2,3,4', '3,4');

-- --------------------------------------------------------

--
-- 表的结构 `message`
--

CREATE TABLE `message` (
  `mid` int(11) NOT NULL,
  `uid1` varchar(255) DEFAULT NULL COMMENT '留言者',
  `uid2` varchar(255) DEFAULT NULL COMMENT '被留言者',
  `conid` int(11) DEFAULT NULL COMMENT '给哪条内容留留言',
  `mcon` varchar(255) DEFAULT NULL,
  `state` int(11) DEFAULT NULL COMMENT '状态'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `message`
--

INSERT INTO `message` (`mid`, `uid1`, `uid2`, `conid`, `mcon`, `state`) VALUES
(4, '14', '6', 10, '测试1', 0),
(84, '1', '1', 3, '这是回复测试', 83),
(83, '1', '1', 3, '这是留言测试', 0),
(13, '14', '6', 10, '啊啊啊', 0),
(17, '14', '6', 10, 'bbbbbbb', 0),
(18, '14', '6', 10, '123456', 0),
(19, '14', '14', 10, '1234563', 1),
(20, '14', '6', 10, '123456789', 0),
(21, '14', '14', 10, '00000000000000000000', 1),
(22, '14', '14', 10, '@fans1:2653165', 1),
(24, '14', '14', 10, '1', 1),
(26, '14', '14', 10, '1', 1),
(27, '14', '14', 10, '@fans1:2', 1),
(28, '14', '14', 10, '@fans1:2', 1),
(30, '14', '14', 10, '测试1次', 1),
(31, '14', '14', 10, '@fans1:测试2次', 1),
(32, '14', '14', 10, '@fans1:测试3次', 1),
(33, '1', '6', 10, 'aaaaaaa', 0),
(34, '1', '1', 10, 'ddd', 9),
(35, '1', '6', 10, 'aaaaaaaaa', 3),
(36, '1', '6', 10, 'dbibds', 0),
(37, '1', '1', 10, '64163516', 1),
(38, '1', '1', 10, '@user:163513683115', 1),
(39, '1', '6', 10, '00', 37),
(40, '1', '6', 10, 'qqqqqqqqqqqqq', 37),
(41, '1', '1', 10, 'wwwwwwww', 37),
(46, '1', '6', 10, 'aaaa', 0),
(47, '1', '1', 10, 'adasdasfasda', 39),
(48, '1', '1', 10, 'asasd a', 39),
(49, '1', '1', 10, '@user:awf', 39),
(88, '1', '1', 13, '这是一条留言', 0),
(52, '1', '6', 10, 'aaaa', 0),
(53, '1', '1', 10, 'aaa', 45),
(54, '1', '6', 10, 'www', 0),
(55, '1', '1', 10, 'asds', 47),
(56, '1', '1', 10, 'adas', 47),
(57, '1', '1', 10, 'fasfz', 47),
(58, '1', '6', 10, 'aaaaaa', 0),
(59, '1', '1', 10, 'aaaaa', 58),
(60, '1', '6', 10, 'asdasdasdsdasdasdasdasdasddasddaa', 0),
(61, '1', '1', 10, 'sadsa', 60),
(87, '1', '1', 10, '啊', 0),
(63, '1', '6', 10, 'sad', 0),
(64, '1', '1', 10, 'as', 63),
(65, '1', '6', 10, 'asdsadasd', 0),
(66, '1', '1', 10, 'dssadas', 65),
(67, '1', '6', 10, 'ESFESGF', 0),
(68, '1', '1', 10, 'SF', 67),
(69, '1', '1', 10, 'SDF', 67),
(70, '1', '1', 10, '@user:DSF', 67),
(91, '1', '1', 13, '这是新的测试', 0),
(89, '1', '1', 13, '这是一条回复', 88),
(75, '1', '1', 10, 'WFDWERFWQFEWFEFESDFDSF', 74),
(76, '1', '1', 10, '@user:RDSFSDF', 74),
(90, '1', '1', 13, '@user:这是回复的回复', 88),
(86, '1', '1', 12, '哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈', 85);

-- --------------------------------------------------------

--
-- 表的结构 `position`
--

CREATE TABLE `position` (
  `pid` int(11) NOT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `pthumb` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `position`
--

INSERT INTO `position` (`pid`, `pname`, `pthumb`) VALUES
(1, '短篇小说', 'upload/17-11-12/1510470029459a.jpg'),
(2, '成长励志', 'upload/17-11-12/1510470029459a.jpg'),
(3, '文学', 'upload/17-11-12/1510470029459a.jpg'),
(4, '浅谈写作', 'upload/17-11-11/1510362511460aaa.png'),
(6, '旅行-在路上', 'upload/17-11-12/1510470029459a.jpg'),
(7, '上班这点事', 'upload/17-11-12/1510470142826a.jpg'),
(8, '社会热点', 'upload/17-11-12/1510470261397banner.jpeg');

-- --------------------------------------------------------

--
-- 表的结构 `role`
--

CREATE TABLE `role` (
  `rid` int(11) NOT NULL,
  `rname` varchar(32) DEFAULT NULL,
  `connum` int(11) NOT NULL,
  `conlevel` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `role`
--

INSERT INTO `role` (`rid`, `rname`, `connum`, `conlevel`) VALUES
(2, '普通会员', 1, 1),
(3, '白金会员', 50, 3),
(4, '钻石会员', 100, 3);

-- --------------------------------------------------------

--
-- 表的结构 `self`
--

CREATE TABLE `self` (
  `selfid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `conid` int(11) DEFAULT NULL,
  `money` int(255) DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `shoucang`
--

CREATE TABLE `shoucang` (
  `sid` int(11) NOT NULL,
  `uid1` int(11) DEFAULT NULL COMMENT '收藏者',
  `uid2` int(11) DEFAULT NULL COMMENT '被收藏者'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `shoucang`
--

INSERT INTO `shoucang` (`sid`, `uid1`, `uid2`) VALUES
(2, 1, 1),
(3, 17, 17);

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `uname` varchar(30) DEFAULT NULL,
  `upass` varchar(32) DEFAULT NULL,
  `nicheng` varchar(32) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `level` tinyint(2) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `regdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`uid`, `uname`, `upass`, `nicheng`, `photo`, `level`, `phone`, `regdate`) VALUES
(1, 'user', 'e10adc3949ba59abbe56e057f20f883e', '若荷清寒', 'upload/17-11-08/151012332025a.jpg', 2, '1234567', '2017-10-30 07:59:24'),
(6, '白发老头', 'e10adc3949ba59abbe56e057f20f883e', 'User', 'upload/17-11-08/1510149532446aaa.png', 2, '123456789', '2017-11-07 13:50:21'),
(10, '雪花乳糖', 'e10adc3949ba59abbe56e057f20f883e', 'abc', 'upload/17-11-08/151012332025a.jpg', 2, '12345678910', '2017-11-08 06:42:02'),
(11, '名贵的考拉', 'e10adc3949ba59abbe56e057f20f883e', 'User', 'upload/17-11-08/1510149412323a.jpeg', 2, '12345678910', '2017-11-08 06:54:21'),
(12, '在下行知', 'e10adc3949ba59abbe56e057f20f883e', 'User', 'upload/17-11-12/1510475795559aaa.png', 2, '12300000000', '2017-11-08 08:16:17'),
(13, '一棵白菜', 'e10adc3949ba59abbe56e057f20f883e', 'ceshi', 'upload/17-11-08/1510149434421tou.jpeg', 3, '12345678910', '2017-11-08 11:18:09'),
(14, 'fans1', 'e10adc3949ba59abbe56e057f20f883e', '粉丝一号', 'upload/17-11-14/1510624028630zzt1.png', 2, '12345678910', '2017-11-13 13:43:53'),
(15, 'fans2', 'e10adc3949ba59abbe56e057f20f883e', '粉丝二号', 'upload/17-11-14/1510624028630zzt1.png', 2, '12345678910', '2017-11-13 13:44:23'),
(16, 'fans3', 'e10adc3949ba59abbe56e057f20f883e', '粉丝三号', 'upload/17-11-08/1510149434421tou.jpeg', 2, '12345678910', '2017-11-13 13:44:56'),
(17, '包子', 'e10adc3949ba59abbe56e057f20f883e', '哎呦喂', 'upload/17-11-20/1511144040544bao.jpg', 2, '17835394040', '2017-11-20 01:00:49');

-- --------------------------------------------------------

--
-- 表的结构 `usermessage`
--

CREATE TABLE `usermessage` (
  `userMid` int(11) NOT NULL,
  `userMname` varchar(50) NOT NULL,
  `userMcon` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `usermessage`
--

INSERT INTO `usermessage` (`userMid`, `userMname`, `userMcon`) VALUES
(1, '1张三2', '自称“小仙女”的女粉丝222'),
(2, '1张三', '自称“小仙女”的女粉丝');

-- --------------------------------------------------------

--
-- 表的结构 `zhanghu`
--

CREATE TABLE `zhanghu` (
  `zhanghuid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `money` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `buy`
--
ALTER TABLE `buy`
  ADD PRIMARY KEY (`buyid`);

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`carid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `con`
--
ALTER TABLE `con`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `good`
--
ALTER TABLE `good`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `guanzhu`
--
ALTER TABLE `guanzhu`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `hits`
--
ALTER TABLE `hits`
  ADD PRIMARY KEY (`hid`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `self`
--
ALTER TABLE `self`
  ADD PRIMARY KEY (`selfid`);

--
-- Indexes for table `shoucang`
--
ALTER TABLE `shoucang`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `usermessage`
--
ALTER TABLE `usermessage`
  ADD PRIMARY KEY (`userMid`);

--
-- Indexes for table `zhanghu`
--
ALTER TABLE `zhanghu`
  ADD PRIMARY KEY (`zhanghuid`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- 使用表AUTO_INCREMENT `buy`
--
ALTER TABLE `buy`
  MODIFY `buyid` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `car`
--
ALTER TABLE `car`
  MODIFY `carid` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `category`
--
ALTER TABLE `category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- 使用表AUTO_INCREMENT `con`
--
ALTER TABLE `con`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- 使用表AUTO_INCREMENT `good`
--
ALTER TABLE `good`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `guanzhu`
--
ALTER TABLE `guanzhu`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- 使用表AUTO_INCREMENT `hits`
--
ALTER TABLE `hits`
  MODIFY `hid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- 使用表AUTO_INCREMENT `level`
--
ALTER TABLE `level`
  MODIFY `lid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- 使用表AUTO_INCREMENT `message`
--
ALTER TABLE `message`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
--
-- 使用表AUTO_INCREMENT `position`
--
ALTER TABLE `position`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- 使用表AUTO_INCREMENT `role`
--
ALTER TABLE `role`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- 使用表AUTO_INCREMENT `self`
--
ALTER TABLE `self`
  MODIFY `selfid` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `shoucang`
--
ALTER TABLE `shoucang`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- 使用表AUTO_INCREMENT `usermessage`
--
ALTER TABLE `usermessage`
  MODIFY `userMid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

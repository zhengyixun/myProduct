jQuery(document).ready(function ($) {
    $(".slider").slideshow({
        width: 1000,
        height: 300,
        transition: ['bar', 'Rain', 'square', 'squareRandom', 'explode']
    });
});
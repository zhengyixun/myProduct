<?php
return array(
    'database'=> array(
        'host'=>'localhost',
        'port'=>'3306',
        'user'=>'root',
        'pass'=>'123456',
        'database'=>'w1703_blog'
    )
)
?>
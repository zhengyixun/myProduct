<?php
class selfInfo extends main{
    //查看个人信息
    function showInfo(){
        $uid=$_SESSION['uid'];
        $db=new db("user");
        $result=$db->where("uid=".$uid)->find();
        $photo=isset($result["photo"])?$result["photo"]:"";
        $this->smarty->assign("result",$result);
        $this->smarty->assign("photo",$photo);
        $this->smarty->display("index/Self/self.html");
    }
    //修改个人信息
    function updateInfo(){
        $uid=$_SESSION['uid'];
        $uname=$_POST['uname'];
        $phone=$_POST['phone'];
        $nicheng=$_POST['nicheng'];

        $photo=$_POST['photo'];
        $db=new db("user");

        if($photo){
            //上传了新的头像
            $result=$db->where("uid=".$uid)->update("uname="."'{$uname}'".",nicheng="."'{$nicheng}'".",photo="."'{$photo}'".",phone=$phone");
            if($result>0){
                echo "<script>alert('修改成功');location.href='index.php?m=index&f=selfInfo&a=showInfo'</script>";
            }
        }else{
            //没有上传头像
            $result=$db->where("uid=".$uid)->update("uname="."'{$uname}'".",nicheng="."'{$nicheng}'".",phone=$phone");
            if($result>0) {
                echo "<script>alert('修改成功');location.href='index.php?m=index&f=selfInfo&a=showInfo'</script>";
            }
        }
    }
}
<?php
class message extends main{
    //后台功能----查看留言
    function showMessage(){
        $db=new db();
        $db->selectTable("message");
        $total=$db->select();
        $page=new pages();
        $page->total=count($total);
        $str=$page->show();
        $sql="select message.*,user.uname from message,user WHERE message.uid1=user.uid  limit ".$page->limit;
        $result=$db->select($sql);

        $this->smarty->assign("str",$str);
        $this->smarty->assign("result",$result);
        $this->smarty->display("admin/showMessage.html");
    }
    //删除留言
    function delMessage(){
        $mid=$_GET['mid'];
        $db=new db("message");
        if($db->where("mid=".$mid)->delete()>0){
            echo "<script>alert('删除成功');location.href='index.php?m=admin&f=message&a=showMessage'</script>";
        }

    }
}

<?php
/* Smarty version 3.1.30, created on 2017-11-20 03:38:51
  from "D:\360Downloads\wamp64\www\1703\11-01mvc\template\index\comment.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a124e4b066448_50833808',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a2368decf85046748c63a2208d0389520c6bdd36' => 
    array (
      0 => 'D:\\360Downloads\\wamp64\\www\\1703\\11-01mvc\\template\\index\\comment.html',
      1 => 1510984221,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a124e4b066448_50833808 (Smarty_Internal_Template $_smarty_tpl) {
?>
<link rel="stylesheet" href="<?php echo CSS_URL;?>
/comment.css">
<div class="comment">
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data5']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
    <div class="commentCon">
        <div class="commentConTop">
            <div class="commentConTopImg">
                <img src="<?php echo $_smarty_tpl->tpl_vars['v']->value['photo'];?>
" alt="">
            </div>
            <h4><?php echo $_smarty_tpl->tpl_vars['v']->value['uname'];?>
</h4>
            <h5><?php echo $_smarty_tpl->tpl_vars['v']->value['mid'];?>
楼 2017.10.23 08:54</h5>
        </div>
        <!--评论内容-->
        <h5 style="display: block;width: 100%;height: auto;margin-top: 10px"><?php echo $_smarty_tpl->tpl_vars['v']->value['mcon'];?>
</h5>
        <div class="hits">
            <button type="button" class="btn btn-default btn-sm rbtn">回复</button>
        </div>
        <!--添加新的评论-->
        <div class="replayList">


            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['v']->value["son"], 'v2');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v2']->value) {
?>
            <div class='replayCon'>
                <span class="authorCon"><?php echo $_smarty_tpl->tpl_vars['v2']->value['uname'];?>
:</span><br>
                <span><?php echo $_smarty_tpl->tpl_vars['v2']->value['mcon'];?>
</span><br>
                <span class="authortime">2017-11-01</span>
                <button type="button" class="rbtn replayBtn" style="border: none;background: #fff;outline: none">回复</button>
            </div>
            <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


            <!--添加新评论-->
            <button type="button" class="rbtn" style="border: none;background: #fff;outline: none;margin-top:20px;">添加新评论</button>
            <div class="inp">
                <textarea name="" id="" cols="30" rows="10" class="tjCon"></textarea><br>
                <button type="button" class="btn btn-default btn-sm tj" uid2="<?php echo $_smarty_tpl->tpl_vars['uid1']->value;?>
" state="<?php echo $_smarty_tpl->tpl_vars['mid']->value;?>
">提交</button>
                <button type="button" class="btn btn-default btn-sm cancels">取消</button>
            </div>
        </div>
    </div>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</div><?php }
}

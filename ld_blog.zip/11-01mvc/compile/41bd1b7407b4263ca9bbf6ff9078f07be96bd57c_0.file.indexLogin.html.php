<?php
/* Smarty version 3.1.30, created on 2018-01-10 07:47:02
  from "D:\360Downloads\wamp64\www\1703\11-01mvc\template\index\indexLogin.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a55c4f6b19365_76793675',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '41bd1b7407b4263ca9bbf6ff9078f07be96bd57c' => 
    array (
      0 => 'D:\\360Downloads\\wamp64\\www\\1703\\11-01mvc\\template\\index\\indexLogin.html',
      1 => 1510057026,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a55c4f6b19365_76793675 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo '<script'; ?>
 src="<?php echo JS_URL;?>
/jquery-3.2.1.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo JS_URL;?>
/jquery.validate.min.js"><?php echo '</script'; ?>
>
    <link rel="stylesheet" href="<?php echo CSS_URL;?>
/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS_URL;?>
/login.css">
    <title>login</title>
</head>
<body>
<h1><a href="index.php">Blog</a></h1>
<div class="box">
    <div class="text">
        <div class="login"><a href="index.php?m=index&f=indexLogin&a=init">登录</a></div>
        <div class="reg"><a href="index.php?m=index&f=indexLogin&a=indexReg">注册</a></div>
    </div>
    <!--登录-->
    <div class="logindo">
        <form action="index.php?m=index&f=indexLogin&a=check" method="post">
            <ul class="list-group">
                <li class="list-group-item">
                    <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-user" id="basic-addon1"></span>
                        <input type="text" class="form-control" placeholder="请输入账号" name="uname" aria-describedby="basic-addon1" autocomplete="off">
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-lock"></span>
                        <input type="password" class="form-control" name="upass" placeholder="请输入密码" aria-describedby="basic-addon1" autocomplete="off">
                    </div>
                </li>
                <li class="list-group-item codeInput">
                    <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-leaf"></span>
                        <input type="text" class="form-control" name="ucode" placeholder="请输入验证码" aria-describedby="basic-addon1" autocomplete="off">
                    </div>
                    <div class="imgCode">
                        <img id="img" src="index.php?m=index&f=indexLogin&a=imgCode" onclick="this.src='index.php?m=index&f=indexLogin&a=imgCode'" alt="">
                    </div>
                </li>
            </ul>
            <input type="checkbox"> 记住我
            <button type="submit" class="btn btn-default btn-info login1">登录</button>
        </form>
    </div>
</div>
</body>
<?php echo '<script'; ?>
>
    $(function(){
        $('form').validate({
            rules:{
                aname: {
                    required: true,
                    minlength: 2
                },
                apass: {
                    required: true,
                    minlength: 6
                },
            },
            messages:{
                aname: {
                    required: '请输入用户名',
                    minlength: '长度不得小于2位'
                },
                apass: {
                    required: '请输入密码',
                    minlength: '长度不得小于6位'
                },
            },
        })

    })
<?php echo '</script'; ?>
>
</html><?php }
}

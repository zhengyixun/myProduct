<?php
/* Smarty version 3.1.30, created on 2017-11-20 03:38:50
  from "D:\360Downloads\wamp64\www\1703\11-01mvc\template\index\blogCon.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a124e4ac9e457_79599025',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '39506ecdfcd7f072c4018c3cf6c5ce203df3d3e9' => 
    array (
      0 => 'D:\\360Downloads\\wamp64\\www\\1703\\11-01mvc\\template\\index\\blogCon.html',
      1 => 1511149127,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a124e4ac9e457_79599025 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['header']->value, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

<link rel="stylesheet" href="<?php echo CSS_URL;?>
/header.css">
<link rel="stylesheet" href="<?php echo CSS_URL;?>
/blogCon.css">
<?php echo '<script'; ?>
 src="<?php echo JS_URL;?>
/jquery-3.2.1.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo JS_URL;?>
/blogCon.js"><?php echo '</script'; ?>
>
<main cid="<?php echo $_smarty_tpl->tpl_vars['result']->value['cid'];?>
" uid2="<?php echo $_smarty_tpl->tpl_vars['result']->value['uid'];?>
" uid1="<?php echo $_smarty_tpl->tpl_vars['uid1']->value;?>
" username="<?php echo $_smarty_tpl->tpl_vars['username']->value;?>
">
    <div class="headBox"></div>
    <h1><?php echo $_smarty_tpl->tpl_vars['result']->value['ctitle'];?>
</h1>
    <div class="author">
        <div class="authorImg">
            <img src="<?php echo $_smarty_tpl->tpl_vars['result']->value['thumb'];?>
" alt="">
        </div>
        <h4><?php echo $_smarty_tpl->tpl_vars['uname']->value;?>
</h4>
        <div class="atte">
            <?php if (!$_smarty_tpl->tpl_vars['uname']->value) {?>
            <a href="javascript:;" class="guanzhu" style="display: block;">+关注</a>
            <a href="javascript:;" class="cancel" style="display: none;background: grey">取消关注</a>
            <?php } else { ?>
                <?php if ($_smarty_tpl->tpl_vars['flag']->value != 0) {?>
            <a href="javascript:;" class="guanzhu" style="display: none;">+关注</a>
            <a href="javascript:;" class="cancel" style="display: block;background: grey">取消关注</a>
                <?php } else { ?>
            <a href="javascript:;" class="guanzhu" style="display: block;">+关注</a>
            <a href="javascript:;" class="cancel" style="display: none;background: grey">取消关注</a>
                <?php }?>
            <?php }?>
        </div>
        <h5><?php echo $_smarty_tpl->tpl_vars['result']->value['condate'];?>
 字数 3336 阅读 <?php echo $_smarty_tpl->tpl_vars['dj']->value['hnum'];?>
 评论 62 喜欢 81 赞赏 4</h5>
    </div>
    <div class="textCon">
        <p><?php echo $_smarty_tpl->tpl_vars['result']->value['ccon'];?>
</p>﻿﻿
    </div>
    <!--作者信息-->
    <div class="authorCons">
        <img src="<?php echo IMG_URL;?>
/a.jpeg" alt="">
        <h4><?php echo $_smarty_tpl->tpl_vars['author']->value['uname'];?>
</h4>
        <h5>获得了100个关注</h5>
        <div class="consBox">
            探索这个世界的游戏规则 专研—自
        </div>
        <!--收藏-->
        <?php if (!$_smarty_tpl->tpl_vars['uname']->value) {?>
        <a href="javascript:;" class="love" style="display: block;">+收藏</a>
        <a href="javascript:;" class="noLove" style="display: none;background: grey">取消收藏</a>
        <?php } else { ?>
        <?php if ($_smarty_tpl->tpl_vars['flags']->value != 0) {?>
        <a href="javascript:;" class="love" style="display: none;">+收藏</a>
        <a href="javascript:;" class="noLove" style="display: block;background: grey">取消收藏</a>
        <?php } else { ?>
        <a href="javascript:;" class="love" style="display: block;">+收藏</a>
        <a href="javascript:;" class="noLove" style="display: none;background: grey">取消收藏</a>
        <?php }?>
        <?php }?>
    </div>
    <!--填写评论-->
    <div class="mess">
        <textarea name="" id="" cols="30" rows="10" placeholder="请填写您的评论" class="myCon"></textarea>
        <button type="button" class="btn btn-default myConBtn" style="float: right;margin: 10px 0">提交</button>
    </div>
    <!--评论comment 在新的页面-->
    <?php $_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['comment']->value, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>


</main>
</body>
</html><?php }
}

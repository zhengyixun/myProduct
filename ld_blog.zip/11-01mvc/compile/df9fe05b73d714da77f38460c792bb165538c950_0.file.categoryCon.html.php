<?php
/* Smarty version 3.1.30, created on 2018-01-10 07:47:31
  from "D:\360Downloads\wamp64\www\1703\11-01mvc\template\index\categoryCon.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a55c5130a3f44_31025126',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'df9fe05b73d714da77f38460c792bb165538c950' => 
    array (
      0 => 'D:\\360Downloads\\wamp64\\www\\1703\\11-01mvc\\template\\index\\categoryCon.html',
      1 => 1510974335,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a55c5130a3f44_31025126 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender($_smarty_tpl->tpl_vars['header']->value, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>

    <link rel="stylesheet" href="<?php echo CSS_URL;?>
/categoryCon.css">
    <link rel="stylesheet" href="<?php echo CSS_URL;?>
/header.css">
<main>
    <div class="headBox"></div>
    <div class="title">
        <div class="titleImg"><img src="<?php echo IMG_URL;?>
/iconfont/zhuzhuangtu.png" alt=""></div>
        <span><?php echo $_smarty_tpl->tpl_vars['result1']->value['cname'];?>
</span>
    </div>
    <!--分类页开始-->
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['result2']->value, 'v2');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v2']->value) {
?>
    <div class="con">
        <div class="conTop">
            <div class="conTopImg"><img src="<?php echo $_smarty_tpl->tpl_vars['v2']->value['thumb'];?>
" alt=""></div>
            <span class="titles"><?php echo $_smarty_tpl->tpl_vars['v2']->value['uname'];?>
</span>
            <span><?php echo $_smarty_tpl->tpl_vars['v2']->value['condate'];?>
</span>
        </div>
        <h3><a href="index.php?m=index&f=index&a=blogCon&cid=<?php echo $_smarty_tpl->tpl_vars['v2']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['v2']->value['ctitle'];?>
</a></h3>
        <div class="conMid">
            <p><?php echo mb_substr($_smarty_tpl->tpl_vars['v2']->value['ccon'],0,100,'utf-8');?>
</p>
        </div>
        <div class="otherCategory" style="padding-top: 2px">
            <a href="index.php?m=index&f=index&a=qxCon&cquanxian=<?php echo $_smarty_tpl->tpl_vars['v2']->value['cquanxian'];?>
">
                <?php if ($_smarty_tpl->tpl_vars['v2']->value['cquanxian'] == 1) {?>
                普通
                <?php } elseif ($_smarty_tpl->tpl_vars['v2']->value['cquanxian'] == 2) {?>
                精华
                <?php } else { ?>
                热门
                <?php }?>
            </a>
        </div>
        <!--小icon-->
        <div class="iconfont">
            <img src="<?php echo IMG_URL;?>
/eyey.png" alt="">
            <span>21</span>
        </div>
        <div class="iconfont">
            <img src="<?php echo IMG_URL;?>
/info.png" alt="">
            <span>211</span>
        </div>
        <div class="iconfont">
            <img src="<?php echo IMG_URL;?>
/love.png" alt="">
            <span>21</span>
        </div>
        <div class="iconfont">
            <img src="<?php echo IMG_URL;?>
/mon.png" alt="">
            <span>1</span>
        </div>
        <!--右侧缩略图-->
        <div class="rightImg">
            <img src="<?php echo $_smarty_tpl->tpl_vars['v2']->value['thumb'];?>
" alt="">
        </div>
    </div>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

    <!--分类页结束-->
    <!--推荐作者-->
    <div class="hot">
        <span>推荐作者</span>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['result']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
        <div class="hotAuthor">
            <div class="hotAuthorImg">
                <img src="<?php echo $_smarty_tpl->tpl_vars['v']->value['photo'];?>
" alt="">
            </div>
            <span><?php echo $_smarty_tpl->tpl_vars['v']->value['uname'];?>
</span>
            <span class="guanzhu">+关注</span>
            <h5>写了350k字 20.3k喜欢</h5>
        </div>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


        <!--authorAll页面-->
        <div class="sayAll">
            <a href="index.php?m=index&f=index&a=authorAll">查看全部</a>
        </div>
    </div>
</main>

</body>
</html><?php }
}

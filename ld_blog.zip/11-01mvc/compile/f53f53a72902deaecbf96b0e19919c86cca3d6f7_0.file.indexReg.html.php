<?php
/* Smarty version 3.1.30, created on 2018-01-10 07:47:11
  from "D:\360Downloads\wamp64\www\1703\11-01mvc\template\index\indexReg.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a55c4ff879035_86915849',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f53f53a72902deaecbf96b0e19919c86cca3d6f7' => 
    array (
      0 => 'D:\\360Downloads\\wamp64\\www\\1703\\11-01mvc\\template\\index\\indexReg.html',
      1 => 1510110699,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a55c4ff879035_86915849 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo '<script'; ?>
 src="<?php echo JS_URL;?>
/jquery-3.2.1.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="<?php echo JS_URL;?>
/jquery.validate.min.js"><?php echo '</script'; ?>
>
    <link rel="stylesheet" href="<?php echo CSS_URL;?>
/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo CSS_URL;?>
/reg.css">
    <title>reg</title>
</head>
<style>
    label{
        display: block;background: #fff;z-index: 999;
    }
    .click{
        z-index: 99;
    }
</style>
<body>
<h1><a href="index.php">Blog</a></h1>
<div class="box">
    <div class="text">
        <div class="login"><a href="index.php?m=index&f=indexLogin&a=init">登录</a></div>
        <div class="reg"><a href="index.php?m=index&f=indexLogin&a=indexReg">注册</a></div>
    </div>
    <!--登录-->
    <div class="logindo">
        <form action="index.php?m=index&f=indexLogin&a=indexRegCon" method="post">
            <ul class="list-group">
                <li class="list-group-item">
                    <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-user" id="basic-addon1"></span>
                        <input type="text" class="form-control" placeholder="请输入用户名" name="uname" aria-describedby="basic-addon1" autocomplete="off">
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-lock"></span>
                        <input type="password" class="form-control" name="upass" placeholder="请输入密码" aria-describedby="basic-addon1" >
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="input-group fclick">
                        <span class="input-group-addon glyphicon glyphicon-phone"></span>
                        <input type="text" class="form-control" name="phone" placeholder="请输入手机号" aria-describedby="basic-addon1" autocomplete="off">
                        <button class="click">发送验证码</button>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-envelope"></span>
                        <input type="password" class="form-control" name="aphonecode" placeholder="请输入您收到的验证码" aria-describedby="basic-addon1" autocomplete="off">
                    </div>
                </li>
                <li class="list-group-item codeInput">
                    <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-leaf"></span>
                        <input type="text" class="form-control" name="ucode" placeholder="请输入验证码" aria-describedby="basic-addon1" autocomplete="off">
                    </div>
                    <div class="imgCode">
                        <img id="img" src="index.php?m=index&f=indexLogin&a=imgCode" onclick="this.src='index.php?m=index&f=indexLogin&a=imgCode'" alt="">
                    </div>
                </li>
            </ul>
            <button type="submit" class="btn btn-default btn-info login1">注 册</button>
        </form>
    </div>
</div>
</body>
<?php echo '<script'; ?>
 src="<?php echo JS_URL;?>
/indexReg.js"><?php echo '</script'; ?>
>
</html><?php }
}

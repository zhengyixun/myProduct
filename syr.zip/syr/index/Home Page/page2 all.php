<?php
include "../../public/path.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        
        <title>全部分类</title>
        <link rel="stylesheet" type="text/css" href="<?php echo $url1;?>/Home Page/Fontt/iconfont.css"/>
        <link rel="stylesheet" href="<?php echo $url1;?>/Home Page/css/page2.css">
        <script src="<?php echo $url1;?>/Home Page/jQuery/jquery-3.2.1.js"></script>
		<script src="<?php echo $url1;?>/Home Page/jQuery/jquery.sliphover.min.js"></script>
        <script src='<?php echo $url1;?>/Home Page/js/animate.js'></script>
        <script type="text/javascript" src="<?php echo $url1;?>/Home Page/js/coin-slider.js"></script>
		<link rel="stylesheet" type="text/css" href="<?php echo $url1;?>/Home Page/css/coin-slider-styles.css"/>
        <link rel="shortcut icon" href="favicon.ico" />
    </head>
    <body>
  <!-- 搜索框 -->
    <div class="search">
        <div class="serach1">
            <input type="text" class="sea" placeholder="请输入要搜索的宝贝">
            <div class="sea1 iconfont icon-sousuo"></div>
        </div>
    </div>
    <div class="Totop iconfont icon-top1"></div>
    <!-- 头部 -->
    <header>
    	<div class="head">
    		<div class="head-left"><img src="img/Logo_03.png" alt="" /></div>
    		<div class="head-right">
    			<ul class="h">
                    <?php
                    include "../../public/db.php";
                    $sql="select * from category WHERE pid=0";
                    $result=$db->query($sql);
                    $result->setFetchMode(PDO::FETCH_ASSOC);
                    while($row=$result->fetch()){
                        ?>
                        <li class="h1"><a href="<?php echo $row['link']?>"><?php echo $row['cname'];?></a></li>
                        <?php
                    }
                    ?>
    			</ul>
    		</div>
    	</div>
    </header>
    <!-- banner -->
    <section class="banner">
    	<div class="banner-m">
<!--轮播图-->
        <div id='coin-slider'>
            <?php
            $result0=$db->query("select * from shows WHERE cid=15");
            $result0->setFetchMode(PDO::FETCH_ASSOC);
            while ($row0=$result0->fetch()){
                ?>
                <a href="#"><img src="../../admin/<?php echo $row0['simage'];?>" alt=""></a>
                <?php
            }
            ?>
		</div>

            <div class="banner-nav1"></div>
    		<div class="banner-nav">
    			<div class="nav-left"><a href="">A L L</a></div>
    			<div class="nav-m">    			</div>
    			<div class="nav-right">
    				<div class="nav-right1">立 即 查 看</div>
    			</div>
    		</div>

    	</div>
    </section>
    <!-- 文字 -->
    <section class="tex">
        <div class="tex-top">
            <div class="tex-top1"><a href="">依然.</a></div>
            <div class="tex-top2">
                <a href="">极简</a>
                <div class="cil"></div>
            </div>
        </div>
        <div class="tex-bot"><a href="">极简主义风格的居室设计极简主义</a></div>
         <div class="tex-bot"><a href="">装饰上去伪存真，有无相声的道家思想</a></div>
    </section>
    <!-- 圆圈展示 -->
    <section class="circle">
        <div class="circle-m">
            <div class="circle1">
                <div class="circle1-1">
                     <a href=""><div class="circle1-2"></div></a>
                     <div class="circle1-3"><a href=""><img src="img/taoci2.jpg" alt=""></a></div>
                     <a href=""><div class="circle1-4">精致陶罐</div></a>
                </div>
                <div class="ttao"><a href="">陶罐</a></div>
                <div class="tao"><a href="">今俗语窑器谓之磁器者</a></div>
                <div class="tao"><a href="">如纸、明如镜、声如磬</a></div>
                <div class="tao"><a href="">元代瓷器盛行印花瓷及五彩戗金</a></div>
            </div>

             <div class="circle1">
                <div class="circle1-1">
                     <a href=""><div class="circle1-2"></div></a>
                     <div class="circle1-3"><a href=""><img src="img/taoci3.jpg" alt=""></a></div>
                     <a href=""><div class="circle1-4">绝世瓷器</div></a>
                </div>
                <div class="ttao"><a href="">瓷器</a></div>
                <div class="tao"><a href="">珐琅瓷、“粉彩”杰出</a></div>
                <div class="tao"><a href="">胎体质薄轻巧，洁白的瓷体上</a></div>
                <div class="tao"><a href="">敷以蓝色纹饰，素雅清新，充满生机</a></div>
            </div>

             <div class="circle1">
                <div class="circle1-1">
                     <a href=""><div class="circle1-2"></div></a>
                     <div class="circle1-3"><a href=""><img src="img/taoci4.jpg" alt=""></a></div>
                     <a href=""><div class="circle1-4">唯美干花</div></a>
                </div>
                <div class="ttao"><a href="">干花</a></div>
                <div class="tao"><a href="">使鲜花迅速脱水而制成</a></div>
                <div class="tao"><a href="">风干是最常用的一种制作干花的方法</a></div>
                <div class="tao"><a href="">花在干燥过程中有装饰价值</a></div>
            </div>

             <div class="circle1">
                <div class="circle1-1">
                     <a href=""><div class="circle1-2"></div></a>
                     <div class="circle1-3"><a href=""><img src="img/taoci5.jpg" alt=""></a></div>
                     <a href=""><div class="circle1-4">生活摆件</div></a>
                </div>
                <div class="ttao"><a href="">摆件</a></div>
                <div class="tao"><a href="">根据位置，选择不同的摆件</a></div>
                <div class="tao"><a href="">清代玉工善于借鉴绘画、雕刻、工艺美术</a></div>
                <div class="tao"><a href="">小型玉摆饰大多独出心裁</a></div>
            </div>
            
        </div>
    </section>
    <!-- 陶罐系列 -->
    <!-- 头 -->
    <section class="stean">
        <div class="ste"></div>
        <div class="ste1">陶罐系列</div>
        <div class="cude1"></div>
        <div class="cude2"></div>
    </section>
    <!-- 主 -->
    <div class="stean-m"><a href=""><img src="img/taoqi/tq1.jpg" alt=""></a></div>
    <div class="stean-m1">
        <div class="stean-m2"><a href=""><img src="img/taoci1.jpg" alt=""></a></div>
        <div class="stean-m3"><a href="">墙角粗陶系列</a></div>
        <div class="cir">
            <a href=""><div class="cir1">
                <div class="cir1-1">￥279</div>
                <div class="cir1-2">套餐价</div>
            </div></a>
        </div>
        <div class="stean-m4"><a href="">粗陶</a>
            <div class="cude0"></div>
        </div>
        <div class="stean-m5">含铁量多的陶泥烧制的陶器</div>
        <div class="stean-m5">彩陶花纹富于变化</div>
        <div class="stean-m5">有令人引以为豪的悠久历史</div>
        <div class="stean-m5">秦汉兵马陶俑的朴拙高古</div>
        <div class="stean-m5">唐三彩造型釉彩绚丽多姿</div>
        <div class="stean-m5">宋瓷的幽澹高雅</div>
        <div class="stean-m5">韵致精微</div>
        <div class="stean-m5">精美</div>
    </div>
    <div class="hand">
        <?php
        $result1=$db->query("select * from shows WHERE cid=22");
        $result1->setFetchMode(PDO::FETCH_ASSOC);
        while ($row1=$result1->fetch()){
            ?>
            <div class="hand1"><a href="">
                    <span class="hand0">Hot</span>
                    <div class="hand2"><img src="../../admin/<?php echo $row1['simage'];?>" alt=""></div>
                    <div class="hand3">手工陶艺茶壶</div>
                    <div class="hand4">传承经典</div>
                </a></div>
            <?php
        }
        ?>
    </div>
<!-- 瓷器系列 -->
    <section class="stean">
        <div class="ste"></div>
        <div class="ste1">瓷器系列</div>
        <div class="cude1"></div>
        <div class="cude2"></div>
    </section>
    <div class="ciqi">
        <div class="ciqi1">
            <div class="ciqi1-1">白瓷系列</div>
            <div class="ciqi1-1">青花瓷系列</div>
            <div class="ciqi1-1">彩瓷系列</div>
        </div>
        <?php
        $result2=$db->query("select * from shows WHERE cid=23");
        $result2->setFetchMode(PDO::FETCH_ASSOC);
        while ($row2=$result2->fetch()){
            ?>
            <div class="ciqi-m">
                <a href="">
                    <div class="ciqi-m1"><img src="../../admin/<?php echo $row2['simage'];?>" alt=""></div>
                    <div class="ciqi-tex">手工陶艺山水盘</div>
                    <div class="ciqi-tex1">传承精湛手工，雕琢每一件艺术品</div>
                </a>
            </div>
            <?php
        }
        ?>
    </div>
    <!-- 干花系列 -->
    <section class="stean">
        <div class="ste"></div>
        <div class="ste1">干花系列</div>
        <div class="cude1"></div>
        <div class="cude2"></div>
    </section>
    <div class="stean-m"><a href=""><img src="img/dt/tq2.jpg" alt=""></a></div>
    <div class="stean-m1">
        <div class="stean-m2"><a href=""><img src="img/taoci1.jpg" alt=""></a></div>
        <div class="stean-m3"><a href="">绝美干花系列</a></div>
        <div class="cir">
            <a href=""><div class="cir1">
                <div class="cir1-1">￥1119</div>
                <div class="cir1-2">套餐价</div>
            </div></a>
        </div>
        <div class="stean-m4"><a href="">干花</a>
            <div class="cude0"></div>
        </div>
        <div class="stean-m5">啊啊啊啊啊啊啊啊啊啊啊</div>
        <div class="stean-m5">啊啊啊啊啊啊啊啊啊啊</div>
        <div class="stean-m5">啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊</div>
        <div class="stean-m5">啊啊啊啊啊啊啊啊啊啊</div>
        <div class="stean-m5">啊啊啊啊啊啊啊</div>
        <div class="stean-m5">啊啊啊啊啊啊</div>
        <div class="stean-m5">韵啊啊啊啊啊</div>
        <div class="stean-m5">啊啊啊啊</div>
    </div>
     <div class="ciqi">
        <div class="ciqi1">
            <!-- <div class="ciqi1-1">白瓷系列</div>
            <div class="ciqi1-1">青花瓷系列</div>
            <div class="ciqi1-1">彩瓷系列</div> -->
        </div>

         <?php
         $result2=$db->query("select * from shows WHERE cid=23");
         $result2->setFetchMode(PDO::FETCH_ASSOC);
         while ($row2=$result2->fetch()){
             ?>
             <div class="ciqi-m">
                 <a href="">
                     <div class="ciqi-m1"><img src="../../admin/<?php echo $row2['simage'];?>" alt=""></div>
                     <div class="ciqi-tex">手工陶艺山水盘</div>
                     <div class="ciqi-tex1">传承精湛手工，雕琢每一件艺术品</div>
                 </a>
             </div>
             <?php
         }
         ?>
    </div>
    <!-- 干花系列结束 -->
     <!-- 瓷器系列 -->
    <section class="stean">
        <div class="ste"></div>
        <div class="ste1">瓷器系列</div>
        <div class="cude1"></div>
        <div class="cude2"></div>
    </section>
    <div class="cq">
        <div class="cq-left"><img src="img/hand/ciqi (1).jpg" alt=""></div>
        <div class="cq-right">
            <?php
            $result2=$db->query("select * from shows WHERE cid=24");
            $result2->setFetchMode(PDO::FETCH_ASSOC);
            while ($row2=$result2->fetch()){
                ?>
                <div class="cq-right1">
                    <div class="cq-right2"><img src="../../admin/<?php echo $row2['simage'];?>" alt=""></div>
                    <div class="cq-tex1">竹网装饰花篮</div>
                    <div class="cq-tex2">啊啊啊啊</div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
      <!-- demo开始-->
      <div class="demo-t">CREATIVE PRODUCT</div>
        <div class="demo" id="demo1">
            <ul>
                <li>
                    <a href="#">
                    <img src="img/bj/bj1.jpg" title="description goes here"/>
                    </a>
                </li>
                <li>
                    <a href="#" >
                    <img src="img/bj/bj (4).png" title="description goes here" />
                    </a>
                </li>
                <li>
                    <a href="#">
                    <img src="img/bj/bj2.jpg" title="with html, you can put  or any other element you want" />
                    </a>
                </li>
                <li>
                    <a href="#">
                    <img src="img/bj/bj (4).png" title="description for this image" />
                    </a>
                </li>
                <li>
                    <a href="#">
                    <img src="img/bj/bj3.jpg" title="this is a normal caption" />
                    </a>
                </li>
                <li>
                    <a href="#" >
                    <img src="img/bj/bj (4).png" title="description goes here" />
                    </a>
                </li>
                <li>
                    <a href="#">
                    <img src="img/bj/bj4.jpg" title="with html, you can put  or any other element you want" />
                    </a>
                </li>
                <li>
                    <a href="#">
                    <img src="img/bj/bj (4).png" title="description for this image" />
                    </a>
                </li>
                <li>
                    <a href="#">
                    <img src="img/bj/bj5.jpg" title="this is a normal caption" />
                    </a>
                </li>
                <li>
                    <a href="#" >
                    <img src="img/bj/bj (4).png" title="description goes here" />
                    </a>
                </li>
                <li>
                    <a href="#">
                    <img src="img/bj/bj1.jpg" title="with html, you can put  or any other element you want" />
                    </a>
                </li>
                <li>
                    <a href="#">
                    <img src="img/bj/bj3.jpg" title="description for this image" />
                    </a>
                </li>
                
            </ul>
        </div>
        <!-- demo结束 -->
    <!-- 底部 -->
    <footer>
        <div class="foot">
            <div class="foot-top">
                <div class="foot-top1">
                    <ul class="foot1">
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe608;</div>
                            <span>全场包邮</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe603;</div>
                            <span>百城速达</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe658;</div>
                            <span>7天无理由退货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe677;</div>
                            <span>15天免费换货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe6d8;</div>
                            <span>1年免费保修</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe619;</div>
                            <span>2300+线下体验店</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe683;</div>
                            <span>远程协助服务</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe656;</div>
                            <span>上门维修</span>
                        </a></li>
                        
                    </ul>
                </div>
                <div class="foot-top2">
                    <div class="hour">24小时服务热线</div>
                    <div class="hour1">400-788-3333</div>
                    <div class="call"><a href="">
                        <div class="iconfont">&#xe606;</div>
                        <span>在线客服</span>
                    </a></div>
                </div>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">了解我们</a></li>
                    <li class="our1"><a href="">加入我们</a></li>
                    <li class="our1"><a href="">联系我们</a></li>
                    <li class="our1"><a href="">朋友社区</a></li>
                    <li class="our1"><a href="">天猫旗舰店</a></li>
                    <li class="our1"><a href="">问题反馈</a></li>
                    <li class="our1"><a href="">线上销售授权名单公示</a></li>
                    <li class="our1"><a href="">中文/English</a></li>
                </ul>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">©2017 Meizu Telecom Equipment Co., Ltd. All rights reserved.     粤ICP备13003602号 合字B2-20170010 营业执照 法律声明  粤公网安备 44049102496009 号</a></li> 
                </ul>
            </div>
        </div>
    </footer>
    </body>
</html>
<script type="text/javascript">
	let next=0,now=0;
	let flag
	//////////////////////search////////////////////////////////
	let search=$('.search')
	let Totop=$('.Totop')
	$(window).scroll(function(){
		let st=document.body.scrollTop           //获取body超出浏览器部分的距离
		if(st>500){
			if(flag){
				flag=false
				search.animate({top:0})
				Totop.animate({right:10})
			}
		}else{
			if(!flag){
				flag=true
				search.animate({top:-85})
				Totop.animate({right:-80})
			}
		} 
		Totop.click(function(){                        //灰到顶部
			animate(document.body,{scrollTop:0})
		})
	})

	
	
    $(function(){    
   		$('#demo1').sliphover();
    })

  	$(document).ready(function() {
    	$('#coin-slider').coinslider();
 	});
</script>

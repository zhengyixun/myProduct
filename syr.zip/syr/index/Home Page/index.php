<?php
include "../../public/path.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="css/index.css">
        <title>网站首页</title>
        <link rel="stylesheet" type="text/css" href="<?php echo $url1;?>/Home Page/Fontt/iconfont.css"/>
        <script type="text/javascript" src="<?php echo $url1;?>/Home Page/jQuery/jquery-3.2.1.js"></script>
        <script src="<?php echo $url1;?>/Home Page/js/index.js"></script>
        <script src="<?php echo $url1;?>/Home Page/js/animate.js"></script>
        <link rel="shortcut icon" href="favicon.ico"/>
    </head>
    <style>
        .nav-right1 a{color: #fff;font-size: 15px}
    </style>
    <body>
    <!-- 搜索框 -->
    <div class="search">
        <div class="serach1">
            <input type="text" class="sea" placeholder="请输入要搜索的宝贝">
            <div class="sea1 iconfont icon-sousuo"></div>
        </div>
    </div>
    <div class="Totop iconfont icon-top1"></div>
    <!-- 头部 -->
    <header>
    	<div class="head">
    		<div class="head-left"><img src="img/Logo_03.png" alt=""></div>
    		<div class="head-right">
    			<ul class="h">
                    <?php
                    include "../../public/db.php";
                    $sql="select * from category WHERE pid=0";
                    $result=$db->query($sql);
                    $result->setFetchMode(PDO::FETCH_ASSOC);
                    while($row=$result->fetch()){
                        ?>
                        <li class="h1"><a href="<?php echo $row['link']?>"><?php echo $row['cname'];?></a></li>
                        <?php
                    }
                    ?>
    			</ul>
    		</div>
    	</div>
    </header>
    <!-- banner -->
    <section class="banner">
    	<div class="banner-m">
        <!-- 文字 -->
    	<!-- 轮播点 -->
    		<div class="lunbo"><a><</a></div>
    		<div class="lunbo1"><a>></a></div>
            <?php
            include "../../public/db.php";
            $result=$db->query("select * from shows WHERE cid=9");
            $result->setFetchMode(PDO::FETCH_ASSOC);
            while ($row=$result->fetch()){
                ?>
                <div class="imgBox"><img src="../../admin/<?php echo $row['simage'];?>" alt=""></div>
                <?php
            }
            ?>
    		<div class="banner-nav1"></div>
    		<div class="banner-nav">
    			<div class="nav-left"><a href="">分类</a></div>
    			<div class="nav-m">
    				
    			</div>
    			<div class="nav-right">
                    <div class="nav-right1">
                        <a href="../../admin/login.php">管理员登录</a>
                    </div>
    			</div>
    		</div>

    	</div>
    </section>
    <!-- 这里有你想要的 -->
    <section class="want">
        <div class="want-t">
            <ul class="Want">
                <?php
                include "../../public/db.php";
                $result1=$db->query("select * from shows WHERE cid=11");
                $result1->setFetchMode(PDO::FETCH_ASSOC);
                while ($row1=$result1->fetch()){
                    ?>
                    <li class="Want1"><img src="../../admin/<?php echo $row1['simage']?>" alt=""></li>
                    <?php
                }
                ?>
            </ul>
            <ul class="Want">
                <?php
                $result1=$db->query("select * from shows WHERE cid=12");
                $result1->setFetchMode(PDO::FETCH_ASSOC);
                while ($row1=$result1->fetch()) {
                    ?>
                    <li class="Want1"><img src="../../admin/<?php echo $row1['simage']?>" alt=""></li>
                    <?php
                }
                ?>
            </ul>
            <ul class="Want">
                <?php
                $result1=$db->query("select * from shows WHERE cid=13");
                $result1->setFetchMode(PDO::FETCH_ASSOC);
                while ($row1=$result1->fetch()) {
                    ?>
                    <li class="Want1"><img src="../../admin/<?php echo $row1['simage']?>" alt=""></li>
                    <?php
                }
                ?>
            </ul>
            <ul class="Want">
                <?php
                $result1=$db->query("select * from shows WHERE cid=14");
                $result1->setFetchMode(PDO::FETCH_ASSOC);
                while ($row1=$result1->fetch()) {
                    ?>
                    <li class="Want1"><img src="../../admin/<?php echo $row1['simage']?>" alt=""></li>
                    <?php
                }
                ?>
            </ul>
        </div>
        <div class="want-m">
            <?php
            $result2=$db->query("select * from shows WHERE sid=31");
            $result2->setFetchMode(PDO::FETCH_ASSOC);
            $row2=$result2->fetch()
            ?>
            <div class="want-left"><img src="../../admin/<?php echo $row2['simage'];?>" alt="" /></div>

            <?php
            $result2=$db->query("select * from shows WHERE sid=32");
            $result2->setFetchMode(PDO::FETCH_ASSOC);
            $row2=$result2->fetch()
            ?>
            <div class="want-right1"><?php echo $row2['scon']?></div>
            <?php
            $result2=$db->query("select * from shows WHERE stitle='right2'");
            $result2->setFetchMode(PDO::FETCH_ASSOC);
            while($row2=$result2->fetch()){
                ?>
                <div class="want-right2"><?php echo $row2['scon'];?></div>
                <?php
            }
            ?>
        	<div class="want-btn">
        		<div class="want-btn1">Read More</div>
        	</div>
        </div>
    </section>
    <!-- 新鲜蔬果 -->
    <div class="vegetable">
        <a href=""><img src="img/dt/dt.png" alt=""></a>
        <div class="veget-left">
        	<div class="vleft"><span class="just">JUST TRY IT</span></div>
        </div>
         <div class="veget-right">
         	<div class="vright"><span class="just">JUST DO IT</span></div>
         </div>
    </div>
    <div class="newpro">OUR NEW PRODUCT</div>
    <div class="Pic">
        <?php
        $result3=$db->query("select * from shows WHERE cid=20");
        $result3->setFetchMode(PDO::FETCH_ASSOC);
        while ($row3=$result3->fetch()){
            ?>
            <div class="pic">
                <img src="../../admin/<?php echo $row3['simage'];?>"/>
                <div class="zpic">
                    <h3>NEW PRODUCT</h3>
                    <h4>Read More</h4>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
<!--a-->
	<div class="bigbox">
		<div class="tc iconfont icon-guanbi"></div>
		<div class="smallbox"><img /></div>
	</div>
    <!-- 时尚手机 -->
    <div class="vegetable">
        <a href=""><img src="img/dt/dt1.png" alt=""></a>
        <div class="veget-left">
        	<div class="vleft"><span class="just">PLAE BELIEVE</span></div>
        </div>
         <div class="veget-right">
         	<div class="vright"><span class="just">WE ARE BEST</span></div>
         </div>
    </div>
    <div class="newpro">POPULAR PRODUCT</div>
    <div class="phone">
        <div class="phone-left"><img src="img/hand/hand (1).jpg" alt="" /></div>
        <div class="phone-right">
        	<div class="right-top1 rt">
        		<img src="img/ciqi/ciqi1 (15).jpg" alt="" />
        		<div class="rt1">
        			<span>HOT PRODUCT</span>
        			<div class="hot1">
        				<div class="h4">Read</div>
        			</div>
        		</div>
        	</div>
            <div class="right-top2 rt">
            	<img src="img/hand/hand (9).jpg" alt="" />
            	<div class="rt1">
            		<span>HOT PRODUCT</span>
        			<div class="hot1">
        				<div class="h4">Read</div>
        			</div>
            	</div>
            </div>
            <div class="right-top3 rt">
            	<img src="img/ciqi/ciqi1 (6).jpg" alt="" />
            	<div class="rt1">
            		<span>HOT PRODUCT</span>
        			<div class="hot1">
        				<div class="h4">Read</div>
        			</div>
            	</div>
            </div>
            <div class="right-top4 rt">
            	<img src="img/hand/hand (5).jpg" alt="" />
            	<div class="rt1">
            		<span>HOT PRODUCT</span>
        			<div class="hot1">
        				<div class="h4">Read</div>
        			</div>
            	</div>
            </div>
        </div>
    </div>
    <div class="phone-bot">
        <div class="p-bot1"><img src="img/ciqi/ciqi1 (13).jpg" alt="" /></div>
        <div class="p-bot1"><img src="img/ciqi/ciqi1 (2).jpg" alt="" /></div>
        <div class="p-bot1"><img src="img/ciqi/ciqi1 (21).jpg" alt="" /></div>
    </div>
    <!-- 底部 -->
    <footer>
        <div class="foot">
            <div class="foot-top">
                <div class="foot-top1">
                    <ul class="foot1">
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe608;</div>
                            <span>全场包邮</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe603;</div>
                            <span>百城速达</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe658;</div>
                            <span>7天无理由退货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe677;</div>
                            <span>15天免费换货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe6d8;</div>
                            <span>1年免费保修</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe619;</div>
                            <span>2300+线下体验店</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe683;</div>
                            <span>远程协助服务</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe656;</div>
                            <span>上门维修</span>
                        </a></li>
                        
                    </ul>
                </div>
                <div class="foot-top2">
                    <div class="hour">24小时服务热线</div>
                    <div class="hour1">400-788-3333</div>
                    <div class="call"><a href="">
                        <div class="iconfont">&#xe606;</div>
                        <span>在线客服</span>
                    </a></div>
                </div>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">了解我们</a></li>
                    <li class="our1"><a href="">加入我们</a></li>
                    <li class="our1"><a href="">联系我们</a></li>
                    <li class="our1"><a href="">朋友社区</a></li>
                    <li class="our1"><a href="">天猫旗舰店</a></li>
                    <li class="our1"><a href="">问题反馈</a></li>
                    <li class="our1"><a href="">线上销售授权名单公示</a></li>
                    <li class="our1"><a href="">中文/English</a></li>
                </ul>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">©2017 Meizu Telecom Equipment Co., Ltd. All rights reserved.     粤ICP备13003602号 合字B2-20170010 营业执照 法律声明  粤公网安备 44049102496009 号</a></li> 
                </ul>
            </div>
        </div>
    </footer>
    </body>
</html>
<script type="text/javascript" src="js/pic.js"></script>
<?php
include "../../public/path.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>产品详情</title>
        <link rel="stylesheet" href="<?php echo $url1;?>/Home Page/css/xiangqing.css">
        <script type="text/javascript" src="<?php echo $url1;?>/Home Page/js/functions.js">
        <link rel="shortcut icon" href="<?php echo $url1;?>/Home Page/favicon.ico" />
        </script>
    </head>
    <body>
    <!-- 头部 -->
    <header>
    	<div class="head">
    		<div class="head-left"><img src="img/Logo_03.png" alt=""></div>
    		<div class="head-right">
    			<ul class="h">
                    <?php
                    include "../../public/db.php";
                    $sql="select * from category WHERE pid=0";
                    $result=$db->query($sql);
                    $result->setFetchMode(PDO::FETCH_ASSOC);
                    while($row=$result->fetch()){
                        ?>
                        <li class="h1"><a href="<?php echo $row['link']?>"><?php echo $row['cname'];?></a></li>
                        <?php
                    }
                    ?>
    			</ul>
    		</div>
    	</div>
    </header>
    <!-- banner -->
    <section class="banner">
    	<div class="banner-m">
            <div class="banner-m1"><img src="img/dt/m.jpg" alt=""></div>
    	</div>
    </section>
<!--详情-->
<div class="puc">
	<div class="puc-left"><img src="img/ganhua/ganhua1 (6).jpg"/></div>
	<div class="puc-right">
		<div class="Name">手工瓷器</div>
		<div class="Mon">估价： <b>199</b></div>
		<div class="pinglun">
			<div class="pinglun1">评论：400条</div>
			<div class="pinglun1">收藏：999+</div>
		</div>
		<div class="buy">
			<span>购买数量</span>
			<input type="text" placeholder="1" />
		</div>
		<div class="btn">加入购物车</div>
		<div class="btn">立即购买</div>
	</div>
</div>

<div class="js">
	<div class="js1">作品详情</div>
	<div class="js1">交流讨论（999+）</div>
	<div class="js1">留言区</div>
</div>
<div class="xq">
	<div class="xq-m">
	<div class="xq1"><img src="img/ganhua/ganhua1 (6).jpg" alt="" /></div>
	<div class="xq1">
		<pre>		<b>制作瓷器的完整流程，经过如下工序。</b>
	练泥：将瓷胎的原料磨洗、除杂揉匀后，调和成瓷泥。
	制坯：经过模具，将瓷泥制成所需要的瓷器外形，坯胎凉干
	上釉：圆口瓷器将瓷胎浸泡在釉浆中。
	釉下彩：将颜料直接涂在未上釉的瓷胎上，再进行上釉。
	釉上彩：将未上色的瓷胎涂釉后放入窑内烧结为素瓷，
			待冷却后再进行上色，进行二次烧结。
		</pre>
		<pre>		<b>制作瓷器的完整流程，经过如下工序。</b>
	练泥：将瓷胎的原料磨洗、除杂揉匀后，调和成瓷泥。
	制坯：经过模具，将瓷泥制成所需要的瓷器外形，坯胎凉干
	上釉：圆口瓷器将瓷胎浸泡在釉浆中。
	釉下彩：将颜料直接涂在未上釉的瓷胎上，再进行上釉。
	釉上彩：将未上色的瓷胎涂釉后放入窑内烧结为素瓷，
			待冷却后再进行上色，进行二次烧结。
		</pre>
	</div>
	</div>
	<div class="xq-m">
	
	<div class="xq1">
		<pre>		<b>制作瓷器的完整流程，经过如下工序。</b>
	练泥：将瓷胎的原料磨洗、除杂揉匀后，调和成瓷泥。
	制坯：经过模具，将瓷泥制成所需要的瓷器外形，坯胎凉干
	上釉：圆口瓷器将瓷胎浸泡在釉浆中。
	釉下彩：将颜料直接涂在未上釉的瓷胎上，再进行上釉。
	釉上彩：将未上色的瓷胎涂釉后放入窑内烧结为素瓷，
			待冷却后再进行上色，进行二次烧结。
		</pre>
		<pre>		<b>制作瓷器的完整流程，经过如下工序。</b>
	练泥：将瓷胎的原料磨洗、除杂揉匀后，调和成瓷泥。
	制坯：经过模具，将瓷泥制成所需要的瓷器外形，坯胎凉干
	上釉：圆口瓷器将瓷胎浸泡在釉浆中。
	釉下彩：将颜料直接涂在未上釉的瓷胎上，再进行上釉。
	釉上彩：将未上色的瓷胎涂釉后放入窑内烧结为素瓷，
			待冷却后再进行上色，进行二次烧结。
		</pre>
	</div>
	<div class="xq1"><img src="img/ganhua/ganhua1 (6).jpg" alt="" /></div>
	</div>
	<!--評論-->
	<div class="pl">
		<div class="pl-t">
			<div class="pl-t1">好评度<b>100%</b></div>
			<div class="manyi">很不满意</div>
			<div class="manyi">不满意</div>
			<div class="manyi">一般</div>
			<div class="manyi">满意</div>
			<div class="manyi">很满意</div>
		</div>
		
		<div class="pl-m">
			<div class="pl-m1"><img src="img/ciqi/ciqi1 (9).jpg" alt="" /></div>
			<div class="nam">张三</div>
			<div class="dat">2017-08-27</div>
			<div class="neirong">啊啊啊啊啊啊啊</div>
		</div>
		<div class="pl-m">
			<div class="pl-m1"><img src="img/ganhua/ganhua1 (4).jpg" alt="" /></div>
			<div class="nam">张三</div>
			<div class="dat">2017-08-27</div>
			<div class="neirong">啊啊啊啊啊啊啊</div>
		</div>
		<div class="pl-m">
			<div class="pl-m1"><img src="img/ganhua/ganhua1 (4).jpg" alt="" /></div>
			<div class="nam">张三</div>
			<div class="dat">2017-08-27</div>
			<div class="neirong">啊啊啊啊啊啊啊</div>
		</div>
		<div class="pl-m">
			<div class="pl-m1"><img src="img/ganhua/ganhua1 (4).jpg" alt="" /></div>
			<div class="nam">张三</div>
			<div class="dat">2017-08-27</div>
			<div class="neirong">啊啊啊啊啊啊啊</div>
		</div>
		<div class="pl-m">
			<div class="pl-m1"><img src="img/ganhua/ganhua1 (4).jpg" alt="" /></div>
			<div class="nam">张三</div>
			<div class="dat">2017-08-27</div>
			<div class="neirong">啊啊啊啊啊啊啊</div>
		</div>
		<div class="pl-m">
			<div class="pl-m1"><img src="img/ganhua/ganhua1 (4).jpg" alt="" /></div>
			<div class="nam">张三</div>
			<div class="dat">2017-08-27</div>
			<div class="neirong">啊啊啊啊啊啊啊</div>
		</div>
	</div>
	<!--留言板-->
	<div class="lyb big">
		<!-- top -->
    <div class="top">留言区</div>
	<div class="xingming">
		<textarea name="" id="namee" cols="30" rows="10" placeholder="请输入您的姓名"></textarea>
		<input type="date" class="riqi" placeholder="请输入日期">
	</div>
	<div class="tex">
		<textarea name="" placeholder="请说点什么吧" id="text" cols="30" rows="10" maxlength="120" minlength="5"></textarea>	
		<div class="box">还可以输入120个字</div>
	</div>
	<div class="tijiao">提 交</div>
		
	<div class="main">
		<div class="main1">
			<div class="imgbox"><img src="img/a.jpg" alt=""></div>
			<p>这是默认的张三</p>
			<div class="date">2017-08-21</div>
			<div class="word">生活愉快</div>
		</div>
	</div>
	</div>
	
</div>
    <!-- 底部 -->
    <footer>
        <div class="foot">
            <div class="foot-top">
                <div class="foot-top1">
                    <ul class="foot1">
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe608;</div>
                            <span>全场包邮</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe603;</div>
                            <span>百城速达</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe658;</div>
                            <span>7天无理由退货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe677;</div>
                            <span>15天免费换货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe6d8;</div>
                            <span>1年免费保修</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe619;</div>
                            <span>2300+线下体验店</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe683;</div>
                            <span>远程协助服务</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe656;</div>
                            <span>上门维修</span>
                        </a></li>
                        
                    </ul>
                </div>
                <div class="foot-top2">
                    <div class="hour">24小时服务热线</div>
                    <div class="hour1">400-788-3333</div>
                    <div class="call"><a href="">
                        <div class="iconfont">&#xe606;</div>
                        <span>在线客服</span>
                    </a></div>
                </div>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">了解我们</a></li>
                    <li class="our1"><a href="">加入我们</a></li>
                    <li class="our1"><a href="">联系我们</a></li>
                    <li class="our1"><a href="">朋友社区</a></li>
                    <li class="our1"><a href="">天猫旗舰店</a></li>
                    <li class="our1"><a href="">问题反馈</a></li>
                    <li class="our1"><a href="">线上销售授权名单公示</a></li>
                    <li class="our1"><a href="">中文/English</a></li>
                </ul>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">©2017 Meizu Telecom Equipment Co., Ltd. All rights reserved.     粤ICP备13003602号 合字B2-20170010 营业执照 法律声明  粤公网安备 44049102496009 号</a></li> 
                </ul>
            </div>
        </div>
    </footer>
    </body>
</html>
<script>
	/* 
	剩余字数 总数-输入
	          120 str.length
	1.获取字数 value/innertext
	2.>120 maxlength 最大长度   <10
	3.提交 shift+enter e.shiftKey e.keyCode==13
		①.文本域保存并清空
		②.插入

		ele=document.createElement()
		ele.innerText
	*/
window.onload=function(){
	let textarea=document.querySelector('#text')
	let box =document.querySelector('.box')
	let max=120
	let main=document.querySelector('.main')
	let namee=document.querySelector('#namee')
	let dat=document.querySelector('.riqi')


	textarea.onkeyup=function(){
		let str=textarea.value
		box.innerText=`还可以输入${max-str.length}个字`
	}

	textarea.onkeydown=function(e){
		if(e.shiftKey&&e.keyCode==13){
			let val=textarea.value
			let namm=namee.value
			let datt=dat.value
			textarea.value=''
			let main1=document.createElement('div')
			main1.innerHTML=`
							<div class="main1">
								<div class="imgbox"><img src="img/a.jpg" alt=""></div>
			
								<p>${namm}</p>
								<div class="date">${datt}</div>
								<div class="word">${val}</div>
							</div>
							`
				main.prependChild(main1)	
		}
	}

	let tijiao=document.querySelector('.tijiao')
	tijiao.onclick=function(){
		let val=textarea.value
			let namm=namee.value
			let datt=dat.value
			textarea.value=''
			
		let main1=document.createElement('div')
			main1.innerHTML=`
							<div class="main1">
								<div class="imgbox"><img src="img/a.jpg" alt=""></div>
								<p>${namm}</p>
								<div class="date">${datt}</div>
								<div class="word">${val}</div>
							</div>
							`
			main.prependChild(main1)
			namm=''
			datt=""
	}
//dianji

let pl=document.querySelector('.pl')
let lyb=document.querySelector('.lyb')
let xq=document.querySelectorAll('.xq-m')

let js1=document.querySelectorAll('.js1')
console.log(js1)
js1[0].onclick=function(){
	xq[0].style.display='block'
	xq[1].style.display='block'
	pl.style.display='none'
	lyb.style.display='none'
}
js1[1].onclick=function(){
	xq[0].style.display='none'
	xq[1].style.display='none'
	pl.style.display='block'
	lyb.style.display='none'
}
js1[2].onclick=function(){
	xq[0].style.display='none'
	xq[1].style.display='none'
	pl.style.display='none'
	lyb.style.display='block'
}
}
</script>

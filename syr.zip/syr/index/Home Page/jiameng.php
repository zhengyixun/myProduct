<?php
include "../../public/path.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>加盟查询</title>
        <link rel="stylesheet" href="<?php echo $url1;?>/Home Page/css/jiameng.css">
         <link rel="shortcut icon" href="favicon.ico?" />
    </head>
    <body>
    <!-- 头部 -->
    <header>
    	<div class="head">
    		<div class="head-left"><img src="img/Logo_03.png" alt=""></div>
    		<div class="head-right">
    			<ul class="h">
                    <?php
                    include "../../public/db.php";
                    $sql="select * from category WHERE pid=0";
                    $result=$db->query($sql);
                    $result->setFetchMode(PDO::FETCH_ASSOC);
                    while($row=$result->fetch()){
                        ?>
                        <li class="h1"><a href="<?php echo $row['link']?>"><?php echo $row['cname'];?></a></li>
                        <?php
                    }
                    ?>
    			</ul>
    		</div>
    	</div>
    </header>
    <!-- banner -->
    <section class="banner">
    	<div class="banner-m">
            <div class="banner-m1"><img src="img/dt/jiamng1.jpg" alt=""></div>
    	</div>
    </section>
    <!--jiameng-->
   <section class="join">
   	<div class="kefu">
   	<div class="kefu1">
   			<div class="kefu1-1">24小时在线</div>
   			<div class="men">
   				<div class="Q"><img src="img/JIA.png"/></div>
   				<span>唐三彩</span>
   			</div>
   			<div class="men">
   				<div class="Q"><img src="img/JIA.png"/></div>
   				<span>无花瓷</span>
   			</div>
   			<div class="men">
   				<div class="Q"><img src="img/zhong.png"/></div>
   				<span>工作时间</span>
   			</div>
   			<div class="men">   			
   				<span>周一至周五:8:30-18:00</span>
   			</div>
   			<div class="men">
   				<span>周六至周日:9:00-17:00</span>
   			</div>
   	</div>

   		<div class="kefu1">
   			<div class="kefu1-1">24小时在线</div>
   			<div class="men">
   				<div class="Q"><img src="img/JIA.png"/></div>
   				<span>唐三彩</span>
   			</div>
   			<div class="men">
   				<div class="Q"><img src="img/JIA.png"/></div>
   				<span>无花瓷</span>
   			</div>
   			<div class="men">
   				<div class="Q"><img src="img/zhong.png"/></div>
   				<span>工作时间</span>
   			</div>
   			<div class="men">   			
   				<span>周一至周五:8:30-18:00</span>
   			</div>
   			<div class="men">
   				<span>周六至周日:9:00-17:00</span>
   			</div>
   		</div>
   	</div>
	<div class="pic"><img src="img/taoci4.jpg"/></div>
	<div class="tex">
		<p><b>清代生产“彩瓷”，图样新颖，瓷色华贵</b><br>以“珐琅瓷”、“粉彩”杰出，
			又有“天青釉”，仿拟五代柴窑瓷色，还有霁红瓷和霁青瓷等。现在
			著名瓷器产地有：江西景德镇，以青花瓷、青花玲珑瓷、颜色釉瓷
			和粉彩瓷闻名。河北唐山、山西长治、广州石湾都能采用传统工艺
			及现代化技术设备，烧制各种各色瓷器。此外，还有河南禹县的钧
			瓷、湖南醴陵的红瓷、临汝的汝瓷，浙江龙泉的青瓷等</p>
	</div>
   </section>
   <section class="from">
   	<div class="tishi">*如果需要合作请填写以下表单，我们会尽快给您回复，并为您提供优质服务，谢谢您的支持</div>
   	<div class="from-m">
   		<div class="from1">
   			<span>姓名:</span>
   			<input type="text" placeholder="请输入您的姓名"/>
   		</div>
   		<div class="from1">
   			<span>电话:</span>
   			<input type="text" placeholder="请输入您的电话"/>
   		</div>
   		<div class="from1">
   			<span>邮箱:</span>
   			<input type="text" placeholder="请输入您的E-mail"/>
   		</div>
   		<div class="from1">
   			<span>地址:</span>
   			<input type="text" placeholder="请输入您的地址"/>
   		</div>
   		<div class="from1">
   			<span>时间:</span>
   			<input type="text" placeholder="请输入您希望联系的时间"/>
   		</div>
   		<div class="beizhu">
   			<span>备注:</span>
   			<textarea name="" rows="" cols="" placeholder="请输入您的备注"></textarea>
   		</div>
   		<div class="from1-1">
   			<span>购买方式:</span>
   			<span>批发：</span><input type="checkbox" id="xu" >
   			<span>零食：</span><input type="checkbox" id="xu"/>
   		</div>
   		
   		 	<div class="tijiao">提 交</div>
   	</div>
  
   </section>
    <!-- 底部 -->
    <footer>
        <div class="foot">
            <div class="foot-top">
                <div class="foot-top1">
                    <ul class="foot1">
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe608;</div>
                            <span>全场包邮</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe603;</div>
                            <span>百城速达</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe658;</div>
                            <span>7天无理由退货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe677;</div>
                            <span>15天免费换货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe6d8;</div>
                            <span>1年免费保修</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe619;</div>
                            <span>2300+线下体验店</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe683;</div>
                            <span>远程协助服务</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe656;</div>
                            <span>上门维修</span>
                        </a></li>
                        
                    </ul>
                </div>
                <div class="foot-top2">
                    <div class="hour">24小时服务热线</div>
                    <div class="hour1">400-788-3333</div>
                    <div class="call"><a href="">
                        <div class="iconfont">&#xe606;</div>
                        <span>在线客服</span>
                    </a></div>
                </div>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">了解我们</a></li>
                    <li class="our1"><a href="">加入我们</a></li>
                    <li class="our1"><a href="">联系我们</a></li>
                    <li class="our1"><a href="">朋友社区</a></li>
                    <li class="our1"><a href="">天猫旗舰店</a></li>
                    <li class="our1"><a href="">问题反馈</a></li>
                    <li class="our1"><a href="">线上销售授权名单公示</a></li>
                    <li class="our1"><a href="">中文/English</a></li>
                </ul>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">©2017 Meizu Telecom Equipment Co., Ltd. All rights reserved.     粤ICP备13003602号 合字B2-20170010 营业执照 法律声明  粤公网安备 44049102496009 号</a></li> 
                </ul>
            </div>
        </div>
    </footer>
    </body>
</html>
<script type="text/javascript">
	window.onload=function(){
		let tijiao=document.querySelector('.tijiao')
		tijiao.onclick=function(){
			confirm("确认提交吗？")
		}
	}
</script>
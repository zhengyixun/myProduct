<?php
include "../../public/path.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>品牌溯源</title>
        <link rel="stylesheet" href="<?php echo $url1;?>/Home Page/css/pinpai.css">
        <link rel="shortcut icon" href="favicon.ico" />
    </head>
    <body>
    <!-- 头部 -->
    <header>
    	<div class="head">
    		<div class="head-left"><img src="img/Logo_03.png" alt=""></div>
    		<div class="head-right">
    			<ul class="h">
                    <?php
                    include "../../public/db.php";
                    $sql="select * from category WHERE pid=0";
                    $result=$db->query($sql);
                    $result->setFetchMode(PDO::FETCH_ASSOC);
                    while($row=$result->fetch()){
                        ?>
                        <li class="h1"><a href="<?php echo $row['link']?>"><?php echo $row['cname'];?></a></li>
                        <?php
                    }
                    ?>
    			</ul>
    		</div>
    	</div>
    </header>
    <!-- banner -->
    <section class="banner">
    	<div class="banner-m">
            <div class="banner-m1"><img src="img/dt/pinpai.jpg" alt=""></div>
    	</div>
    </section>
   <!-- 实体店 -->
   <div class="store">
       <div class="store1">品牌溯源</div>
       <div class="store1">NFORMATION CENTER</div>
   </div>
    <div class="news">
    	<div class="news1">品牌溯源</div>
    </div>
   <div class="pp">
       <?php
       $result1=$db->query("select * from shows WHERE cid=31");
       $result2=$db->query("select * from shows WHERE cid=32");
       $result1->setFetchMode(PDO::FETCH_ASSOC);
       $result2->setFetchMode(PDO::FETCH_ASSOC);
       $row1=$result1->fetch();
       $row2=$result2->fetch();
       ?>
       <h2><?php echo $row1['scon'];?></h2>
       <p><?php echo $row2['scon'];?></p>

       <h2><?php echo $row1['scon'];?></h2>
       <p><?php echo $row2['scon'];?></p>

       <h2><?php echo $row1['scon'];?></h2>
       <p><?php echo $row2['scon'];?></p>

       <h2><?php echo $row1['scon'];?></h2>
       <p><?php echo $row2['scon'];?></p>

       <h2><?php echo $row1['scon'];?></h2>
       <p><?php echo $row2['scon'];?></p>

       <h2><?php echo $row1['scon'];?></h2>
       <p><?php echo $row2['scon'];?></p>
   </div>
    <!-- 底部 -->
    <footer>
        <div class="foot">
            <div class="foot-top">
                <div class="foot-top1">
                    <ul class="foot1">
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe608;</div>
                            <span>全场包邮</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe603;</div>
                            <span>百城速达</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe658;</div>
                            <span>7天无理由退货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe677;</div>
                            <span>15天免费换货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe6d8;</div>
                            <span>1年免费保修</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe619;</div>
                            <span>2300+线下体验店</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe683;</div>
                            <span>远程协助服务</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe656;</div>
                            <span>上门维修</span>
                        </a></li>
                        
                    </ul>
                </div>
                <div class="foot-top2">
                    <div class="hour">24小时服务热线</div>
                    <div class="hour1">400-788-3333</div>
                    <div class="call"><a href="">
                        <div class="iconfont">&#xe606;</div>
                        <span>在线客服</span>
                    </a></div>
                </div>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">了解我们</a></li>
                    <li class="our1"><a href="">加入我们</a></li>
                    <li class="our1"><a href="">联系我们</a></li>
                    <li class="our1"><a href="">朋友社区</a></li>
                    <li class="our1"><a href="">天猫旗舰店</a></li>
                    <li class="our1"><a href="">问题反馈</a></li>
                    <li class="our1"><a href="">线上销售授权名单公示</a></li>
                    <li class="our1"><a href="">中文/English</a></li>
                </ul>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">©2017 Meizu Telecom Equipment Co., Ltd. All rights reserved.     粤ICP备13003602号 合字B2-20170010 营业执照 法律声明  粤公网安备 44049102496009 号</a></li> 
                </ul>
            </div>
        </div>
    </footer>
    </body>
</html>
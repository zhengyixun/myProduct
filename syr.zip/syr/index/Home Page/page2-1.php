<?php
include "../../public/path.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>最新推出</title>
        <link rel="stylesheet" href="<?php echo $url1;?>/Home Page/css/page2-1.css">
        <link rel="stylesheet" type="text/css" href="<?php echo $url1;?>/Home Page/Fontt/iconfont.css"/>
        <script type="text/javascript" src="<?php echo $url1;?>/Home Page/jQuery/jquery-3.2.1.js"></script>
        <script src='<?php echo $url1;?>/Home Page/js/animate.js'></script>
        <script type="text/javascript" src="<?php echo $url1;?>/Home Page/js/coin-slider.js"></script>
		<link rel="stylesheet" type="text/css" href="<?php echo $url1;?>/Home Page/css/coin-slider-styles.css"/>
        <link rel="shortcut icon" href="favicon.ico" />
    </head>
    <body>
        <!-- 搜索框 -->
   <div class="search">
        <div class="serach1">
            <input type="text" class="sea" placeholder="请输入要搜索的宝贝">
            <div class="sea1 iconfont icon-sousuo"></div>
        </div>
    </div>
    <div class="Totop iconfont icon-top1"></div>
    <!-- 头部 -->
    <header>
    	<div class="head">
    		<div class="head-left"><img src="img/Logo_03.png" alt="" /></div>
    		<div class="head-right">
    			<ul class="h">
                    <?php
                    include "../../public/db.php";
                    $sql="select * from category WHERE pid=0";
                    $result=$db->query($sql);
                    $result->setFetchMode(PDO::FETCH_ASSOC);
                    while($row=$result->fetch()){
                        ?>
                        <li class="h1"><a href="<?php echo $row['link']?>"><?php echo $row['cname'];?></a></li>
                        <?php
                    }
                    ?>
    			</ul>
    		</div>
    	</div>
    </header>
    <!-- banner -->
    <section class="banner">
    	<div class="banner-m">
    	<!-- 轮播点 -->
    	<div id='coin-slider'>
            <?php
            $result0=$db->query("select * from shows WHERE cid=15");
            $result0->setFetchMode(PDO::FETCH_ASSOC);
            while ($row0=$result0->fetch()){
                ?>
                <a href="#"><img src="../../admin/<?php echo $row0['simage'];?>" alt=""></a>
                <?php
            }
            ?>
		</div>

    		<div class="banner-nav1"></div>
    		<div class="banner-nav">
    			<div class="nav-left"><a href="">A L L</a></div>
    			<div class="nav-m">
    				
    			</div>
    			<div class="nav-right">
    				<div class="nav-right1">立 即 查 看</div>
    			</div>
    		</div>

    	</div>
    
    </section>
        <!-- 副banner -->
        <div class="fubanner">
            <div class="fubanner1">
                <div class="ba-one ba-one0">
                    <div class="ba-one1"><a href="">
                        <div class="iconfont">&#xe677;</div>
                        <span>免码通道</span>
                    </a></div>
                    <div class="ba-one1"><a href="">
                        <div class="iconfont">&#xe658;</div>
                        <span>以旧换新</span>
                    </a></div>
                    <div class="ba-one1"><a href="">
                        <div class="iconfont">&#xe659;</div>
                        <span>回执单页</span>
                    </a></div>
                    <div class="ba-one1"><a href="">
                        <div class="iconfont">&#xe65a;</div>
                        <span>意外保险</span>
                    </a></div>
                    
                </div>  
                <div class="ba-one">
                    <a href=""><img src="img/taoqi/taoqi (2).jpeg" alt=""></a>
                </div> 
                <div class="ba-one">
                    <a href=""><img src="img/taoqi/taoqi (2).jpg" alt=""></a>
                </div> 
                <div class="ba-one">
                    <a href=""><img src="img/taoqi/taoqi (3).jpeg" alt=""></a>
                </div> 
                <div class="ba-one">
                    <a href=""><img src="img/taoqi/taoqi (4).jpg" alt=""></a>
                </div> 
                    
            </div>
        </div>
  
    <!-- 产品区 -->
    <!-- 手机 -->
    <section class="shouji">
        <div class="phone">
            <div class="phone-top">
                <ul class="top0">
                    <li class="top1"><a href="">手工陶器</a></li>
                    <li class="top2"><a href="">最新推出</a></li>
                    <li class="top3"><a href="">更 多 ></a></li>
                </ul>
            </div>
            <div class="phone-bot">
                <div class="phone-bot0"><a href=""><img src="img/taoqi/taoqi2 (3).jpg" alt=""></a></div>
               <?php
               $result=$db->query("select * from shows WHERE cid=25");
               $result->setFetchMode(PDO::FETCH_ASSOC);
               while ($row=$result->fetch()){
                   ?>
                   <div class="phone-bot1">
                       <a href="">
                           <div class="bot1-top"><img src="../../admin/<?php echo $row['simage'];?>" alt=""></div>
                           <div class="tex1">手工陶罐</div>
                           <div class="tex2">传承经典，精心打造</div>
                           <div class="tex2 tex3">呕心沥血倾心推出</div>
                       </a>
                   </div>
                   <?php
               }
               ?>
            </div>
            <div class="lang"><img src="img/lang3.png" alt=""></div>
        </div>
    </section>
    <!-- 手工瓷器 -->
    <section class="shouji">
        <div class="phone">
            <div class="phone-top">
                <ul class="top0">
                    <li class="top1"><a href="">手工瓷器</a></li>
                    <li class="top2"><a href="">最新推出</a></li>
                    <li class="top3"><a href="">更 多 ></a></li>
                </ul>
            </div>
            <div class="phone-bot">
                <div class="phone-bot0"><a href=""><img src="img/ciqi/ciqi1 (1).jpg" alt=""></a></div>
                <?php
                $result=$db->query("select * from shows WHERE cid=26");
                $result->setFetchMode(PDO::FETCH_ASSOC);
                while ($row=$result->fetch()){
                    ?>
                    <div class="phone-bot1">
                        <a href="">
                            <div class="bot1-top"><img src="../../admin/<?php echo $row['simage'];?>" alt=""></div>
                            <div class="tex1">这一件瓷器</div>
                            <div class="tex2">是一段故事，一段人生</div>
                            <div class="tex2 tex3">瓷器人生</div>
                        </a>
                    </div>
                    <?php
                }
                ?>
            </div>
            <div class="lang"><a href=""><img src="img/dt/lang3.png" alt=""></a></div>
        </div>
    </section>
    <!-- 唯美干花 -->
    <section class="shouji">
        <div class="phone">
            <div class="phone-top">
                <ul class="top0">
                    <li class="top1"><a href="">唯美干花</a></li>
                    <li class="top2"><a href="">最新推出</a></li>
                    <li class="top3"><a href="">更 多 ></a></li>
                </ul>
            </div>
            <div class="phone-bot">
                <div class="phone-bot0"><a href=""><img src="img/ganhua/ganhua1 (1).jpg" alt=""></a></div>
                <?php
                $result=$db->query("select * from shows WHERE cid=27");
                $result->setFetchMode(PDO::FETCH_ASSOC);
                while ($row=$result->fetch()){
                    ?>
                    <div class="phone-bot1">
                        <a href="">
                            <div class="bot1-top"><img src="../../admin/<?php echo $row['simage'];?>" alt=""></div>
                            <div class="tex1">这是一件瓷器</div>
                            <div class="tex2">是一段故事，一段人生</div>
                            <div class="tex2 tex3">故事和缘</div>
                        </a>
                    </div>
                    <?php
                }
                ?>
            </div>
                <div class="lang"><img src="img/dt/lang3.png" alt=""></div>
        </div>
    </section>
        <!-- b摆件 -->
    <section class="shouji">
        <div class="phone">
            <div class="phone-top">
                <ul class="top0">
                    <li class="top1"><a href="">精致摆件</a></li>
                    <li class="top2"><a href="">最新推出</a></li>
                    <li class="top3"><a href="">更 多 ></a></li>
                </ul>
            </div>
            <div class="phone-bot">
                <div class="phone-bot0"><a href=""><img src="img/ganhua/ganhua1 (1).jpg" alt=""></a></div>
                <?php
                $result=$db->query("select * from shows WHERE cid=28");
                $result->setFetchMode(PDO::FETCH_ASSOC);
                while ($row=$result->fetch()){
                    ?>
                    <div class="phone-bot1">
                        <a href="">
                            <div class="bot1-top"><img src="../../admin/<?php echo $row['simage'];?>" alt=""></div>
                            <div class="tex1">这是一件瓷器</div>
                            <div class="tex2">是一段故事，一段人生</div>
                            <div class="tex2 tex3">故事和缘</div>
                        </a>
                    </div>
                    <?php
                }
                ?>
            </div>
                <div class="lang"><img src="img/dt/lang3.png" alt=""></div>
        </div>
    </section>
    <!-- 底部 -->
    <footer>
        <div class="foot">
            <div class="foot-top">
                <div class="foot-top1">
                    <ul class="foot1">
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe608;</div>
                            <span>全场包邮</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe603;</div>
                            <span>百城速达</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe658;</div>
                            <span>7天无理由退货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe677;</div>
                            <span>15天免费换货</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe6d8;</div>
                            <span>1年免费保修</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe619;</div>
                            <span>2300+线下体验店</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe683;</div>
                            <span>远程协助服务</span>
                        </a></li>
                        <li class="foot2"><a href="">
                            <div class="iconfont">&#xe656;</div>
                            <span>上门维修</span>
                        </a></li>
                        
                    </ul>
                </div>
                <div class="foot-top2">
                    <div class="hour">24小时服务热线</div>
                    <div class="hour1">400-788-3333</div>
                    <div class="call"><a href="">
                        <div class="iconfont">&#xe606;</div>
                        <span>在线客服</span>
                    </a></div>
                </div>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">了解我们</a></li>
                    <li class="our1"><a href="">加入我们</a></li>
                    <li class="our1"><a href="">联系我们</a></li>
                    <li class="our1"><a href="">朋友社区</a></li>
                    <li class="our1"><a href="">天猫旗舰店</a></li>
                    <li class="our1"><a href="">问题反馈</a></li>
                    <li class="our1"><a href="">线上销售授权名单公示</a></li>
                    <li class="our1"><a href="">中文/English</a></li>
                </ul>
            </div>
            <div class="foot-bot">
                <ul class="our">
                    <li class="our1"><a href="">©2017 Meizu Telecom Equipment Co., Ltd. All rights reserved.     粤ICP备13003602号 合字B2-20170010 营业执照 法律声明  粤公网安备 44049102496009 号</a></li> 
                </ul>
            </div>
        </div>
    </footer>
    </body>
</html>
<script type="text/javascript">
	let next=0,now=0;
	let flag
	//////////////////////search////////////////////////////////
	let search=$('.search')
	let Totop=$('.Totop')
	$(window).scroll(function(){
		let st=document.body.scrollTop           //获取body超出浏览器部分的距离
		if(st>500){
			if(flag){
				flag=false
				search.animate({top:0})
				Totop.animate({right:10})
			}
		}else{
			if(!flag){
				flag=true
				search.animate({top:-85})
				Totop.animate({right:-80})
			}
		} 
		Totop.click(function(){                        //灰到顶部
			animate(document.body,{scrollTop:0})
		})
	})


  	$(document).ready(function() {
    	$('#coin-slider').coinslider();
 	});
</script>
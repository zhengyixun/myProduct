<?php
if(is_uploaded_file($_FILES["file"]["tmp_name"])){
    if(!is_dir("tmp")){
        mkdir("tmp");
    }
    //判断图片大小
    $size=1024*1024*88;
    if($_FILES["file"]["size"]>$size){
        echo "图片过大";
        exit;
    }
    //判断啊图片类型
    $type=array('image/png','image/jpeg','image/jpg','image/gif');
    if(!in_array($_FILES['file']['type'],$type)){  //如果不在数组里报错
        echo "图片格式错误";
        exit;
    }
    $name=mt_rand(1,999).$_FILES['file']['name'];
    move_uploaded_file($_FILES["file"]["tmp_name"],"../upload/tmp/".$name);
    echo "ok";
}
/*双通道验证
 *
 * 整个类，想象成电脑：内存条 主机 电脑 线路 显卡
 * public
 * 不需要用户操作，内部使用的定义成private（私有的），只允许内部调用，外部不可调用，
 * protected  受保护的，只允许内部调用
 *
 * class upload{
 *      public $name='zhangsan';
 * }
 * class stu extends upload{
 *      继承
 * }
 *
 * 构造函数 function __sonstruct(){}
 *          function 方法名和类名一样
 * 运算写在构造函数中
 * 1.接收accept()
 * 2.检查check()
 *      is_upload_file
 *          3.存储，创建目录 createDir
 *          4.移动到指定目录
 * 字符串处理方式：strchr（$str，“a”）
 *
 *
 *
 * */
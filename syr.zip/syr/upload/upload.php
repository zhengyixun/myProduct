<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="../admin/js/jquery-3.2.1.js"></script>
    <script src="up.js"></script>
    <title>try</title>
    <script>
        window.onload=function(){
            var upl=new upload();
            var parent= document.querySelector('.box');
            upl.createView({parent});
            upl.upl("server.php")
        }
    </script>
</head>
<style>
    /*.box{*/
        /*width: 100px;height: auto;*/
        /*margin-top: 10px;margin-bottom: 10px;*/
    /*}*/
    /*.list{*/
        /*width: 100px;height: 100px;border: 1px solid #cccccc;*/
    /*}*/
    /*img{*/
        /*width: 100%;height: 100%;*/
    /*}*/
    /*.progress{*/
        /*width: 100%;height: 5px;*/
        /*position: relative;*/
    /*}*/
    /*.back{*/
        /*height: 100%;width: 0;background: blue;*/
        /*position: absolute;top:0;left:0;*/
    /*}*/
    .box{
        width: auto;height: auto;
    }
</style>
<body>
<div class="box">

</div>
<!--<input type="file" name="file" multiple="multiple"/>-->
<!--<div class="box">-->
<!--    <div class="list">-->
<!--        <img src="" alt="">-->
<!--    </div>-->
<!--    <div class="progress">-->
<!--        <div class="back"></div>-->
<!--    </div>-->
<!--</div>-->
<!--<button type="button" >上传</button>-->
</body>
</html>
<script>
//    var file=document.querySelector("input[type=file]");
//    var btn=document.querySelector("button");
//    var filesize=1024*1024*88;
//    var type=['image/png','image/jpeg','image/jpg','image/gif'];
//    var flag=true;
//    var obj;
//    var xhr = new XMLHttpRequest();
//    var arr=['image/jpeg','image/jpg','image/png','image/gif'];
//    var progress=document.querySelector(".progress");
//
//    file.onchange=function(){
//        obj=this.files[0];   //获取到和php一样的图片信息
//        console.log(obj);
//        if(obj.size>filesize){
//            progress.innerHTML="文件过大";
//            xhr.abort();
//        }
//        if(obj.type!='image/jpeg'){
//            progress.innerHTML="文件格式错误";
//            xhr.abort();
//        }
//
//        var fr =new FileReader();
//        fr.readAsDataURL(obj);
//        fr.onload=function(e){
//            document.querySelector('img').src=(e.target.result);
//        };
//
//        xhr.onprogress=function(e){
//            var total=e.total;
//            var loaded=e.loaded;
//            var bili=loaded/total*100+"%";
//            document.querySelector(".back").style.width=bili;
//        };
//    };
//    btn.onclick=function(){
//        if(obj.size>filesize){
//            alert("上传失败");
//        }
//        if(obj.type!="image/jpeg"){
//            alert("上传失败");
//        }
//
//        xhr.onload = function () {
//            console.log(xhr.response)   //ajax输出什么浏览器得到什么
//        };
//        var formobj=new FormData();  //formdata对象可以手动组装成send所需要的格式 ”name=zhangsan&age=10“
//        formobj.append("file",obj);  //字符串类型
//        xhr.open("post", "1.php");
//        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;");  //设置请求头信息
//        xhr.send(formobj);
//    }



    /*
    * var obj=this.files[0];   //获取的图片信息
    * var fr = new fileReader()   创建能够解析文件信息的对象
    * fr.readAsDataURL(obj)       调用方法  利用提供的fileReader对象中的readAsDataURL解析成地址的方式
    *                             解析完成触发onload事件
    * files.onload=function(e){
    *   console.log(e.target.result) 通过实践对象中的target.result
    * }
    *
    * */

</script>

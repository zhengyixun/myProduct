<?php
header("content-type:text/html;charset=utf-8");
$db=new PDO("mysql:host=sqld.duapp.com;port=4050;dbname=dBGIKOaTBByvxRxMgHNd",'616c30dade164a4d945af6b4a7d23650','39d6b323bf8b4479941a12b6342100c9');
$db->query('set names utf8');
?>
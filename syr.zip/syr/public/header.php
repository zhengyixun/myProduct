<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    *{
        margin:0;padding: 0;
    }
    nav{width: 800px;height: 50px;margin: 20px auto;border: 1px solid #ccc;display: flex;
        justify-content: space-around;
        align-items: center;}
</style>
<body>
<?php
include "../public/db.php";
$sql="select * from category where pid=0";
$result=$db->query($sql);
$result->setFetchMode(PDO::FETCH_ASSOC);
?>
<nav>
    <a href="index.php">
        首页
    </a>
    <?php
    while ($row=$result->fetch()){
        if($row['state']==0){
            $url="list.php";
        }else{
            $url="category.php";
        }
     ?>
        <a href="<?php echo $url;?>?cid=<?php echo $row['cid']?>"><?php echo $row['cname']?></a>
        <?php
    }
    ?>
</nav>
<!--</body>-->
<!--</html>-->
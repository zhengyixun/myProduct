<?php
$url=$_SERVER['SCRIPT_NAME'];
$http=strtolower(substr($_SERVER['SERVER_PROTOCOL'],0,strrpos($_SERVER['SERVER_PROTOCOL'],"/")));

//var_dump($http);
$lo=$_SERVER['SERVER_NAME'];
$str=substr($url,0,strrpos($url,"/"));
$url1=$http.'://'.$lo.substr($str,0,strrpos($str,"/"));
?>
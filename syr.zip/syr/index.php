<?php
echo "<script>location.href='index/Home Page/index.php';</script>"
?>

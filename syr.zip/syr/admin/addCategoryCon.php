<?php
include "../public/db.php";
$cname=$_POST['cname'];
$pid=$_POST['pid'];
$link=$_POST['link'];
$sql="insert into category (cname,pid,state,link) VALUES ('{$cname}','{$pid}',0,'{$link}')";
if($db->exec($sql)){
    /*
    if($pid!=0){
    $sql="update categroy get state=1 where cid=".$pid
    if($db->exec($sql)){;

        }
    }
    *
     *     事务
    */
    if($pid!=0){
        $sql = "update category set state=1 WHERE cid=" . $pid;
        $db->exec($sql);
        echo "<script>alert('添加成功');location.href='addCategory.php'</script>";
    }else{
        echo "<script>alert('插入成功');location.href='addCategory.php'</script>";
    }
};

<?php
include "../public/db.php";
$aname=htmlspecialchars(addslashes($_POST['aname']));
$apass=md5($_POST['apass']);
$anicheng=$_POST['anicheng'];
$aphoto=$_POST['aphoto'];
$sql="insert into admin (`aname`,`apass`,`anicheng`,`aphoto`) VALUES ('{$aname}','{$apass}','{$anicheng}','{$aphoto}')";
//这一部分上传图片


$result=$db->exec($sql);

if($result){
    echo "<script>alert('插入成功');location.href='add.php'</script>";
}

/*if ($_FILES["aphoto"]["error"] > 0)
{
    echo "错误代码:" . $_FILES["aphoto"]["error"] . "<br/>";
}else{
    echo "Upload: " . $_FILES["aphoto"]["name"] . "<br/>";
    echo "Temp file: " . $_FILES["aphoto"]["tmp_name"] . "<br/>";

    if(file_exists("../upload".$_FILES["aphoto"]["name"])){
        echo $_FILES["aphoto"]["name"] . "已存在";
    }else{
        move_uploaded_file($_FILES["aphoto"]["tmp_name"],"../upload/". $_FILES["aphoto"]["name"]);
    }
}

魔术变量

文件上传流程
    某个目录下存放临时文件--->硬盘中
        为了安全，需要判断文件类型，关键信息，需要获取文件的信息，判断成功，再存到硬盘中。

1.post累心
2.设置编码格式
3.php中

is upload file 检测是不是用户上传的文件
move_uploaded_file  移动临时文件
mkdir("tem")   创建目录

if(is_uploaded_file($_FILES["aphoto"]["tmp_name"])){
    if(!is_dir("tmp")){
        mkdir("tmp")
    }
    move_uploaded_file($_FILES["aphoto"]["tmp_name"],“tmp/aa.jpg”)
}
 */
?>


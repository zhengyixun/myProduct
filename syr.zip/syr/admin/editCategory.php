<?php
include "../public/path.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo $url1;?>/admin/css/bootstrap.css">
    <title>editCategory</title>
</head>
<style>
    form{
        width: 500px;height:200px;margin: 100px auto;padding: 20px;
    }
</style>
<body>
<?php
include "../public/db.php";
$cid=$_GET['cid'];
$sql="select * from category WHERE cid='{$cid}'";
$result=$db->query($sql);
$result->setFetchMode(PDO::FETCH_ASSOC);
$row=$result->fetch();
?>
<form action="editCategoryCon.php" method="get">
    添加分类 <select  class="form-control" id="" name="pid">
        <option value="0">一级分类</option>
        <?php
        include "../public/db.php";
        include "../public/functions.php";
        $obj=new tree();
        $obj->aa("0",$db,"category",0," - ",$_GET["cid"]);
        echo $obj->str;
        $sql=$db->query("select * from category WHERE cid=".$_GET['cid']);
        $sql->setFetchMode(PDO::FETCH_ASSOC);
        $row=$sql->fetch();
        ?>
    </select>
    分类名称 <input type="text" name="cname" class="form-control" value="<?php echo $row['cname'];?>"><br>
    <input type="hidden" name="cid" value="<?php echo $_GET['cid'];?>">
    <input type="submit" value="修改" class="btn btn-info">
</form>
</body>
</html>
<?php
session_start();
$aid = $_GET['aid'];
$_SESSION["aid"]=$aid;
include "../public/path.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo $url1;?>/admin/css/bootstrap.css">
    <script src="<?php echo $url1;?>/admin/js/jquery-3.2.1.js"></script>
    <script src="<?php echo $url1;?>/admin/js/jquery.validate.min.js"></script>
    <script src="<?php echo $url1;?>/admin/js/up.js"></script>
    <title>editData</title>
</head>
<?php

include "../public/db.php";
$db->query('set names utf8');
$sql = "select * from admin WHERE aid=".$aid;
$result = $db->query($sql);
$result->setFetchMode(PDO::FETCH_ASSOC);
$row = $result->fetch();
?>
<body>
<form action="editDataCon.php" method="post" id="signupForm" enctype="multipart/form-data">
    <div class="form-group">
        <label for="exampleInputEmail1">姓名</label>
        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="姓名" name="aname" value="<?php echo $row['aname']; ?>">
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1" >密码</label>
        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="密码" name="apass">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1" >昵称</label>
        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="昵称" name="anicheng" value="<?php echo $row['anicheng']; ?>" >
    </div>
    <div class="form-group parent">
        <label for="exampleInputEmail1">头像</label>
        <div class="picture"><img src="<?php echo $row['aphoto'];?>" alt="">
            <input type="hidden" class="form-control btnn" id="exampleInputEmail1"  name="aphoto">
    </div>
    <button type="submit" class="btn btn-default">提交</button>

</form>
<style>
    label{
        height: 15px;
    }
    .error{
        color: red;
        font-size: 10px;
    }
    .picture img{width: 50px;height: 50px;}
</style>
<script>
    var upll=new upload();
    var btnn=document.querySelector('.btnn');
    var parent=document.querySelector('.parent');
    upll.createView({parent});
    upll.upl("uploadClass.php",function(e){
        var str=e.join(';');
        btnn.value +=str;
    });
    $("#signupForm").validate({
        rules:{
            aname: {
                required: true,
                minlength: 2
            },
        },
        messages:{
            aname:{
                required: "请输入姓名",
                minlength: "姓名长度不得小于2位",
            },
        },
    })
</script>
</body>
</html>
<?php
include "../public/db.php";
$cid=$_POST['cid'];
$stitle=$_POST['stitle'];
$scon=$_POST['scon'];
$simage=$_POST['simage'];
$sql="insert into shows (stitle,scon,simage,cid) VALUES ('{$stitle}','{$scon}','{$simage}','{$cid}')";
$result=$db->exec($sql);
if($sql){
    echo "<script>alert('添加成功');location.href='addCon.php';</script>";
}
?>
<?php
session_start();
include "../public/db.php";
$db->query("set names utf8");  //这句数据库中以中文格式读取
$aname=htmlspecialchars(addslashes($_POST['aname']));
$apass=md5($_POST['apass']);

$sql=$db->query("select * from admin WHERE aname = '{$aname}' and apass = '{$apass}'");

$sql->setFetchMode(PDO::FETCH_ASSOC);
$row=$sql->fetch();
$aid = $row['aid'];

if($sql->rowCount() > 0){            //PDO中使用rowCount()方法；返回受 DELETE、INSERT、 或 UPDATE 语句影响的行数。
    $_SESSION['login'] = 'yes';
    $message = "登录成功";
    $url = "CMS.php";
    $_SESSION['aname'] = $aname;
    include 'message.php';
}else{
    $message = "账号或密码错误";
    $url = "login.php";
    include 'message.php';
}
/*
 *
 * md5加密   无解密
 * js中字符串
 * 正则
 * 替换： preg_replace("/'/","\'","ab'c",1)
 *                    正则   替换成  要替换的字符串   个数
 *
 *
 * php中提供了htmlspecialchars("ab'c") 方法  最外层
 *             转义HTML标签
 *              addslashes()
 *
 * js  基于对象编程
 * php 基于函数编程
 *
 *
 * */
?>
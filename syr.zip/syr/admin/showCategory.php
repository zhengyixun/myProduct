<?php
session_start();
if(!isset($_SESSION["login"])){
    $message = "请登录";
    $url = "login.php";
    include 'message.php';
    exit();
}
include "../public/path.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo $url1;?>/admin/css/bootstrap.css">
    <title>showCategory</title>
</head>
<style>
    a{display: block;margin:10px;}
</style>
<body>
<?php
include "../public/db.php";
include "../public/functions.php";
$obj=new tree();
$obj->showtree(0,$db,'category');
echo $obj->str;
?>
</body>
</html>
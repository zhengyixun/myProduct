<?php
session_start();
if(!isset($_SESSION["login"])){
    $message = "请登录";
    $url = "login.php";
    include 'message.php';
    exit();
}
include "../public/path.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo $url1;?>/admin/css/bootstrap.css">
    <script src="<?php echo $url1;?>/admin/js/jquery-3.2.1.js"></script>
    <title>CMS</title>
</head>
<style>
    li a{
        list-style: none;
        text-decoration: none;
        color: #000;
    }
    a:hover{
        text-decoration: none;
        list-style: none;
        color: #ccc;
        transition: .3s;
    }
    body{
        overflow: hidden;
        font-family: "苹方";
    }
    .header{
        max-width: 1200px;
        height: 80px;
        border: 1px solid #777;
        text-align: center;
        line-height: 80px;
        margin-top: 40px;
        position: relative;
    }
    .bot{
        max-width: 1200px;
        height: 500px;
        border: 1px solid #777;
        border-top: 0;margin: 0 auto;
    }
    .left{
        border-right: 1px solid #777;
        height: 100%;
    }
    .right{
        padding-top: 10px;
        height: 490px;
    }
    iframe{
        width: 100%;
        height: 100%;
    }
    .out{
        position: absolute;
        right:50px;top:20px;
        font-size: 15px;
        font-family: "苹方";
    }
    .one{position: absolute;
        left:50px;top:20px;
        font-size: 15px;
        font-family: "苹方";}
    span{cursor: pointer;}
</style>
<body>

<div class="container header ">

    <h2>欢迎 <?php echo $_SESSION['aname'];?> 来到HP后台管理系统</h2>
    <a href="loginout.php" class="out">退出系统</a>
    <a href="../index/Home%20Page/index.php" class="one">查看首页</a>
</div>
<div class=" container bot">
    <div class="col-xs-4 left col-md-2">
        <ul class="new">
            <li>
                <span>管理员信息</span>
                <ul class="son">
                    <li>
                        <a href="use.php" target="right">查询管理员</a>
                    </li>
                    <li>
                        <a href="add.php" target="right">添加管理员</a>
                    </li>
                </ul>
            </li>
            <li>
                <span>分类信息</span>
                <ul class="son">
                    <li>
                        <a href="showCategory.php" target="right">查询分类</a>
                    </li>
                    <li>
                        <a href="addCategory.php" target="right">添加分类</a>
                    </li>
                </ul>
            </li>
            <li>
                <span>内容管理</span>
                <ul class="son">
<!--                    内容id con title-->
                    <li>查询内容</li>
                    <li>
                        <a href="addCon.php" target="right">添加内容</a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
    <div class="col-xs-8 right col-md-10">
        <iframe src="" name="right" frameborder="0"></iframe>
    </div>
</div>
<script>
    $(function(){
        $(".new>li>span").each(function(){
            $(this).click(function(){
                $(this).siblings('.son').slideToggle();
            })
        })
    })
</script>
</body>
</html>
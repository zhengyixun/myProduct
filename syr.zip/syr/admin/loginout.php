<?php
session_start();
$message="退出成功";
$url="login.php";
unset($_SESSION['aname']);
unset($_SESSION['apass']);
unset($_SESSION['aid']);

include "message.php";
?>
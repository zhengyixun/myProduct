<?php
include "../public/path.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo $url1;?>/admin/css/bootstrap.css">
    <script src="<?php echo $url1;?>/admin/js/jquery-3.2.1.js"></script>
    <script src="<?php echo $url1;?>/admin/js/jquery.validate.min.js"></script>
    <title>login</title>
</head>
<style>
    .box{
        width: 500px;height: 300px;padding-top: 50px;padding-left: 50px;padding-right: 50px;
        margin: 180px auto;border: 1px solid #ccc;
    }
    .login{
        background: #337AB7;
        color: #fff;
    }
    .login:hover{
        background: #337AB7;
        color: #fff;
    }
    h3{
        text-align: center;
        font-family: "苹方";
    }
    .error{
        color: red;
        font-size: 10px;
    }
</style>
<script>
    $(function(){
        $('form').validate({
            rules:{
                aname: {
                    required: true,
                    minlength: 2
                },
                apass: {
                    required: true,
                },
            },
            messages:{
                aname: {
                    required: '请输入用户名',
                    minlength: '长度不得小于2位'
                },
                apass: {
                    required: '请输入密码',
                },
            },
        })
    })
</script>
<body>
<div class="box">
    <h3>登录页面</h3>
    <form class="form-horizontal" action="logindata.php" method="post">
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label" >账号</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="inputEmail3" name="aname" placeholder="请输入用户名">
            </div>
        </div>

        <div class="form-group">
            <label for="inputPassword3" class="col-sm-2 control-label">密 码</label>
            <div class="col-sm-10">
                <input type="password" class="form-control" id="inputPassword3" name="apass" placeholder="请输入密码">
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default login dl">登录</button>

            </div>
        </div>
    </form>
</div>
</body>
</html>
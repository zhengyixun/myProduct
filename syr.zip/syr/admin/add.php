
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/jquery-3.2.1.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/up.js"></script>
    <title>add</title>
</head>
<body>
<form action="ins.php" method="post" id="signupForm" enctype="multipart/form-data">
    <div class="form-group">
        <label for="exampleInputEmail1">姓名</label>
        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="姓名" name="aname">
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1" >密码</label>
        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="密码" name="apass">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1" >昵称</label>
        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="昵称" name="anicheng">
    </div>
    <div class="form-group parent">
        <label for="exampleInputEmail1">头像</label>
        <input type="hidden"  name="aphoto" class="btnn">
    </div>
    <button type="submit" class="btn btn-default">提交</button>
</form>
<style>
    label{
        height: 15px;
    }
    .error{
        color: red;
        font-size: 10px;
    }
</style>
<script>
    var upll=new upload();
    var btnn=document.querySelector('.btnn');
    var parent=document.querySelector('.parent');
    upll.createView({parent});
    upll.upl("uploadClass.php",function(e){
        var str=e.join(';');
        btnn.value +=str;
    });

    $("#signupForm").validate({
        rules:{
            aname: {
                required: true,
                minlength: 2
            },
            apass: {
                required: true,
                minlength: 6
            },

        },
        messages:{
            aname:{
                required: "请输入姓名",
                minlength: "姓名长度不得小于2位",
            },
            apass:{
                required: "请输入密码",
                minlength: "密码长度不得小于6位",
            },

        },
    })
</script>

</body>
</html>
<?php
include "../public/path.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo $url1;?>/admin/css/bootstrap.css">
    <title>use</title>
</head>
<style>
    th,td{
        text-align: center;
    }
</style>
<body>
<div class="box table-responsive">
    <table class="table-bordered table">
        <tr>
            <th>姓名</th>
            <th>昵称</th>
            <th>照片</th>
            <th>操作</th>
        </tr>
        <?php
            include "../public/db.php";
            $sql=$db->query("select * from admin");
            $sql->setFetchMode(PDO::FETCH_ASSOC);

            while($row=$sql->fetch()){
        ?>
                <tr>
                    <td><?php echo $row["aname"];?></td>
                    <td><?php echo $row["anicheng"];?></td>
                    <td><img src="<?php echo $row['aphoto'];?>" alt="" width="30px" height="30px"></td>
                    <td><button type="button" class="btn btn-danger">
                            <a href="editData.php?aid=<?php echo $row['aid']?>">编辑</a>
                        </button></td>
                </tr>
        <?php
            }
        ?>
    </table>
</div>

</body>
</html>













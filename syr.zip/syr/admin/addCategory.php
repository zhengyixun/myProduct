<?php
include "../public/path.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo $url1;?>/admin/css/bootstrap.css">
    <title>addCategory</title>
</head>
<style>
    form{
        width: 500px;height:200px;margin: 100px auto;padding: 20px;
    }
</style>
<body>
<form action="addCategoryCon.php" method="post">
    添加分类 <select  class="form-control" id="" name="pid">
        <option value="0">一级分类</option>
        <?php
        include "../public/db.php";
        include "../public/functions.php";
        $obj=new tree();
        $obj->aa("0",$db,"category",0," - ");
        echo $obj->str;
        ?>
    </select>
    分类名称 <input type="text" name="cname" class="form-control"><br>
    跳转页面 <input type="text" name="link" class="form-control"><br>
    <input type="submit" value="添加" class="btn btn-info">
</form>
</body>
</html>
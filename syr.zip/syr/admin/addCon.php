<?php
include "../public/path.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo $url1;?>/admin/css/bootstrap.css">
    <script type="text/javascript" charset="utf-8" src="<?php echo $url1;?>/static/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="<?php echo $url1;?>/static/ueditor/ueditor.all.js"> </script>
    <script type="text/javascript" charset="utf-8" src="<?php echo $url1;?>/static/ueditor/lang/zh-cn/zh-cn.js"></script>
    <title>addCategory</title>
</head>
<style>
    form{
        width: 500px;height:200px;margin: 50px auto;padding: 20px;
    }
</style>
<body>
<form action="addConCon.php" method="post">
    所属分类 <select  class="form-control" id="" name="cid">
        <option value="0">一级分类</option>
        <?php
        include "../public/db.php";
        include "../public/functions.php";
        $obj=new tree();
        $obj->aa("0",$db,"category",0," - ");
        echo $obj->str;
        ?>
    </select>
    内容标题 <input type="text" name="stitle" class="form-control"><br>
    <div class="form-group parent">
        <label for="exampleInputEmail1">图片</label>
        <input type="hidden"  name="simage" class="btnn">
    </div>
    内容: <script id="editor" name="scon" type="text/plain"></script>
    <input type="submit" value="添加" class="btn btn-info btnn">
</form>
</body>
<script src="<?php echo $url1;?>/admin/js/up.js"></script>
<script>
    var upll=new upload();
    var btnn=document.querySelector('.btnn');
    var parent=document.querySelector('.parent');
    upll.createView({parent});
    upll.upl("uploadClass.php",function(e){
        var str=e.join(';');
        btnn.value +=str;
    });
    var ue = UE.getEditor('editor');
</script>
</html>
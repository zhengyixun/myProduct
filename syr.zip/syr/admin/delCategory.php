<?php
$cid=$_GET["cid"];
include "../public/db.php";
include "../public/functions.php";
$obj=new tree();
$obj->del($cid,$db,"category");
?>
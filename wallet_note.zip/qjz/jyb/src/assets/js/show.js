Vue.component('show-tu',{
    template:`
         <div class="showtu">
                <div class="close" ></div>
                <div class="photo"><img src="img/detail.jpg" alt=""></div>
                <div class="font">账单详情</div>  
         </div>
    `
})
Vue.component('show-mes',{
    template:`
        <div class="showmes">
            <div class="vol" >
                <div class="star">
                    <img src="./img/star.jpg" alt="">
                </div>
                <div class="star">
                    <img src="./img/star.jpg" alt="">
                </div>
                <div class="vol1"><span >2.0 </span>vol</div>
            </div>
            <div class="line" ></div>
            <div class="food" >
                 <div class="img"><img src="./img/icon4.png" alt="" ></div>
                 <div class="font" >餐饮</div>
            </div>
             <img src="./img/photo.jpg" alt="">
             <div class="name" >Anna</div>
            <div class="money" ><span>500.00</span>RMB</div>
        </div>
    `
})
Vue.component('show-set',{
    template:`
        <div class="showset">
            <div class="con" >
                <div class="icon"><img src="./img/icon1.png" alt=""></div>
                <div class="cont">11.27 2017</div>
            </div>
    
            <div class="con" >
                <div class="icon "><img src="./img/icon2.png" alt=""></div>
                <div class="cont setimg">设置图片
    
                    <!--<span style="display: block;position: absolute;top: 0;left: 0;">设置图片</span>
                    <input type="file" style="width: 100%;height: 0.3rem;border: 0;opacity: 0" id="file_input">-->
                </div>
            </div>
            <div class="con">
                <div class="icon"><img src="./img/icon3.png" alt=""></div>
                <div class="cont">备注：<span>金拱门</span></div>
            </div>
        </div>
    `
})
Vue.component('show-share',{
    template:`
        <div class="share">
            <div>
                <a href=""><img src="./img/QQ.png" alt=""></a>
                <a href=""><img src="./img/wx.png" alt=""></a>
                <a href=""><img src="./img/sina.png" alt=""></a>
                <a href=""><img src="./img/link.png" alt=""></a>
            </div>
        </div>
    `
})
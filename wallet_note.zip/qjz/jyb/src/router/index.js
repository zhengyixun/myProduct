import Vue from 'vue'
import Router from 'vue-router'
import '@/assets/css/base.css'
import '@/assets/js/jquery-3.2.1.min.js'
import AppF from '@/components/AppF'
import bck from '@/components/bck'
import loginInput from '@/components/loginInput'
import regInput from '@/components/regInput'
import search from '@/components/search'
import index from '@/components/index'
import indexinfo from '@/components/indexinfo'
import jyb from '@/components/zyx/jyb'
import myinfo from '@/components/wzd/myinfo'
/*wzd*/
import mubiao from '@/components/wzd/mubiao'
import myFriend from '@/components/wzd/myFriend'
import chat from '@/components/wzd/chat'
/*推文*/
import tuiwen from '@/components/ycw/tuiwen'
import more from '@/components/ycw/more'

Vue.use(Router);

export default new Router({
  routes: [
      {
          path: '/',
          component: AppF,
          children:[
              {path:"",component:bck,children:[
                  {path:"",component:loginInput},
                  {path:"/loginInput",component:loginInput},
                  {path:"/regInput",component:regInput}
              ]},

          ]
      },
      {
          path:"/search",
          component:search
      },
      {
          path:"/index",
          component:index,
          children:[
              {path:"",component:indexinfo},
              {path:"/jyb",component:jyb},
              {path:"/myinfo",component:myinfo},
              {path:"/mubiao",component:mubiao},
              {path:"/myFriend",component:myFriend},
              {path:"/tuiwen",component:tuiwen},
              {path:"/more",component:more},
              {path:"/chat",component:chat},
          ]
      },


  ]
})

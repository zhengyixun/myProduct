<template>
	<div>
		<header>
			<router-link to='tuiwen'>
				<div class="back">

				</div>
			</router-link>
			<div class="title">文 章</div>
		</header>
		<!--文章信息-->
		<section class="message">
			<div class="imgbox">
				<img src="/src/assets/img/ycw/head.png"/>
			</div>
			<div class="messagetext">
				<div class="name">MARRY.JEM</div>
				<div class="pen">Everything it's be ok</div>
				<div class="xx"> <img src="/src/assets/img/ycw/xx.png"/></div>
			</div>
			<div class="data">2017-09-08</div>
		</section>
		<!--banner-->
		<section class="banner">
			<img src="/src/assets/img/ycw/banner-more.png"/>
		</section>
		<section class="wenzhang">
			<div class="wenzhang-title">手机记账</div>
			<p> 记账软件是指用来记录个人、家庭、店铺、公司、企业等实体的资产、收支、经营情况的软件。从接入平台上分，记账软件分为PC端理财记账软件、WEB在线理财记账及手机理财记账三大平台，数据既可独立，又可同步。
			</p>
			<p>
				记账软件从使用对象的性质角度可以划分为：非财务人员使用的记账软件和财务人员使用的记账软件。前者也叫流水账、收支账后者也就是通常所说的会计软件、财务软件。两者在使用对象、人员资质要求、记账主体、业务内容、软件的体系流程及复杂程度、法律规范等都有很大的区别。
			</p>
			<p>
				专业人员使用的记账软件在我国始于上世纪八十年代初中期，目前处于较成熟的时期。随着电子商务对实体行业的冲击，业余人员，尤其是针对个体店开发的记账软件也开始流行的。
			</p>
			<p>
				随着移动端互联网在人们的生活中越来越重要，记账软件开始了从大型专业记账向偏个体、个人、家庭使用的小型记账，直接在平台电脑或者智能手机就可以使用的手机记账软
			</p>
		</section>
	</div>
</template>

<script>
    export default {

    }
</script>


<style>
	*{
		margin: 0;
		padding: 0;
		list-style: none;
		text-decoration: none;
	}
	header{
		width: 100%;
		height: 1.4rem;
		background: url(/src/assets/img/ycw/header.png) center center no-repeat;
		background-size: 100% 100%;
	}
	.back{
		width: 0.8rem;
		height: 0.5rem;
		background: url(/src/assets/img/ycw/back.png) center center no-repeat;
		background-size: 100% 100%;
		color: #fff;
		text-align: center;
		line-height: 0.5rem;
		font-size: 0.45rem;
		border-radius: 0.4rem;
		float: left;
		margin-left: 0.2rem;
		margin-top: 0.55rem;
	}
	.title{
		width: 1rem;
		height: 0.8rem;
		font-size: 0.4rem;
		color: #Fff;
		float: left;
		margin-left: 1.5rem;
		margin-top: 0.5rem;
		text-align: center;
	}
	.message{
		width: 100%;
		height: 1.6rem;
	}
	.imgbox{
		width: 1.2rem;
		height: 1.2rem;
		float: left;
		margin-top: 0.2rem;
		margin-left: 0.15rem;
	}
	.messagetext{
		width: 3rem;
		height: 1.2rem;
		float: left;
		margin-top: 0.2rem;
		margin-left: 0.15rem;
		font-size: 0.13rem;
	}
	.imgbox img{
		width: 100%;
		height: 100%;
	}
	.name{
		color: #676767;
		font-size: 0.16rem;

	}
	.pen{
		font-size: 0.13rem;
		color: #999999;
		padding-top: 0.08rem;
	}
	.xx{
		width: 50%;
		height: 0.4rem;
		margin-top: 0.08rem;
	}
	.xx img{
		width: 100%;
		height: 100%;
	}
	.data{
		width: 1.8rem;
		height: 0.3rem;
		color: #ACACAC;
		font-size: 0.12rem;
		float: right;
		margin-top: 0.8rem;
	}
	.banner{
		width: 90%;
		height: 2.5rem;
		margin: 0 auto;
	}
	.banner img{
		width: 100%;
		height: 100%;
	}
	.wenzhang{
		width: 100%;
		height: auto;
		margin-top: 0.3rem;
	}
	.wenzhang-title{
		font-size: 0.3rem;
		margin-bottom: 0.3rem;
		color: #7A97D9;
		padding: 0.15rem 0.3rem;
	}
	.wenzhang p{
		display: block;
		width: 90%;
		height: auto;
		margin: 0 auto;
		line-height: 0.28rem;
		font-size: 0.13rem;
		color: #8D8D8D;
		text-indent:2em;
	}

	.caozuo{
		width: 100%;
		height: 1.4rem;
		display: flex;
		justify-content: space-around;
	}
	.caozuo li{
		width: 0.6rem;
		height: 0.65rem;
		font-size: 0.13rem;
	}
	.caozuo li img{
		width: 100%;
		height: 80%;
	}
</style>
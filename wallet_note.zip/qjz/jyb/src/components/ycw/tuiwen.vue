<template>
    <div style="height: 100%;background: #fff">
        <header>
            <div class="tuiwen">推文</div>
            <ul class="tab">
                <li>游戏</li>
                <li><img src="/src/assets/img/ycw/tab.png"></li>
                <li>汇率</li>
            </ul>
        </header>
        <section class="banner">
            <img src="/src/assets/img/ycw/banner.png"/>
        </section>

        <input type="text" id="search" placeholder="输入您想要查找的联系人" @focus="ss"/>
        <section class="list">
            <div class="title">文章推荐</div>
            <div class="title-en">wenzhangtuijian</div>
            <ul class="artical">
                <li @touchstart="more">
                    <div class="list-img"><img src="/src/assets/img/ycw/list-img_11.png"/></div>
                    <div class="list-text">
                        <img src="/src/assets/img/ycw/wenhao_03.png"/>
                        <div class="list-title">你的钱去哪里了？</div>
                        <div class="list-title-text">生活中发现我们的钱不知不觉的少了</div>
                        <div class="auhtor">
                            <span>by.James</span>
                            <span>11.3 2017</span>
                        </div>
                    </div>
                    <div class="youshang"><img src="/src/assets/img/ycw/youshang_06.png"/></div>
                    <div class="youxia"><img src="/src/assets/img/ycw/youxia_07.png"/></div>
                </li>
                <li @touchstart="more">
                    <div class="list-img"><img src="/src/assets/img/ycw/list-img_15.png"/></div>
                    <div class="list-text">
                        <img src="/src/assets/img/ycw/wenhao_03.png"/>
                        <div class="list-title">你的钱去哪里了？</div>
                        <div class="list-title-text">生活中发现我们的钱不知不觉的少了</div>
                        <div class="auhtor">
                            <span>by.James</span>
                            <span>11.3 2017</span>
                        </div>
                    </div>
                    <div class="youshang"><img src="/src/assets/img/ycw/youshang_06.png"/></div>
                    <div class="youxia"><img src="/src/assets/img/ycw/youxia_07.png"/></div>
                </li>
                <li @touchstart="more">
                    <div class="list-img"><img src="/src/assets/img/ycw/list-img_19.png"/></div>
                    <div class="list-text">
                        <img src="/src/assets/img/ycw/wenhao_03.png"/>
                        <div class="list-title">你的钱去哪里了？</div>
                        <div class="list-title-text">生活中发现我们的钱不知不觉的少了</div>
                        <div class="auhtor">
                            <span>by.James</span>
                            <span>11.3 2017</span>
                        </div>
                    </div>
                    <div class="youshang"><img src="/src/assets/img/ycw/youshang_06.png"/></div>
                    <div class="youxia"><img src="/src/assets/img/ycw/youxia_07.png"/></div>
                </li>
                <li @touchstart="more">
                    <div class="list-img"><img src="/src/assets/img/ycw/list-img_23.png"/></div>
                    <div class="list-text">
                        <img src="/src/assets/img/ycw/wenhao_03.png"/>
                        <div class="list-title">你的钱去哪里了？</div>
                        <div class="list-title-text">生活中发现我们的钱不知不觉的少了</div>
                        <div class="auhtor">
                            <span>by.James</span>
                            <span>11.3 2017</span>
                        </div>
                    </div>
                    <div class="youshang"><img src="/src/assets/img/ycw/youshang_06.png"/></div>
                    <div class="youxia"><img src="/src/assets/img/ycw/youxia_07.png"/></div>
                </li>
            </ul>
        </section>
    </div>
</template>

<script>
    export default{
        methods:{
            more(){
                this.$router.push("/more");
            },
            ss(){
                this.$router.push("/search");
            }

        }
    }
</script>

<style scoped>
    *{
        margin: 0;
        padding: 0;
        list-style: none;
        text-decoration: none;
    }
    body{
        background: #F0FCFC;
    }
    header{
        width: 100%;
        height: 2.1rem;
        background: url(/src/assets/img/ycw/header.png) center center no-repeat;
        background-size: 100% 100%;
    }
    .tuiwen{
        width: 100%;
        height: 0.36rem;
        font-size: 0.35rem;
        color: #fff;
        text-align: center;
        padding-top: 0.5rem;
    }
    .tab{
        display: block;
        width: 70%;
        height: 0.75rem;
        border-radius: 0.3rem;
        display: flex;
        justify-content: space-around;
        background: #fff;
        margin: 0.3rem auto;
    }
    .tab li{
        width: 32%;
        height: 0.7rem;
        border-radius: 0.2rem;
        background: #DEDEDF;
        margin-top: 0.05rem;
        font-size: 0.25rem;
        color: #8F8F8F;
        text-align: center;
        line-height: 0.65rem;
    }
    .tab li:nth-last-of-type(2){
        background: #0AD69E;
    }
    .tab li img{
        display: block;
        width: 100%;
        height: 100%;
    }
    .banner{
        width: 100%;
        height: 2.5rem;
    }
    .banner img{
        width: 100%;
        height: 100%;
    }
    #search{
        display: block;
        width: 80%;
        height: 0.5rem;
        background: #fff;
        border-radius: 0.4rem;
        margin: 0.4rem auto;
        border:none;
        outline:medium;
        font-size: 0.13rem;
        color: #D4D4D5;
        padding-left: 0.15rem;
        box-shadow: 0rem 0.1rem 0.1rem #DFF4FA;
    }
    .title,.title-en{
        width: 100%;
        height: 0.28rem;
        color: #298DFE;
        font-size: 0.25rem;
        text-align: center;
    }
    .title-en{
        font-size: 0.25rem;
        color: #CCE9F6;
        margin-top: 0;
    }
    .artical{
        width: 100%;
        height: auto;
    }
    .artical li{
        width: 100%;
        height: 1.4rem;
        margin-top: 0.15rem;
        background: #fff;
        position: relative;
    }
    .list-img,.list-text{
        width: 1.2rem;
        height: 100%;
    }
    .list-img{
        float: left;
        margin-left: 0.15rem;
    }
    .list-img img{
        width: 100%;
        height: 100%;
    }
    .list-text{
        width: auto;
        float: left;
        margin-left: 0.45rem;
        margin-top: 0.15rem;
    }
    .list-text img{
        width: 0.4rem;
        height: 0.4rem;
        position: absolute;
        top: 0.15rem;
        left: 1.4rem;
    }
    .list-title{
        font-size: 0.16rem;
        color: #575757;
    }
    .list-title a{
        color: #575757;
    }
    .list-title-text{
        font-size: 0.13rem;
        color: #BEBEBE;
    }
    .auhtor{
        font-size: 0.13rem;
        color: #CCCCCC;
    }
    .youshang{
        width: 0.85rem;
        height: 0.45rem;
        position: absolute;
        right: 0.3rem;
        top: -0.1rem;
    }
    .youshang img{
        width: 100%;
        height: 100%;
    }
    .youxia{
        width: 0.45rem;
        height: 0.45rem;
        position: absolute;
        right: 0.03rem;
        bottom: 0;
    }
    .youxia img{
        width: 100%;
        height: 100%;
    }
</style>
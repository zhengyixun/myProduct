<template>
    <div class="cont">
        <slot></slot>
    </div>
</template>

<script>
</script>

<style>
    .cont{
        width: 7rem;
        height: 5.74rem;
        position: relative;
        top:0.73rem;
        left: 0;
        right: 0;
        margin: auto;
    }
</style>


<template>
    <div class="top">
        <div class="goal">用户目标</div>
        <div class="before"><a href=""><img src="../img/before.png" alt=""></a></div>
        <div class="spend">
            <div class="yu">
                <div class="font">小主本月剩还可以花：</div>
                <div class="qian">800.00 </div>
                <img src="../img/qian.png">
            </div>
            <div class="yu">
                <div class="font">小主的储蓄目标还差：</div>
                <div class="qian">2000.00 </div>
                <img src="../img/qian.png">
            </div>
        </div>
    </div>
</template>

<script>
</script>

<style>
    .top{
        width:100%;
        height:4.45rem;
        background: url("../img/back.jpg");
        background-size: cover;
        position: relative;
    }
    .top>.goal{
        width: 1.6rem;
        height: 0.38rem;
        position: absolute;
        top:0.6rem;
        left:0;
        right:0;
        margin:auto;
        font-size: 0.38rem;
        font-family: '黑体';
        text-align: center;
        color: #ffffff;
    }
    .top>.before{
        width: 0.58rem;
        height: 0.38rem;
        position: absolute;
        top: 0.6rem;
        left: 0.25rem;
    }
    .top>.before>a{
        display: block;
        width: 0.58rem;
        height: 0.38rem;
        position: absolute;
        top:0;
        left:0;
    }
    .top>.before>a>img{
        width: 0.58rem;
        height: 0.38rem;
        position: absolute;
        top:0;
        left:0;
    }
    .top>.spend{
        width:6.5rem;
        height:1rem;
        position: absolute;
        top:2.03rem;
        left:0;
        right:0;
        margin:auto;
        display: flex;
        justify-content: space-between;

    }
    .top>.spend>.yu{
        width:3rem;
        height: 1rem;
        position: relative;
    }
    .top>.spend>.yu>.font{
        width:3rem;
        font-size: 0.2rem;
        color: #ffffff;
    }
    .top>.spend>.yu>.qian{
        height:0.45rem;
        font-size: 0.45rem;
        color: #ffffff;
        position: absolute;
        left:0.3rem;
        top:0.52rem;
    }
    .top>.spend>.yu>img{
        width: 0.3rem;
        height: 0.3rem;
        position: absolute;
        left: 2.2rem;
        top:0.72rem;
    }
</style>


<template>
    <div class="set">
        <div class="con" >
            <div class="icon"><img src="/src/assets/img/zl/icon1.png" alt=""></div>
            <div class="cont">11.27 2017</div>
        </div>

        <div class="con" >
            <div class="icon "><img src="/src/assets/img/zl/icon2.png" alt=""></div>
            <div class="cont setimg">设置图片

                <!--<span style="display: block;position: absolute;top: 0;left: 0;">设置图片</span>
                <input type="file" style="width: 100%;height: 0.3rem;border: 0;opacity: 0" id="file_input">-->
            </div>
        </div>
        <div class="con">
            <div class="icon"><img src="/src/assets/img/zl/icon3.png" alt=""></div>
            <div class="cont">备注：<span>金拱门</span></div>
        </div>
    </div>
</template>

<script>
</script>

<style>
    .set{
        width: 100%;
        height:0.37rem;
        position: relative;
        top:0.83rem;
        left:0;
        display: flex;
        justify-content: space-between;
    }
    .set>.con{
        width: 2.3rem;
        height: 0.38rem;
        position: relative;
    }
    .set>.con>.icon{
        width: 0.38rem; height: 0.38rem;
        margin-right: 0.05rem;
        position: absolute;
        top:0;
        left: 0;
    }
    .set>.con>.icon>img {
        width: 0.38rem;
        height: 0.38rem;
        position: absolute;
        top:0;
        left: 0;
    }
    .set>.con>.cont{
        width:auto;
        height: 0.35rem;
        position: absolute;
        left:0.58rem;
        top:0;
        font-size: 0.12rem;
        line-height: 0.35rem
    }
</style>


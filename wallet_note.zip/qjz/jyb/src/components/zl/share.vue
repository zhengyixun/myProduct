<template>
    <div class="share">
        <div>
            <a href=""><img src="/src/assets/img/zl/QQ.png" alt=""></a>
            <a href=""><img src="/src/assets/img/zl/wx.png" alt=""></a>
            <a href=""><img src="/src/assets/img/zl/sina.png" alt=""></a>
            <a href=""><img src="/src/assets/img/zl/link.png" alt=""></a>
        </div>
    </div>
</template>

<script>
</script>

<style>
    .share{
        width: 100%;height: 0.9rem;
        background:url("../../assets/img/zl/foot.png");
        background-size: cover;
        position: relative;
        top:1.3rem;left: 0;
        border-radius: 0 0 0.2rem 0.2rem;

    }
    .share>div{
        width: 3.65rem;
        height:0.37rem;
        position: absolute;
        top:0;
        bottom:0;
        left: 0;
        right:0;
        margin:auto;
        display: flex;
        justify-content: space-around;
    }
    .share>div>a{
        display: block;
        width:0.45rem;
        height:0.35rem;
        position: relative;

    }
    .share>div>a>img {
        width:0.45rem;
        height:0.35rem;
        position: absolute;
        top:0;
        left: 0;
    }
    .up{
        width: 6rem;
        height: 3rem;
        position: relative;
        top:-3rem;
        left: 0;
        right: 0;
        margin:auto;
        background-color: #0aa6de;
        display: none;
    }
</style>


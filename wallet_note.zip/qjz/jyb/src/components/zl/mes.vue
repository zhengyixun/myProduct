<template>
    <div class="mes">
        <div class="vol" >
            <div class="star">
                <img src="../../assets/img/zl/star.jpg" alt="">
            </div>
            <div class="star">
                <img src="../../assets/img/zl/star.jpg" alt="">
            </div>
            <div class="vol1"><span >2.0 </span>vol</div>
        </div>
        <div class="line" ></div>
        <div class="food" >
            <div class="img"><img src="../../assets/img/zl/icon4.png" alt="" ></div>
            <div class="font" >餐饮</div>
        </div>
        <img src="../../assets/img/zl/photo.jpg" alt="">
        <div class="name" >Anna</div>
        <div class="money" ><span>500.00</span>RMB</div>
    </div>
</template>

<script>
</script>

<style>
    .mes{
        position: relative;top: 0.5rem;width: 100%;height: 1.8rem;
    }
    .mes>.vol{
        position: absolute;left: 0.2rem;top: 0.17rem;
    }
    .star{
        width: 0.3rem;height: 0.3rem;float: left;margin-right: 0.1rem;
        position: relative;
    }
    .star>img{
        width:0.3rem;
        height: 0.3rem;
        position: absolute;
        top:0;
        left: 0;
    }
    .vol1{
        float: left;font-size: 0.12rem;
        margin-left: 0.2rem;
    }
    .vol1>span{
        font-size: 0.16rem;
    }
    .line{
        width: 4.1rem;
        height:0.05rem;
        position: absolute;top: 0.7rem;left: 0.2rem;
        background: url("../../assets/img/zl/line.png");
        background-size: cover;
    }
    /*.dot{
        width: 0.1rem;
        height:0.1rem;
        border-radius: 50%;
        background-color: #7c7c7c;
    }
    .dot1{
        position: absolute;
        top:0.63rem;
        left: 0.2rem;
    }
    .dot2{
        position: absolute;
        top:0.63rem;
        left:4.3rem;
    }*/
    .food{
        height: 0.83rem;position:absolute;
        top:0.84rem;left: 0.2rem;line-height: 1rem
    }
    .food>.img{
        width: 0.83rem;
        height:0.83rem;
        float: left;margin-right: 0.2rem
    }
    .food>.img>img{
        width: 0.8rem;height: 0.8rem;
    }
    .food>.font{
        float: left;height:0.8rem;font-size: 0.22rem;color:#4684d8;text-align: center;line-height: 1rem;
    }
    .mes>img{
        width: 1.2rem;height: 1.2rem;position: absolute;top: -0.6rem;right: 0.3rem;background-color: blue;border: 0.03rem solid #ffffff;border-radius: 50%;
        z-index: 2;
    }
    .mes>.name{
        width: 1.2rem;height: 0.15rem;position: absolute;top: 0.75rem;right: 0.3rem;font-size:0.15rem;text-align: center;line-height: 0.15rem
    }
    .mes>.money{
        font-size: 0.2rem;letter-spacing:0.03rem;color: #6defc6;position: absolute;right: 0.3rem;top:1.25rem;
    }
    .mes>.money>span{
        font-size: 0.4rem;
        font-weight:bolder;letter-spacing:0.04rem;color: #2453b2;
    }
</style>


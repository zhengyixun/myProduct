<template>
    <div class="zhangdan">
        <main>
            <div class="top">
                <div class="shu"></div>
                <div class="zhong">今日账单</div>
                <div class="en">ZHANGDANBEIZHU</div>
            </div>
            <div class="bottom">
                <span class="day">11.27</span>
                <span class="week">SUN</span>
                <span class="year">2017</span>
            </div>
        </main>
    </div>
</template>

<script>
    export default {
        name: 'zhangdan',
    }
</script>

<style scoped>
    .zhangdan{
        width:100%;
        height:1.4rem;
        background:#F4F2F1;
    }
    .top{
        width:100%;
        height:0.74rem;
        padding-top: 0.14rem;
        box-sizing: border-box;
    }
    .shu{
        width:0.06rem;
        height:0.5rem;
        background: #FF6326;
        float: left;
        margin-right: 0.1rem;
        border-radius: 0.2rem;
    }
    .zhong{
        font-size:0.28rem;
        color:#60A2D6;
    }
    .en{
        font-size:0.1rem;
        color:#E4E2E1;
    }
    .bottom {
        width: 100%;
        height: 0.5rem;
        padding-top:0.2rem;
        padding-left:0.12rem;
        box-sizing: border-box;
    }
    .day{
        font-size: 0.26rem;
        color:#28E0AD;
        margin-right: 0.24rem;
        display: block;
        float:left;
    }
    .week{
        font-size: 0.26rem;
        color:#28E0AD;
        margin-right: 0.34rem;
        display: block;
        float:left;
    }
    .year{
        font-size: 0.26rem;
        color:#CAC9C9;
        display: block;
        float:left;
    }
</style>


<template>
    <div class="xuanze">
        <span class="p">请填写账单信息</span>
        <span class="pe">qingtianxiezhangdanxinxi</span>
    </div>
</template>

<script>
</script>

<style>
    .xuanze{
        width: 100%;
        height:0.95rem;
        background: #D7F8EA;
        margin-top: 0.4rem;
        text-align: center;

    }
    .p{
        font-size: 0.3rem;
        color:#3399CC;

        display: block;
        margin-top: 0.3rem;
    }
    .pe{
        font-size: 0.2rem;
        color:#C9E8DA;

        display: block;
    }
</style>


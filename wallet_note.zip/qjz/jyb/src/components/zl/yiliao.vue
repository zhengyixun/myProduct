<template>
    <div class="yiliao">

    </div>
</template>

<script>
</script>

<style>
    .yiliao{
        width:100%;
        height:1.41rem;
        background: #FFFFFF;
        font-size: 0.3rem;
        color:#DDDDDD;
        text-align: center;
        line-height: 1.2rem;
    }
</style>


<template>
    <div class="background">
        <img src="/src/assets/img/zl/background_01.png" alt="">
        <main>

            <div class="fanhui" @touchstart="back">
                <img src="/src/assets/img/zl/fanhui_08.png" alt="">
            </div>
            <div class="ji">记笔账</div>
            <div class="fenxiang">
                <img src="/src/assets/img/zl/fenxiang.png" alt="">
            </div>
            <div class="xiao">
                <div class="dian1"></div>
                <span>小主今日消费</span>
                <div class="dian2"></div>
            </div>
            <div class="yuan">
                <span class="erbai">200</span>
                <div class="fang"></div>
                <span class="ling">00</span>
            </div>

        </main>
    </div>
</template>

<script>
    export default {
        methods:{
            back(){
                this.$router.go(-1);
            }
        }

    }
</script>

<style scoped>
    *{
        padding:0;
        margin:0;
        list-style: none;
        text-decoration: none;
    }
    .background{
        width: 7.5rem;
        height:4.4rem;
    }
    .background img{
        display: block;
        width: 7.5rem;
        height:4.4rem;
        position: relative;
    }
    main{
        width:7rem;
        height:auto;
        margin:0 auto;

    }

    .fanhui{
        position: absolute;
        width:0.63rem;
        height:0.4rem;
        top: 0.58rem;
        left:0.25rem;
        float:left;
    }
    .fanhui img{
        width:0.63rem;
        height:0.4rem;
        display: block;
    }
    .ji{
        position: absolute;
        width:1.35rem;
        height:0.4rem;
        font-size:0.4rem;
        color:#FFFFFF;
        float:left;
        top: 0.58rem;
        left:3.08rem;
        line-height: 0.4rem;
    }
    .fenxiang{
        position: absolute;
        width:0.48rem;
        height:0.42rem;
        top: 0.58rem;
        right:0.25rem;
        float:right;

    }
    .fenxiang img{
        width:0.48rem;
        height:0.42rem;
        display: block;
    }
    .xiao{
        position:absolute;
        width:100%;
        height:0.44rem;
        top: 1.54rem;
        left:0;

    }
    .dian1{
        width:0.07rem;
        height:0.07rem;
        border-radius: 50%;
        background: #FFFFFF;
        float:left;
        margin-left: 2.73rem;
        margin-right: 0.1rem;
        margin-top: 0.2rem;
    }
    .xiao span{
        font-size: 0.27rem;
        color:#FFFFFF;
        display: block;
        float:left;
    }
    .dian2{
        width:0.07rem;
        height:0.07rem;
        border-radius: 50%;
        background: #FFFFFF;
        float:right;
        margin-right: 2.72rem;
        margin-top: 0.2rem;
    }
    .yuan{
        position: absolute;
        top:1.85rem;
        left:0;
        width:100%;
        height:2.12rem;

    }
    .erbai{
        font-size: 1.4rem;
        color:#FFFFFF;
        float:left;
        margin-left: 1.2rem;
    }
    .fang{
        width:0.18rem;
        height:0.17rem;
        background:#FFFFFF;
        float:left;
        margin-top: 1.3rem;
    }
    .ling{
        font-size: 1.4rem;
        color:#C0EAE2;
        float:left;
    }
</style>


<template>
    <main>
        <div class="tips">
            <img src="../../assets/img/zl/tips_04.png" alt="">
            <div class="car">
                <img src="../../assets/img/zl/car.gif" alt="">
            </div>
            <div class="qian">
                <img src="../../assets/img/zl/qian_05.png" alt="">
                <span class="rmb">200</span>
            </div>
            <div class="jiao">
                <img src="../../assets/img/zl/jiaotong_04.png" alt="">
                <span class="tong">交通出行</span>
            </div>
            <div class="gengduo">
                <img src="../../assets/img/zl/gengduo.gif" alt="">
            </div>
        </div>
    </main>
</template>

<script>
    export default {

    }
</script>

<style scoped>
    main{
        width:7rem;
        height:auto;
        margin:0 auto;
    }
    .tips{
        width:100%;
        height:1.4rem;
        position: relative;
    }
    .tips img{
        width:7rem;
        height: 1.4rem;
        display: block;

    }
    .car{
        position: absolute;
        top:0.24rem;
        left:0.23rem;
        width:0.82rem;
        height:0.92rem;
    }
    .car img{
        width:0.82rem;
        height:0.92rem;
    }
    .qian{
        position: absolute;
        top:0.24rem;
        left:1.15rem;
        width:2.94rem;
        height:0.92rem;
    }
    .qian img{
        width:2.94rem;
        height:0.92rem;
        position:relative;
    }
    .rmb{
        font-size: 0.28rem;
        color:#FFFFFF;
        position:absolute;
        top:0.3rem;
        left:0.75rem;
    }
    .jiao{
        position: absolute;
        top:0.24rem;
        left:4.09rem;
        width:2.09rem;
        height:0.92rem;
    }
    .jiao img{
        width:2.09rem;
        height:0.92rem;
        position: relative;
    }
    .jiao>.tong{
        font-size: 0.26rem;
        color:#FFFFFF;
        position: absolute;
        top:0.25rem;
        left:0.45rem;
    }
    .gengduo{
        position: absolute;
        top:0.53rem;
        left:6.26rem;
        width:0.43rem;
        height:0.45rem;
    }
    .gengduo img{
        width:0.43rem;
        height:0.45rem;
    }

</style>


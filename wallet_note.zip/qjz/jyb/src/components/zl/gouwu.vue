<template>
    <div class="gouwu">
       购物娱乐
    </div>
</template>

<script>
</script>

<style>
    .gouwu{
        width: 100%;
        height:1.03rem;
        background: #FFFFFF;
        font-size: 0.28rem;
        color:#DDDDDD;
        text-align: center;
        line-height: 1.03rem;

    }
</style>


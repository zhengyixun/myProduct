<template>
<div>
    <div class="close"></div>
</div>
</template>

<script>
    export default {

    }
</script>

<style scoped>
    .close{
        width: 0.73rem;height: 0.54rem;position: absolute;top: 1.25rem;right: 0.3rem;text-align:center;line-height:0.5rem;font-size: 0.3rem;color: #fff;font-weight: bolder;background-image: url('../../assets/img/close.png');background-size: cover;
    }
</style>
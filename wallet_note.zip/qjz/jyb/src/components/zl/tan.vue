<template>
    <div>
         <detail>
             <tu></tu>
             <mes></mes>
             <set></set>
             <share></share>
         </detail>
    </div>
</template>

<script>
    import detail from '@/components/zl/detail'
    import tu from '@/components/zl/tu'
    import mes from '@/components/zl/mes'
    import set from '@/components/zl/set'
    import share from '@/components/zl/share'
    export default {
        components:{detail,tu,mes,set,share}
    }
</script>

<style>
</style>




<template>
    <div class="chuxing">
        <div class="yuanjiao">
            <div class="yuan1"><img src="../../assets/img/zl/dian.png" alt=""></div>
            <div class="yuan2"><img src="../../assets/img/zl/dian.png" alt=""></div>
            <span class="chu">交通出行</span>
        </div>
    </div>
</template>

<script>
</script>

<style>
    .chuxing{
        width: 100%;
        height:0.84rem;
        background: #FFFFFF;
        border-bottom: 0.02rem solid #D6D3D2 ;
        border-top: 0.02rem solid #D6D3D2 ;
    }
    .yuanjiao{
        width: 2.01rem;
        height:0.7rem;
        background: #F0F8F5;
        border-radius: 0.27rem;
        margin:0.07rem auto;
    }
    .yuan1{
        width:0.06rem;
        height: 0.06rem;
        float:left;
        margin-top:0.33rem ;
        margin-left:0.17rem ;
    }
    .yuan1 img{
        width:0.06rem;
        height: 0.06rem;
        display: block;
    }
    .yuan2{
        width:0.06rem;
        height: 0.06rem;
        float:right;
        margin-top:0.33rem ;
        margin-right:0.17rem ;
    }
    .yuan2 img{
        width:0.06rem;
        height: 0.06rem;
        display: block;
    }
    .chu{
        font-size: 0.3rem;
        color: #666;
        text-align: center;
        line-height: 0.7rem;
        display: block;
        float: left;
        margin-left: 0.17rem;
    }
</style>


<template>
    <div>
          <top></top>
           <cont>
               <yue></yue>
               <zongliang></zongliang>
           </cont>
    </div>
</template>

<script>
    import top from '@/components/top'
    import cont from '@/components/cont'
    import yue from '@/components/yue'
    import zongliang from '@/components/zongliang'



    export default {
        name: 'abc',
        components:{top,cont,yue,zongliang}
    }
</script>

<style>
    body{
        margin: 0;
        padding: 0;
    }

    :root{
        background: #F4F2F1;
    }
</style>




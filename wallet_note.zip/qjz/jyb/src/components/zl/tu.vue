<template>
    <div class="tu">
        <div class="photo"><img src="/src/assets/img/zl/detail.jpg" alt=""></div>
        <div class="font">账单详情</div>
    </div>
</template>

<script>
</script>

<style>
    .tu{
        width: 100%;height: 5.5rem;position: relative;top: 0;left: 0;right: 0;margin: auto;
    }
    .tu>.photo{
        width: 100%;height: 5.5rem;position: absolute;
        top:0;left: 0;
    }
    .tu>.photo>img{
        width: 100%;height: 5.5rem;position: absolute;
        top:0;left: 0;
        z-index: 1;
        border-radius: 0.2rem 0.2rem 0 0 ;
    }
    .tu>.font{
        position: absolute;bottom: 0.2rem;left: 0.2rem;font-size: 0.3rem;color: #fff;letter-spacing: 0.04rem;font-weight: bolder;z-index: 2;
    }
</style>


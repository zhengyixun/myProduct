<template>
    <div class="target">
        <div class="image"><img src="../img/win.png" alt=""></div>
        <div class="font">储蓄目标</div>
        <div class="money">26000.00</div>
    </div>
</template>

<script>
</script>

<style>
    .cont>.target{
        width: 7rem;
        height: 2.5rem;
        background: url("../img/goalcon.png");
        background-size: cover;
        margin-bottom: 0.77rem;
        position: relative;
    }
    .cont>.target>.image{
        width:0.83rem;
        height: 0.83rem;
        position: absolute;
        left: 0;
        right: 0;
        margin: auto;
        top:-0.41rem;

    }
    .cont>.target>.image>img{
        width:0.83rem;
        height: 0.83rem;
        border-radius: 50%;
        position: absolute;
        left:0;
        top:0;
        box-shadow: 0 0.1rem 0.5rem #3bf8d1;
    }
    .cont>.target>.font{
        width:100%;
        height: auto;
        position: absolute;
        left: 0;
        right: 0;
        top:0.63rem;
        margin: auto;
        font-size: 0.28rem;
        color:#0aa6de;
        text-align: center;
    }
    .cont>.target>.money{
        width:100%;
        height: auto;
        position: absolute;
        left: 0;
        right: 0;
        top:1.34rem;
        margin: auto;
        font-size: 0.35rem;
        color:#0ac2ba;
        text-align: center;
    }
</style>


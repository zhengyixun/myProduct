<template>
<div class="back" @touchstart="backs"></div>
</template>

<script>
    export default {
        methods:{
            backs(){
                this.$router.go(-1);
            }
        }
    }
</script>

<style scoped>
.back{
    background:url("/src/assets/img/sou (12).png");
    background-size: 0.6rem 0.38rem;
    display: block; width:0.6rem; height:0.38rem;
}
</style>
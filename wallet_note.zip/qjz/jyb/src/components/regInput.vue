<template>
    <div>
        <div class="login">
            <div class="imgbox"></div>
            <input type="text" placeholder="您可以输入邮箱或者手机号" v-model="uphone">
            <check class="checks" v-show="checkFlag1"></check>
        </div>
        <div class="login login1">
            <div class="imgbox pass"></div>
            <input type="text" placeholder="您可以输入密码" v-model="pass1">
            <check class="checks" v-show="checkFlag1"></check>
        </div>
        <div class="login login1">
            <div class="imgbox pass"></div>
            <input type="text" placeholder="请再次输入密码" v-model="pass2">
            <check class="checks" v-show="checkFlag2"></check>
        </div>
        <div class="loginButton" @touchstart="submit">
            <img src="/src/assets/img/loginbutton.png" alt="">
        </div>
        <div class="span">
            <div class="circle"></div>
            小主还没有绑定银行卡  去绑定
            <div class="circle1"></div>
        </div>
    </div>
</template>

<script>
    import check from "./check.vue"
    export default {
        data(){
            return {
                uphone:'',
                pass1:'',
                pass2:'',
                checkFlag:false,
                checkFlag1:false,
                checkFlag2:false,
                flag:true,
            }
        },
        components:{ check },

        methods:{
            submit(){
                var that=this;
                if(this.phone==""){
                    this.checkFlag=true;
                    this.flag=false;
                }
                if(this.pass1==""){
                    this.checkFlag1=true;
                    this.flag=false;
                }
                if(this.pass2==""){
                    this.checkFlag2=true;
                    this.flag=false;
                }
                if(this.pass2!=this.pass1){
                    this.flag=false;
                }
                if(this.flag){
                    fetch("/ajax/quser/reguser",{
                        method:"post",
                        headers:{
                            "content-type":"application/x-www-form-urlencoded"
                        },
                        body:"uphone="+this.uphone+"&upass1="+this.pass1+"&upass2="+this.pass2
                    }).then(function(e){
                        return e.text();
                    }).then(function(e){
                        if(e=="err"){
                            console.log("注册失败")
                        }else if(e=="ok"){
                            console.log("注册成功")
                            that.$router.push("/loginInput");
                        }
                    })
                }
            }
        }
    }
</script>

<style scoped>
    input::-webkit-input-placeholder{
        color: #cfcece;
    }
    .login{
        width: 5.5rem;height: 0.8rem;border: 0.03rem solid #dedede;border-radius: 0.7rem;margin: 0 auto;box-sizing: border-box;position: relative;
        z-index: 2;background:#fbfbfb ;margin-top: 0.7rem;
    }
    .login1{
        margin-top: 0.4rem;
    }
    .checks{
        position: absolute;
        right: 0.2em;top:0.5rem;
    }
    input{
        height: 100%;border: none;background: none;line-height: 0.85rem;display: block;float: left;outline: none;box-shadow: none;
    }
    .imgbox{
        width: 0.8rem;height: 0.8rem;float: left;background: url("/src/assets/img/loginIcon.png");background-size: 1.98rem 0.75rem;margin-right: 0.15rem;
    }
    .pass{
        background-position:0.9rem 0;
    }
    .loginButton{
        width: 2.9rem;height: 0.8rem;margin: 0.3rem auto;
    }
    .loginButton>img{
        width: 100%;height: 100%;
    }
    .span{
        color: #bbb;font-size: 0.2rem;position: relative;width: 4rem;margin: 0 auto;
    }
    .circle{
        width: 0.1rem;height: 0.1rem;box-sizing: border-box;border: 0.02rem solid #e8f1fe;background: #2077f5;position: absolute;top:0.16rem;left:-0.05rem;border-radius: 50%;
    }
    .circle1{
        width: 0.1rem;height: 0.1rem;box-sizing: border-box;border: 0.02rem solid #e8f1fe;background: #2077f5;position: absolute;top:0.16rem;right:-0.05rem;border-radius: 50%;
    }
</style>
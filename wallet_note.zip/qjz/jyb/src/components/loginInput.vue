<template>
    <div>
        <div class="login">
            <div class="imgbox"></div>
            <input type="text" placeholder="您可以输入邮箱或者手机号" v-model="uphone" class="phonecheck">
            <check class="checks" v-show="checkFlag"></check>
        </div>
        <div class="login login1">
            <div class="imgbox pass"></div>
            <input type="text" placeholder="您可以输入密码完成验证" v-model="upass" class="passcheck">
            <check class="checks" v-show="checkFlag1"></check>
        </div>
        <div class="forget"></div>
        <div class="loginButton" @click="logins">
            <img src="/src/assets/img/loginbutton.png" alt="">
        </div>
        <div class="span">
            <div class="circle"></div>
            小主还没有绑定银行卡  去绑定
            <div class="circle1"></div>
        </div>
    </div>
</template>

<script>
    import check from "./check.vue"
    export default {
        data(){
          return {
              uphone:'',
              upass:'',
              checkFlag:false,
              checkFlag1:false
          }
        },
        components:{ check },
        methods:{
            logins(){
                var that=this;
                if(this.uphone==""){
                    this.checkFlag=true;

                }
                if(this.upass==""){
                    this.checkFlag1=true;
                    return
                }
                fetch("/ajax/quser/loginUser",{
                    method:"post",
                    headers:{
                        "content-type":"application/x-www-form-urlencoded"
                    },
                    body:"uphone="+this.uphone+"&upass="+this.upass
                }).then(function(e){
                    return e.json()
                }).then(function(e){
                    if(e.message=="err"){
                        console.log("登陆失败")
                        that.$router.push("/loginInput")
                    }else{
                        sessionStorage.uid=e[0].uid;
                        sessionStorage.uphone=e[0].uphone;
                        sessionStorage.uname=e[0].uname;
                        that.$router.push("/index")
                    }
                })
            }
        }
    }
</script>

<style scoped>
    input::-webkit-input-placeholder{
        color: #cfcece;
    }
    .login{
        width: 5.5rem;height: 0.8rem;border: 0.03rem solid #dedede;border-radius: 0.7rem;margin: 0 auto;box-sizing: border-box;position: relative;
        z-index: 2;background:#fbfbfb ;margin-top: 0.7rem;
    }
    .login1{
        margin-top: 0.4rem;
    }
    .checks{
        position: absolute;
        right: 0.2em;top:0.5rem;
    }
    input{
        height: 100%;border: none;background: none;line-height: 0.85rem;display: block;float: left;outline: none;box-shadow: none;
    }
    .imgbox{
        width: 0.8rem;height: 0.8rem;float: left;background: url("/src/assets/img/loginIcon.png");background-size: 1.98rem 0.75rem;margin-right: 0.15rem;
    }
    .pass{
        background-position:0.9rem 0;
    }
    .forget{
        width: 4.5rem;height: 0.66rem;margin: 0.3rem auto;background: red;background: url("../assets/img/forget.png");background-size: 4.5rem 0.66rem;
    }
    .loginButton{
        width: 2.9rem;height: 0.8rem;margin: 0.3rem auto;
    }
    .loginButton>img{
        width: 100%;height: 100%;
    }
    .span{
        color: #bbb;font-size: 0.2rem;position: relative;width: 4rem;margin: 0.4rem auto;
    }
    .circle{
        width: 0.1rem;height: 0.1rem;box-sizing: border-box;border: 0.02rem solid #e8f1fe;background: #2077f5;position: absolute;top:0.16rem;left:-0.05rem;border-radius: 50%;
    }
    .circle1{
        width: 0.1rem;height: 0.1rem;box-sizing: border-box;border: 0.02rem solid #e8f1fe;background: #2077f5;position: absolute;top:0.16rem;right:-0.05rem;border-radius: 50%;
    }
</style>
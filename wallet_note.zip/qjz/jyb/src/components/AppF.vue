<template>
<div class="Apps">
    <img src="/src/assets/img/header.png" alt="" class="img" style="width:3.4rem;height: 3.4rem;">
    <div class="text">
        <div class="h3">趣记账</div>
        <div class="h5">QU.KEEP ACCOUNTS</div>
        <div class="h6">记录你的生活</div>
        <div class="h7">R E C O R D L I F E</div>
    </div>
    <router-view/>
    <!--微信+qq-->
    <div class="box">
        <div class="QQ"></div>
        <div class="WX"></div>
    </div>
</div>
</template>

<script>
    export default {

    }
</script>

<style scoped>
    .Apps {
        font-family: 'Avenir', Helvetica, Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        text-align: center;
        color: #2c3e50;
    }
    .img{
        position: absolute;left:0;right: 0;margin-left: auto;margin-right: auto;top:0.2rem;
    }
    .text{
        margin-top: 3rem;
    }
    .h3{
        font-size: 0.44rem;
    }
    .h5{
        font-size: 0.3rem;
    }
    .text>.h7{
        font-size: 0.14rem; color: #9decdb;
    }
    .text>.h3,.text>.h5,.text>.h6,.h7{
        color: #fff;font-family: "苹方";
    }
    .h6{
        font-size: 0.2rem;
    }
    .box{
        width: 2.5rem;height: 1rem;margin: 0.2rem auto;display: flex;justify-content: space-around;
    }
    .QQ,.WX{
        float: left;width: 1rem;height: 1rem;;
    }
    .QQ{
        background-image:url("/src/assets/img/QQ+WX.png") ;
        background-position: 1.15rem 0;
        background-size:2.5rem 1rem;
    }
    .WX{
        background-image:url("/src/assets/img/QQ+WX.png") ;
        background-size:2.5rem 1rem;
    }
</style>
<template>
    <div style="position: absolute;top:0;left:0;width: 100%">
        <background></background>
        <zhangdan></zhangdan>
        <jiaotong></jiaotong>
        <main>
        <div class="tips">
            <div class="car">
                <img src="/src/assets/img/zl/a.gif" alt="">
            </div>
            <div class="qian">
                <img src="/src/assets/img/zl/b_09.png" alt="">
                <input type="text" class="rmb" placeholder="金额" v-model="zmoney">
            </div>
            <div class="jiao">
                <input type="text" placeholder="事件" v-model="zthing">
            </div>
            <div class="gengduo">
                <img src="/src/assets/img/zl/e.png" alt="">
            </div>
            <div class="ding">
                <img src="/src/assets/img/zl/d.png" alt="">
            </div>
        </div>
        </main>
        <xuanze></xuanze>
        <div class="chuxing" @touchstart="sub">
            <div class="yuanjiao">
                <div class="yuan1"><img src="/src/assets/img/zl/dian.png" alt=""></div>
                <div class="yuan2"><img src="/src/assets/img/zl/dian.png" alt=""></div>
                <span class="chu">确认添加</span>
            </div>
        </div>
        <yiliao></yiliao>
    </div>
</template>

<script>
    import background from '@/components/zl/background'
    import zhangdan from '@/components/zl/zhangdan'
    import jiaotong from '@/components/zl/jiaotong'
    import xuanze from '@/components/zl/xuanze'
    import yiliao from '@/components/zl/yiliao'

    export default {
        data(){
          return{
              zmoney:"",
              zthing:"",
          }
        },
        components:{background,zhangdan,jiaotong,xuanze,yiliao},
        methods:{
            sub(){
                var that=this;
                fetch("/ajax/quser/insZhangDan",{
                    method:"post",
                    headers:{
                        "content-type":"application/x-www-form-urlencoded"
                    },
                    body:"uid="+sessionStorage.uid+"&zmoney="+that.zmoney+"&zthing="+that.zthing
                }).then(function(e){
                    return e.text();
                }).then(function(e){
                    if(e=="err"){
                        console.log(e);
                    }else if(e=="ok"){
                        that.$router.push("/index");
                    }
                })
            }
        }
    }
</script>

<style scoped>
    body{
        margin: 0;
        padding: 0;
    }
    main{
        width:7rem;
        height:auto;
        margin:0 auto;
    }
    :root{
        background: #F4F2F1;
    }
    .chuxing{
        width: 100%;
        height:0.84rem;
        background: #FFFFFF;
        border-bottom: 0.02rem solid #D6D3D2 ;
        border-top: 0.02rem solid #D6D3D2 ;
    }
    .yuanjiao{
        width: 2.01rem;
        height:0.7rem;
        background: #F0F8F5;
        border-radius: 0.27rem;
        margin:0.07rem auto;
    }
    .yuan1{
        width:0.06rem;
        height: 0.06rem;
        float:left;
        margin-top:0.33rem ;
        margin-left:0.17rem ;
    }
    .yuan1 img{
        width:0.06rem;
        height: 0.06rem;
        display: block;
    }
    .yuan2{
        width:0.06rem;
        height: 0.06rem;
        float:right;
        margin-top:0.33rem ;
        margin-right:0.17rem ;
    }
    .yuan2 img{
        width:0.06rem;
        height: 0.06rem;
        display: block;
    }
    .chu{
        font-size: 0.3rem;
        color: #666;
        text-align: center;
        line-height: 0.7rem;
        display: block;
        float: left;
        margin-left: 0.17rem;
    }
    .tips{
        width:100%;
        height:1.4rem;
        margin-top: 0.22rem;
        background: #FFFFFF;
        position: relative;
    }
    .tips img{
        width:7rem;
        height: 1.4rem;
        display: block;

    }
    .car{
        position: absolute;
        top:0.29rem;
        left:0.18rem;
        width:0.99rem;
        height:0.78rem;
    }
    .car img{
        width:0.99rem;
        height:0.78rem;
    }
    .qian{
        position: absolute;
        top:0.29rem;
        left:1.17rem;
        width:2.99rem;
        height:0.79rem;
    }
    .qian img{
        width:2.99rem;
        height:0.79rem;
        position:relative;
    }
    .rmb{
        width: 0.8rem;
        font-size: 0.16rem;
        color:#CAD3D3;
        position:absolute;
        top:0.23rem;
        left:0.57rem;
        outline: none;
        border:none;
        background: none;
    }
    .jiao{
        position: absolute;
        top:0.29rem;
        left:4.16rem;
        width:1.98rem;
        height:0.79rem;border-radius: 0.4rem;

        background: #F4F2F1;
    }
    .jiao>input{
        width: 100%;height: 100%;text-align: center;outline: none;background: none;border: 0.03rem solid #eee;box-shadow: none;border-radius: 0.4rem;box-sizing: border-box;
    }
    .jiao img{
        width:1.98rem;
        height:0.79rem;
        position: relative;
    }
    .gengduo{
        position: absolute;
        top:0.29rem;
        left:6.15rem;
        width:0.85rem;
        height:0.79rem;
    }
    .gengduo img{
        width:0.85rem;
        height:0.79rem;
    }
    .ding{
        width:0.21rem;
        height:0.24rem;
        position: absolute;
        top:0;
        right:0;
    }
    .ding img{
        width:0.21rem;
        height:0.24rem;
        display: block;
    }
</style>
<template>
    <div class="head">
        <div class="left"></div>
        <div class="mid"></div>
        <div class="right"></div>
    </div>
</template>

<script>
    export default {
        name: 'app'
    }
</script>

<style scoped>
    .head{
        width: 7.1rem;height: 0.8rem;padding: 0 0.2rem;display: flex;justify-content: space-between;
    }
    .left{
        width: 0.6rem;height: 0.6rem;background: url("/src/assets/img/zyx/xinfeng.png");
        background-size: 1.1rem 0.6rem;margin-top: 0.05rem;
    }
    .mid{
        width: 1.1rem;height: 0.6rem;background: url("/src/assets/img/zyx/logo.png");
        background-size: 1.1rem 0.6rem;
    }
    .right{
        width: 0.6rem;height: 0.6rem;background-image: url("/src/assets/img/zyx/xinfeng.png");
        background-size: 1.1rem 0.6rem;margin-top: 0.05rem;
        background-position:0.55rem 0;
    }
</style>
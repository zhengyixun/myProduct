<template>
<div>
    <img src="/src/assets/img/sou (7).png" alt="" class="pho">
    <img src="/src/assets/img/sou (9).png" alt="" class="flag">
</div>
</template>

<script>
    export default {

    }
</script>

<style scoped>
    .part-nei .pho{
        width:1.34rem; height:1.34rem; float:left; z-index: 1;
        position:absolute; top:0.03rem; left:0.3rem;
    }
    .part-nei .flag{
        width:0.64rem; height:0.4rem; position:absolute; right:0.16rem;
        top:-0.06rem;
    }
</style>
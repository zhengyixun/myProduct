<template>
    <div class="bck" style="height: 6.6rem;margin-top: 0.05rem">
        <router-link to="/regInput" class="a">注册</router-link>
        <router-link to="/loginInput" class="a">登录</router-link>
        <router-view></router-view>
    </div>
</template>

<script>
    export default {

    }
</script>

<style scoped>
    .bck{
        background: url("/src/assets/img/login.png") center no-repeat;
        background-size: 100% 110%;
    }
    .a{
        color: #fff;
    }
</style>
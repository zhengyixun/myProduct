<template>
    <div id="back">
        <div class="titBox">
            <div class="goback" style="position: relative;" @touchstart="back()">
                <img style="position:absolute;left: 0;right:0;top:0;bottom: 0;margin: auto;height:0.16rem;" src="/src/assets/img/wzd/huilv-mubiao_03.png" alt="">
            </div>
            <span>CHARS</span>
            <div class="add">
                <img src="/src/assets/img/wzd/chars_03.png" alt="">
            </div>
        </div>
        <div class="charBox">
            <div class="char1">
                <div class="userPhoto">
                    <img src="/src/assets/img/wzd/zzz.jpg" alt="">
                </div>
                <div class="charCon">
                    <p>这是收到的一条信息。</p>
                    <div class="seePoint"></div>
                </div>
            </div>
            <div class="char2">

                <div class="charCon">
                    <div class="seePoint"></div>
                    <p style="color: #333;">这是回复的一条信息。</p>
                </div>
            </div>
        </div>
        <div class="bottomInput">
            <div class="point"></div>
            <div class="point2"></div>
            <input type="text">
            <div class="blueBox">
                <img src="/src/assets/img/wzd/chars_07.png" alt="">
            </div>
            <div class="blueBox">
                <img src="/src/assets/img/wzd/chars_09.png" alt="">
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        methods:{
            back(){
                this.$router.go(-1);
            }
        }
    }
</script>

<style scoped>
    .char1>.charCon>.seePoint{
        width: 0.06rem;
        height: 0.06rem;
        border:0.04rem solid #bbf2d5;
        border-radius: 50%;
        float: left;
        position: absolute;
        left:0;
        bottom: -0.25rem;
    }
    .char2>.charCon{
        position: relative;
    }
    .char2>.charCon>.seePoint{
        width: 0.06rem;
        height: 0.06rem;
        border:0.04rem solid #bbf2d5;
        border-radius: 50%;
        float: left;
        position: absolute;
        right:0.6rem;
        bottom: -0.25rem;
    }
    .point{
        width: 0.05rem;
        height: 0.05rem;
        border-radius: 50%;
        background: #3b89fe;
        position: absolute;
        left:0.6rem;
        top:0.55rem;
    }
    .point2{
        width: 0.05rem;
        height: 0.05rem;
        border-radius: 50%;
        background: #1cb953;
        position: absolute;
        left:0.7rem;
        top:0.55rem;
    }
    .blueBox{
        width: 0.5rem;
        height: 0.5rem;
        border-radius: 50%;
        background: #0aa7dc;
        margin-right: 0.19rem;
        float: left;
        position: relative;
    }
    .blueBox img{
        width:0.28rem;
        height:0.28rem;
        position: absolute;
        left:0;
        right:0;
        top:0;
        bottom:0;
        margin:auto;
    }
    input{
        padding: 0 0.4rem;
        box-sizing: border-box;
        cursor: none;
        float: left;
        width: 5.55rem;
        height:0.5rem;
        margin-left: 0.36rem;
        margin-right: 0.17rem;
        border-radius: 0.25rem;
        border:0.02rem solid #4bafef;
    }
    .bottomInput{
        width: 100%;
        height: 0.88rem;
        position: fixed;
        left: 0;
        bottom: 0;
        background: #e0fefd;
        padding-top: 0.3rem;
    }
    .charBox{
        width: 100vw;
        height: 12rem;
        position: relative;
        bottom: 0;
        left:0;
        background: #e0fefd;
        padding: 0.29rem 0.22rem;
        box-sizing: border-box;
    }
    .char2{
        width: 100%;
        height: 1rem;
    }
    .char2>.charCon{
        float: right;
        max-width: 4rem;
        min-width: 1rem;
        height: 0.5rem;
        background: #fff;
        box-shadow: 0 0 0.03rem 0.05rem #dfeeee;
        border-radius: 0 0.25rem 0.25rem 0.25rem;
    }
    .char1{
        width: 100%;
        height: 1.5rem;
    }
    .userPhoto{
        width: 0.8rem;
        height:0.8rem;
        border-radius:0.03rem;
        background: #fff;
        box-shadow: 0 0.03rem 0.1rem 0.05rem #e4e4e4;
        overflow: hidden;
        float: left;
    }
    .userPhoto img{
        float: left;
        width: 0.8rem;
        height: 0.8rem;
    }
    .char1>.charCon{
        float: left;
        margin-left: 0.26rem;
        margin-top:  0.08rem;
        max-width: 4rem;
        min-width: 1rem;
        height: 0.5rem;
        background: #0aa7dc;
        border-radius: 0 0.25rem 0.25rem 0.25rem;
        box-shadow: 0 0 0.03rem 0.05rem #dfeeee;
        position: relative;
    }
    .charCon>p{
        width: 100%;
        height: 100%;
        font-size: 0.2rem;
        color: #fff;
        padding: 0.05rem 0.25rem;
        box-sizing: border-box;
    }

    #back{
        width:100vw;
        height:100vh;
        background-image:-webkit-linear-gradient(0deg, #39a5df, #39dd96);
        overflow: hidden;
    }
    .titBox{
        width:100vw;
        height:0.43rem;
        color:#fff;
        text-align: center;
        line-height: 1;
        font-size: .4rem;
        padding-top: 0.6rem;
        position: relative;
        padding-bottom: 1rem;
    }
    .goback{
        float: left;
        width: 0.58rem;
        height: 0.36rem;
        border-radius: 0.1rem;
        border:0.02rem solid #fff;
        background: #4dade4;
        position: absolute;
        left: 0.24rem;
        bottom:0;
        font-size: .1rem;
        text-align: center;
        line-height: 1;
    }
    .add{
        width: 0.57rem;
        height: 0.57rem;
        background: #0aa6dd;
        border:0.02rem solid #fff;
        border-radius:50%;
        position: absolute;
        right:0.24rem;
        bottom: 0.25rem;
    }
    .add>img{
        height: 0.3rem;
        position: absolute;
        left:0;
        right:0;
        top:0;
        bottom:0;
        margin: auto;
    }
</style>
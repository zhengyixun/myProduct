<template>
<div style="position: absolute;top:0;left:0;width: 100%" id="back">

        <img src="/src/assets/img/wzd/img1.png" style="position:absolute;right:0.25rem;top:0.72rem;width:0.33rem;">
        <div class="photo">
            <div class="photoLeft PBox">
                <img src="/src/assets/img/wzd/img(2).png">
            </div>
            <div class="photoRight PBox">
                <img src="/src/assets/img/wzd/img(3).png">
            </div>
            <div class="myPhoto">
                <div class="imgBox">
                    <img src="/src/assets/img/wzd/zzz.jpg" class="imgBoxImg">
                </div>
            </div>
        </div>
        <div class="infoBox">
            <span class="name">{{name}}</span>
            <span>星级</span>
            <p @touchstart="tuiwen">点击 查看更多</p>
        </div>
    <conBox></conBox>
    </div>
</template>

<script>
    import conBox from "@/components/wzd/conBox"
    export default {
        data(){
          return{
              name:''
          }
        },
        components: {conBox},
        methods:{
            tuiwen(){
                this.$router.push("/tuiwen")
            }
        },
        created(){
            this.name=sessionStorage.uname?sessionStorage.uname:''
        }
    }
</script>

<style scoped>
    #back{
        width:100vw;
        height:100vh;
        background-image:
                -webkit-linear-gradient(0deg, #39a5df, #39dd96);
        overflow: hidden;
    }
    .photo{
        width:4.1rem;
        height:1.76rem;
        margin:0 auto;
        margin-top:1.25rem;
    }
    .myPhoto{
        margin:0 auto;
        width:1.5rem;
        height:1.5rem;
        border-radius:50%;
        background:#80d3d8;
        border:0.12rem solid #56c4cd;
        position:relative;
    }
    .imgBox{
        width:.99rem;
        height:.99rem;
        border-radius:50%;
        background:#ace3e4;
        border:.13rem solid #ace5e2;
        position:absolute;
        top:0;bottom:0;left:0;right:0;
        margin:auto;
    }
    .imgBoxImg{
        float: left;
        width:100%;
        height:100%;
        background:red;
        border-radius:50%;
    }
    .photoLeft{
        width:0.65rem;
        height:0.65rem;
        border-radius:50%;
        background:#45d0bb;
        float:left;
        margin-top:0.57rem;
    }
    .photoRight{
        width:0.65rem;
        height:0.65rem;
        border-radius:50%;
        background:#49f4f8;
        float:right;
        margin-top:0.57rem;
    }
    .PBox{
        position:relative;
    }
    .PBox img{
        height:0.33rem;
        position:absolute;
        left:0;top:0;right:0;bottom:0;
        margin:auto;
    }
    .infoBox{
        margin-top:0.20rem;
        width:100%;
        height:1.4rem;
        text-align:center;
        font-size:0.12rem;
    }
    .infoBox span,.infoBox>p{
        display:block;color:#fff;
        margin-bottom:0.05rem;
    }
    span.name{
        font-size:0.3rem;
        font-weight:bold;
    }
</style>
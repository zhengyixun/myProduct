<template>
    <div id="back">
        <div class="titBox">
            <div class="goback" style="position: relative;" @touchstart="back">
                <img style="position:absolute;left: 0;right:0;top:0;bottom: 0;margin: auto;height:0.16rem;" src="/src/assets/img/wzd/huilv-mubiao_03.png" alt="">
            </div>
            <span>用户目标</span>
        </div>
        <div class="Con">
            <div class="conLeft moneyCon">
                <span>小主本月还可花：</span>
                <div class="box">
                    <div class="yang">
                        <img src="/src/assets/img/wzd/huilv-mubiao_07.png" alt="">
                    </div>
                    <span class="moneyNum">{{gsheng}}.00</span>
                </div>
            </div>
            <div class="conRight moneyCon">
                <span>小主的本月目标：</span>
                <div class="box">
                    <div class="yang">
                        <img src="/src/assets/img/wzd/huilv-mubiao_07.png" alt="">
                    </div>
                    <span class="moneyNum">{{gmax}}.00</span>
                </div>
            </div>
        </div>
        <conBot></conBot>
    </div>
</template>
<script>
    import conBot from "@/components/wzd/conBot.vue"
    export default {
        data(){
            return {
                gsheng:"",
                gmax:""
            }
        },
        components: {conBot},
        methods:{
            back(){
                this.$router.go(-1);
            }
        },
        created(){
            var that=this;
            fetch("/ajax/quser/goal",{
                method:"post",
                headers:{
                    "content-type":"application/x-www-form-urlencoded"
                },
                body:"uid="+sessionStorage.uid
            }).then(function(e){
                return e.json();
            }).then(function(e){
                that.gsheng=e[0].gsheng;
                that.gmax=e[0].gmax;
            })
        }
    }
</script>
<style scoped>
    #back{
        width:100vw;
        height:100vh;
        background-image:-webkit-linear-gradient(0deg, #39a5df, #39dd96);
        overflow: hidden;
    }
    .titBox{
        width:100vw;
        height:0.43rem;

        padding-top: 0.6rem;
        position: relative;
        margin-bottom: 1rem;
    }
    .titBox>span{
        color:#fff;font-size: .4rem;text-align: center;
        line-height: 1;
    }
    .goback{
        float: left;
        width: 0.58rem;
        height: 0.36rem;
        border-radius: 0.1rem;
        border:0.02rem solid #fff;
        background: #4dade4;
        position: absolute;
        left: 0.24rem;
        bottom:0;
        font-size: .1rem;
        text-align: center;
        line-height: 1;
    }
    .Con{
        width: 100vw;
        height: 1rem;
    }
    .moneyCon{
        float: left;
        width: 50vw;
        height: 100%;
        position: relative;
    }
    .moneyCon>span{
        text-align: center;
        color: #fff;
        font-size: 0.2rem;
    }
    .moneyCon .box{
        margin-top: 0.2rem;
        width: 100%;
        height: .44rem;
    }
    .moneyNum{
        display: block;
        font-size: 0.44rem;
        float: right;
        color:#fff;
    }
    .yang{
        width:0.29rem;
        height: 0.29rem;
        float: right;
        margin-right: 0.9rem;
        margin-left: 0.15rem;
        margin-top: 0.15rem;
        position: relative;
    }
    .yang img{
        width: 100%;
        position: absolute;
        left: 0;
        top: 0;
        right:0;
        bottom:0;
        margin: auto;
    }
</style>
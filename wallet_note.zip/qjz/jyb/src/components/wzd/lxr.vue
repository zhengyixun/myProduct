<template>
    <div class="">
        <div class="conLeft">
            <div class="listBox">
                <div class="titBox">
                    <div class="tit">A</div>
                    <span>38</span>
                </div>
                <div class="list" @touchstart="talk">
                    <div class="myPhoto">
                        <img src="/src/assets/img/wzd/zzz.jpg" alt="">
                    </div>
                    <span class="name">Angle</span>
                    <span class="con">好开心！</span>
                    <div class="point"></div><span class="classes">运城学院 美术与工艺技术系</span>
                </div>
                <div class="list" @touchstart="talk">
                    <div class="myPhoto">
                        <img src="/src/assets/img/wzd/zzz.jpg" alt="">
                    </div>
                    <span class="name">Ann</span>
                    <span class="con">我又花超了。</span>
                    <div class="point"></div><span class="classes">艺术设计学院学院</span>
                </div>
            </div>
            <div class="listBox">
                <div class="titBox">
                    <div class="tit">B</div>
                    <span>99</span>
                </div>
                <div class="list" @touchstart="talk">
                    <div class="myPhoto">
                        <img src="/src/assets/img/wzd/zzz.jpg" alt="">
                    </div>
                    <span class="name">BLACK</span>
                    <span class="con">双十一又要剁手了~</span>
                    <div class="point"></div><span class="classes">艺术设计学院学院</span>
                </div>
                <div class="list">
                    <div class="myPhoto" @touchstart="talk">
                        <img src="/src/assets/img/wzd/zzz.jpg" alt="">
                    </div>
                    <span class="name">Big Bang</span>
                    <span class="con">大家一起来记账吧~</span>
                    <div class="point"></div><span class="classes">艺术设计学院学院</span>
                </div>
            </div>
        </div>
        <ul class="conRight">
            <li>A</li>
            <li>B</li>
            <li>C</li>
            <li>D</li>
            <li>E</li>
            <li>F</li>
            <li>G</li>
            <li>H</li>
            <li>I</li>
            <li>J</li>
            <li>K</li>
            <li>L</li>
            <li>M</li>
            <li>N</li>
        </ul>
    </div>
</template>

<script>
    export default {
        methods:{
            talk(){
                this.$router.push("/chat")
            }
        }
    }
</script>

<style scoped>
    .conRight{
        height: 7.5rem;
        width: 0.4rem;
        float: right;
        display: flex;
        flex-direction: column;
        justify-content: space-around;
        font-weight: bold;
        text-align: center;
    }
    .conRight>li{
        color: #d3e1e0; font-size: 0.18rem;
    }
    .conLeft{
        width: 6.6rem;
        height: auto;
        margin-left: 0.24rem;
        float: left;
    }
    .listBox{
        width: 6.6rem;
        height: auto;
    }
    .titBox{
        width: 100%;
        height: 0.64rem;
    }
    .titBox span{
        float: left;
        font-size: 0.3rem;
        font-weight: bold;
        color: #5a6684;
        margin-left: 0.21rem;
    }
    .tit{
        float: left;
        width: 0.39rem;
        height: 0.39rem;
        border-radius: 50%;
        background: #0ac2b9;
        font-size: 0.25rem;
        color: #fff;
        text-align: center;
        line-height: 0.39rem;
        border:0.04rem solid #bcdbfd;
    }
    .list{
        width: 6.6rem;
        height: 1.2rem;
        background: #fff;
        border:0.01rem solid #f2f6f6;
        border-radius: 0.05rem;
        margin-bottom: 0.07rem;
    }
    .myPhoto{
        width: 0.8rem;
        height:0.8rem;
        border-radius:0.03rem;
        margin: 0.2rem;
        background: #fff;
        float: left;
        box-shadow: 0 0.03rem 0.1rem 0.05rem #e4e4e4;
        overflow: hidden;
    }
    .myPhoto img{
        float: left;
        width: 0.8rem;
        height: 0.8rem;
    }
    .list span{
        display: block;
    }
    .name{
        font-size: 0.2rem;
        color: #255dff;
        font-weight: bold;
    }
    .con{
        font-size: 0.2rem;
        color: #a6a6a6;
        display: block;
    }
    .classes{
        font-size: 0.14rem;
        color: #a6a6a6;
    }
    .point{
        width: 0.06rem;
        height: 0.06rem;
        border-radius: 50%;
        border: 0.04rem solid #cef1d1;
        background: #26c435;
        float: left;
        margin-top: 0.14rem;
        margin-right: 0.1rem;
    }

</style>
<template>
    <div id="back">
        <div class="titBox">
            <div class="goback" style="position: relative;" @touchstart="back">
                <img style="position:absolute;left: 0;right:0;top:0;bottom: 0;margin: auto;height:0.16rem;" src="/src/assets/img/wzd/huilv-mubiao_03.png" alt="">
            </div>
            <span>我的好友</span>
            <div class="add">+</div>
        </div>
        <div class="inputBox">
            <div class="input-friend">好友</div>
            <div class="input-news">消息</div>
        </div>
        <div class="Bottom">
            <div class="gongnengBox">
                <div class="tongXun" style="margin-left: 0.24rem;">
                    <div class="blueBox">
                        <img src="/src/assets/img/wzd/py(1).png" alt="">
                    </div>
                    <span class="engTit">Address book</span>
                    <span class="zhTit">通讯录</span>
                </div>
                <div class="tongXun" style="margin-left: 0.24rem;">
                    <div class="blueBox">
                        <img src="/src/assets/img/wzd/py(2).png" alt="">
                    </div>
                    <span class="engTit">My Friends</span>
                    <span class="zhTit">好友</span>
                </div>
            </div>
            <div class="sousuoBox">
                <input type="text" placeholder="请输入您想要查找的联系人">
            </div>
            <lxr></lxr>
        </div>
    </div>
</template>

<script>
    import lxr from "@/components/wzd/lxr.vue"
    export default {
        components: {lxr},
        methods:{
            back(){
                this.$router.go(-1);
            }
        }
    }
</script>

<style scoped>
    .sousuoBox{
        width: 100%;
        height:0.5rem;
        margin-bottom: 0.3rem;
    }
    .sousuoBox input{
        display: block;
        width: 6.45rem;
        height: 0.5rem;
        margin: 0 auto;
        border-radius: 0.25rem;
        border: none;
        color: #a1a1a1;
        font-size: 0.2rem;
        padding-left: 0.4rem;
        box-sizing: border-box;
        box-shadow: 0 0.02rem 0.3rem 0.03rem #81edc6;
    }
    ::-webkit-input-placeholder {
        color:#d4d4d5;
        font-size: 0.1rem;
    }
    .gongnengBox{
        width: 100%;
        height: 1.91rem;
    }
    .tongXun{
        width: 3.43rem;
        height: 1.23rem;
        background: #fff;
        border-radius: 0.05rem;
        overflow: hidden;
        float: left;
        margin-top: 0.26rem;
    }
    .blueBox{
        width: 0.92rem;
        height: 0.92rem;
        border-radius: 50%;
        background: linear-gradient(0deg, #39a5df, #39dd96);
        margin-top: 0.15rem;
        margin-left: 0.18rem;
        float:left;
        margin-right: 0.13rem;
        position: relative;
    }
    .blueBox img{
        width:0.41rem;
        position: absolute;
        top: 0;
        bottom: 0;
        left:0;
        right: 0;
        margin: auto;
    }
    .zhTit{
        font-size: 0.2rem;
        color: #bcbfc4;
        display: block;
        float: left;
        padding-right: 0.34rem;
    }
    .engTit{
        margin-top: 0.2rem;
        font-size: 0.3rem;
        color: #838ca3;
        display: block;
        float: left;
        font-weight: bold;
    }
    #back{
        width:100vw;
        height:100vh;
        background-image:-webkit-linear-gradient(0deg, #39a5df, #39dd96);
        overflow: hidden;
    }
    .titBox{
        width:100vw;
        height:0.43rem;
        text-align: center;

        padding-top: 0.6rem;
        position: relative;
        padding-bottom: 1rem;
    }
    .titBox>span{
        color:#fff;
        line-height: 1;
        font-size: .4rem;
    }
    .goback{
        float: left;
        width: 0.58rem;
        height: 0.36rem;
        border-radius: 0.1rem;
        border:0.02rem solid #fff;
        background: #4dade4;
        position: absolute;
        left: 0.24rem;
        bottom:0;
        font-size: .1rem;
        text-align: center;
        line-height: 1;
    }
    .add{
        width: 0.57rem;
        height: 0.57rem;
        background: #0aa6dd;
        box-shadow: 0 0.03rem 0.1rem 0.03rem #0aa6dd;
        border-radius:50%;
        position: absolute;
        right:0.24rem;
        bottom: 0.25rem;
        color: #fff;line-height: 0.6rem;text-align: center;
    }
    .inputBox{
        width: 3.32rem;
        height: 0.5rem;
        background:#fff;
        border:0.02rem solid #fff;
        margin: 0.01rem auto;
        margin-bottom: 0.25rem;
        border-radius: 0.2rem;
    }
    .input-friend{
        width: 1.6rem;
        height: 0.5rem;
        border-radius: 0.2rem;
        background-image:linear-gradient(-180deg, #0adb99, #0ab2cf);
        border:0.02rem solid #5adac9;
        text-align: center;
        line-height: 0.4rem;
        color: #fff;
        font-size: 0.2rem;
        float: left;
        box-sizing: border-box;
    }
    .input-news{
        width: 1.6rem;
        height: 0.5rem;
        border-radius: 0.2rem;
        background: #eeeeef;
        border:0.02rem solid #d9d9dd;
        text-align: center;
        line-height: 0.4rem;
        color: #909090;
        font-size: 0.2rem;
        float: right;
        box-sizing: border-box;
    }
    .Bottom{
        position: relative;
        left:0;
        bottom:0;
        width: 100%;
        height:12rem;
        background: #e0fefd;
    }
</style>
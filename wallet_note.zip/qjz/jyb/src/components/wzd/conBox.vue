<template>
    <div class="conBox">
        <div class="gongneng">
            <div class="zhangben gongnengBtn">
                <div class="iconBox">
                </div>
                <img src="/src/assets/img/wzd/img(5).png">
                <div class="cate">
                    <span class="span1" style="margin-top:0.25rem;">账本</span>
                </div>
            </div>
            <div class="zhuanzhang gongnengBtn">
                <img src="/src/assets/img/wzd/img(6).png">
                <div class="iconBox">

                </div>
                <div class="cate">
                    <span class="span1" style="margin-top:0.25rem;">转账</span>
                </div>
            </div>
            <div class="qianbao gongnengBtn">
                <img src="/src/assets/img/wzd/img(4).png">
                <div class="iconBox">

                </div>
                <div class="cate">
                    <span class="span1" style="margin-top:0.25rem;">钱包</span>
                </div>
            </div>
        </div>
        <ul class="listBox">
            <li>
                <div class="listIconBox">
                    <img src="/src/assets/img/wzd/img(7).png" alt="">
                </div>
                <div  class="JTBox" @touchstart="mubiao">
                    <span class="tit">用户目标</span>
                    <div class="jiantou"> > </div>
                    <div class="state"><span style="color:#93d08e">800</span> 状态</div>
                </div>
            </li>
            <li>
                <router-link to="myFriend">
                <div class="listIconBox">
                    <img src="/src/assets/img/wzd/img(8).png" alt="">
                </div>
                    <div class="JTBox">
                        <span class="tit">好友管理</span>
                        <div class="jiantou"> > </div>
                        <div class="state"><span style="color:#93d08e"></span> 未同步手机通讯录</div>
                    </div>
                </router-link>
            </li>
            <li>
                <div class="listIconBox">
                    <img src="/src/assets/img/wzd/img(9).png" alt="">
                </div>
                <div class="JTBox">
                    <span class="tit">银行卡绑定</span>
                    <div class="jiantou"> > </div>
                    <div class="state"><span style="color:#93d08e"></span>已绑定</div>
                </div>
            </li>
            <li>
                <div class="listIconBox">
                    <img src="/src/assets/img/wzd/img(10).png" alt="">
                </div>
                <div class="JTBox">
                    <span class="tit">游 戏</span>
                    <div class="jiantou"> > </div>
                    <div class="state"><span style="color:#93d08e"></span></div>
                </div>
            </li>
            <li class="loginOut" @touchstart="loginOut">
                <div class="listIconBox">
                    <img src="/src/assets/img/wzd/img(10).png" alt="">
                </div>
                <div class="JTBox JTBox1">
                    <span class="tit">退出登录</span>
                    <div class="jiantou"> > </div>
                    <div class="state"><span style="color:#93d08e"></span></div>
                </div>
            </li>
        </ul>
    </div>
</template>
<script>
    export default {
        methods:{
            mubiao(){
                this.$router.push("/mubiao")
            },
            loginOut(){
                sessionStorage.removeItem("uid");
                sessionStorage.removeItem("uname");
                sessionStorage.removeItem("uphone");
                this.$router.push("/")
            }
        }
    }
</script>

<style scoped>

    .conBox{
        width:6.83rem;
        height:7.93rem;
        margin:0 auto;
        background:#edf3f2;
        overflow: hidden;
    }
    .gongneng{
        margin-top:0.5rem;
        display:flex;
        justify-content: space-around;
        padding-bottom:.27rem;
    }
    .gongnengBtn{
        width:1.83rem;
        height:0.94rem;
        border-radius:0.72rem;
        box-shadow:0rem 0.08rem 0.25rem #39c0bc;
        position:relative;
    }
    .gongnengBtn img{
        width:0.42rem;
        height:0.42rem;
        position:absolute;
        top:0.25rem;left:0.29rem;
    }
    .zhangben{
        background:#3be55b;
    }
    .zhuanzhang{
        background:#39c1ba;
    }
    .qianbao{
        background:#39a5de;
    }
    .iconBox{
        width:0.72rem;
        height:0.72rem;
        border-radius: 50%;
        background:#231f20;
        opacity: .2;
        margin:0.12rem;
        float:left;
    }

    .Cate{
        margin-top:0.12rem;
    }
    .span1{
        font-size:.27rem;
        color:#fff;
    }
    .cate span{
        display:block;
    }
    .listBox{
        width:6.3rem;
        height:auto;
        margin:0 auto;
    }
    .listBox li{
        width:100%;
        height:1.08rem;
        margin-bottom:0.11rem;
        border-radius:.2rem;
        background:#fff5f5;
        overflow: hidden;
    }
    .listIconBox{
        width:.62rem;
        height:.62rem;
        border-radius:50%;
        background:#9cd6de;
        margin:0.27rem;
        float:left;
        position:relative;
    }
    .listIconBox img{
        width:0.33rem;
        height:0.33rem;
        position:absolute;
        left:0;right:0;top:0;bottom:0;
        margin:auto;
    }
    .JTBox{
        width:6.3rem;
        height:1.08rem;
        position:relative;
    }
    .tit{
        float:left;
        font-size:.27rem;
        color:#939696;
        margin-top:0.35rem;
        font-weight:bold;
    }
    .jiantou{
        width:.27rem;
        height:.27rem;
        font-size:.2rem;
        color:#3ab5c9;
        background:#ffffff;
        border-radius:50%;
        line-height:.27rem;
        text-align:center;
        position:absolute;
        right:0.29rem;
        bottom:0;
        top:0;
        margin:auto;
    }
    .state{
        width:auto;
        height:.4rem;
        font-size:.15rem;
        position:absolute;
        right:0.6rem;
        bottom:0;
        top:0;
        margin:auto;
        color:#d3caca;
    }
    .loginOut{
        background: #D9534F;
    }
    .JTBox1{
        background: none;
    }
</style>
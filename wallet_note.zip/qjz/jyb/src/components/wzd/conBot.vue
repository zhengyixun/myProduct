<template>
    <div class="conBot">
        <div class="conListBox">
            <div class="conList">
                <span class="tit">本月余额目标</span>
                <input type="text" class="moneyNum"  v-model="gsheng" style="text-align: center">
                <div class="iconBox"  @touchstart="submit">
                    <img src="/src/assets/img/wzd/huilv-mubiao_11.png" alt="">
                </div>
            </div>
            <div class="con658"></div>
            <div class="con614"></div>
        </div>
        <div class="conListBox">
            <div class="conList">
                <span class="tit">储蓄目标</span>
                <input type="text" class="moneyNum" v-model="gmax" style="text-align: center">
                <div class="iconBox" @touchstart="submit">
                    <img src="/src/assets/img/wzd/huilv-mubiao_15.png" alt="">
                </div>
            </div>
            <div class="con658"></div>
            <div class="con614"></div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                gsheng:'',
                gmax:''
            }
        },
        methods:{
          submit(){
              var that=this;
              fetch("/ajax/quser/updateGoal",{
                  method:"post",
                  headers:{
                      "content-type":"application/x-www-form-urlencoded"
                  },
                  body:"uid="+sessionStorage.uid+"&gsheng="+that.gsheng+"&gmax="+that.gmax
              }).then(function(e){
                  return e.text();
              }).then(function(e){
                  console.log(e);
                  that.$router.push("/index");
              })
          }
        },
        created(){
            var that=this;
            fetch("/ajax/quser/goal",{
                method:"post",
                headers:{
                    "content-type":"application/x-www-form-urlencoded"
                },
                body:"uid="+sessionStorage.uid
            }).then(function(e){
                return e.json();
            }).then(function(e){
                that.gsheng=e[0].gsheng;
                that.gmax=e[0].gmax;
            })
        }

    }
</script>

<style scoped>
    .conBot{
        position: fixed;
        bottom: 0;
        left:0;
        width: 100vw;
        height: 9rem;
        background: #f4f2f1;
    }
    .conListBox{
        width: 100%;
        height: 3.27rem;
    }
    .conList {
        background: #fff;
        width: 6.98rem;
        height: 2.17rem;
        margin:0 auto;
        margin-top: 0.76rem;
        border-radius: 0.1rem;
        text-align: center;
        font-weight: bold;
        position: relative;
    }
    .iconBox{
        position: absolute;
        left: 0;right: 0;
        margin: 0 auto;
        top: -0.43rem;
        width: 0.83rem;
        height: 0.83rem;
        background: #0ad0a7;
        border-radius: 50%;
        box-shadow: 0 0.05rem 0.2rem 0.01rem #0ad0a7;
    }
    .iconBox img{
        width: 0.48rem;
        position: absolute;
        left: 0;right: 0;
        top:0; bottom: 0;
        margin:auto;
    }
    .con614{
        width: 6.14rem;
        height: 0.16rem;
        border-radius: 0 0 0.1rem 0.1rem;
        margin:0 auto;
        background: #b0e2ea;
    }
    .con658{
        width: 6.58rem;
        height: 0.16rem;
        border-radius: 0 0 0.1rem 0.1rem;
        margin:0 auto;
        background: #4bcde4;
    }
    .conList span:first-child{
        display: block;
        color: #0aa6de;
        font-size: 0.28rem;
        padding-top: 0.64rem;
    }
    .moneyNum{
        display: block;
        color: #0ac2ba;
        font-size: 0.3rem;
        padding-top: 0.3rem;
        width: 5.35rem;
        margin: 0 auto;
        outline: none;
        background: none;
        box-shadow: none;
        border: none;
        border-bottom: 0.02rem solid #b5b5b5;

    }
</style>
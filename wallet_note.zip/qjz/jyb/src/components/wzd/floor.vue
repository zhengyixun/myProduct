<template>
        <div class="floor">
            <div class="floorLeft" @touchstart="jyb">
                <img src="/src/assets/img/wzd/img(13).png">
            </div>

            <div class="floorRight" @touchstart="myinfo">
                <img src="/src/assets/img/wzd/img(12).png">

            </div>
            <div class="floorCenter" @touchstart="indexs">
                <img src="/src/assets/img/wzd/img11).png">
            </div>
        </div>
</template>

<script>
    export default {
        methods:{
            indexs(){
                this.$router.push("/index")
            },
            jyb(){
                this.$router.push("/jyb")
            },
            myinfo(){
                this.$router.push("/myinfo")
            }
        }
    }
</script>

<style scoped>
.floor{
    width:100%;
    height:0.98rem;
    background:#2d3541;
    position:absolute;
    bottom:0;
    left:0;
}
.floorLeft{
    background:#2e3642;
    width:0.8rem;
    height:0.8rem;
    border-radius:50%;
    border:1px solid #303946;
    margin-left:0.66rem;
    margin-top:0.08rem;
    float:left;
    text-align: center;
    line-height: .3rem;
}
.floorRight{
    float:right;
    background:#2e3642;
    width:0.8rem;
    height:0.8rem;
    border-radius:50%;
    border:1px solid #303946;
    margin-right:0.66rem;
    margin-top:0.08rem;
    text-align: center;
    line-height: .3rem;
}
.floorRight span{
    color:#fff;
    font-size:.5px;
}
.floorLeft,.floorRight{
    position:relative;
}
.floorLeft img,.floorRight img{
    width:0.55rem;
    position:absolute;
    left:0;right:0;top:0;bottom:0;
    margin:auto;
}
.floorCenter{
    width:1rem;
    height:1rem;
    border-radius:50%;
    background:#fbfbfb;
    text-align:center;
    line-height:0.5rem;
    position:relative;
    top:-0.3rem;
    left:0;right:0;
    margin:auto;
}
.floorCenter img{
    width:0.39rem;
    position:absolute;
    left:0;top:0;right:0;bottom:0;
    margin:auto;
    box-shadow:0 0 0.15rem #15dcc1;
}
</style>
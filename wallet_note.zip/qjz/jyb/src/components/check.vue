<template>
    <div class="check">
        <div class="gant"></div>
        <span>请输入内容</span>
    </div>
</template>

<script>
    export default {

    }
</script>

<style scoped>
    .check{
        width: 2.5rem;height: 0.45rem;background: #ff1a4b;border-radius: 0.4rem;
    }
    .gant{
        width: 0.35rem;height: 0.35rem;background: url('/src/assets/img/gant.png') center no-repeat;margin-left: 0.09rem;float: left;background-size: 0.35rem 0.35rem;margin-top: 0.05rem;
        border-radius: 50%;
    }
    span{
        color: #fff;line-height: 0.5rem;float: left;margin-left: 0.2rem;
    }
</style>
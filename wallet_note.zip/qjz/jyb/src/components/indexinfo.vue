<template>
<div>
    <head1 class="head1"></head1>
    <div class="months">
        <div>JUE</div>
        <div>FEB</div>
        <div>MAR</div>
        <div>JUE</div>
        <div>FEB</div>
        <div>MAR</div>
        <div>JUE</div>
        <div>FEB</div>
        <div>MAR</div>
        <div>JUE</div>
        <div>FEB</div>
        <div>MAR</div>
    </div>
    <div class="months months1">
        <div>1</div>
        <div>2</div>
        <div>3</div>
        <div>4</div>
        <div>5</div>
        <div>6</div>
        <div>7</div>
        <div>8</div>
        <div>9</div>
        <div>10</div>
        <div>11</div>
        <div>12</div>
    </div>
    <h6>小猪本月剩余大洋</h6>
    <router-link to="/mubiao" class="h1">
        <span>{{gsheng}}.00</span>
        <div class="mon"></div>
    </router-link>
    <!--本月进项-->
    <div class="thing">
        <router-link to="/mubiao" class="jin">
            <div class="zhi">本月支出大洋</div>
            <div class="zhi1">{{gmax-gsheng}}.00</div>
        </router-link>
        <!--zhih-->
        <router-link to="/mubiao" class="jin">
            <div class="zhi">本月进项大洋</div>
            <div class="zhi1">{{gmax}}.00</div>
        </router-link>
    </div>
    <div class="bck1">
        <div class="jian"></div>
        <div class="jyb">
            <div class="jyb1 jyb0" @touchstart="jyb0"></div>
            <div class="jyb1 jyb2"></div>
        </div>
        <div class="zd"></div>
        <!--日期-->
        <div class="date">
            <span>11.11</span>
            <span>SUN</span>
            <span>2017</span>
        </div>
        <!--信息-->
        <div class="info" @touchstart="xq" v-for="item in result">
            <div class="infoBox"></div>
            <span>{{item.zthing}}</span>
            <div class="rig">
                <span>{{item.zmoney}}</span>
                <span>RMB</span>
            </div>
        </div>

    </div>
    <!--弹出框-->
    <close v-show="flag"></close>
    <div class="clo" v-show="flag" @touchstart="clo"></div>
    <tan v-show="flag"></tan>
</div>
</template>

<script>
    import head1 from "@/components/zyx/head1"
    import tan from "@/components/zl/tan"
    import close from "@/components/zl/close"
    export default {
        data(){
          return{
              flag:false,
              result:[],
              gsheng:"",
              gmax:"",
          }
        },
        components:{ head1,tan,close },
        methods:{
            jyb0(){
                this.$router.push("/jyb")
            },
            xq(){
                this.flag=true;
            },
            clo(){
               this.flag=false;
            },

        },
        created(){
            var that=this;
            fetch("/ajax/quser/zhangdan",{
                method:"post",
                headers:{
                    "content-type":"application/x-www-form-urlencoded"
                },
                body:"uid="+sessionStorage.uid
            }).then(function(e){
                return e.json();
            }).then(function(e){
               that.result=e;
               console.log(that.result);
            });
            fetch("/ajax/quser/goal",{
                method:"post",
                headers:{
                    "content-type":"application/x-www-form-urlencoded"
                },
                body:"uid="+sessionStorage.uid
            }).then(function(e){
                return e.json();
            }).then(function(e){
                that.gsheng=e[0].gsheng;
                that.gmax=e[0].gmax;
            })
        }
    }
</script>

<style scoped>
    .clo{
        width: 0.73rem;height: 0.54rem;position: absolute;top: 1.25rem;right: 0.3rem;z-index: 999;
    }
    .head1{
        margin-top: 0.5rem;margin-bottom: 0.2rem;
    }
    .months{
        width: 7.1rem;height: 0.24rem;display: flex;justify-content: space-between;padding: 0 0.2rem;margin-bottom: 0.1rem;
    }
    .months1{
        justify-content: space-around;
    }
    .months>div{
        color: #fff;font-size: 0.15rem;
    }
    h6{
        color: #fff;margin-top: 0.4rem;
    }
    .h1{
        text-decoration: none;font-family: "苹方";height: 1.5rem;width: 5.5rem;display: block;margin: 0 auto;
    }
    .h1>span{
        font-size: 1.2rem;color: #fff;float: left;display: block;
    }
    .h1>.mon{
        width: 0.6rem;height: 0.6rem;background-image: url("../assets/img/zyx/mon.png");
        background-size: 1.2rem 0.6rem;float: left;margin-top: 0.8rem;
    }
    .thing{
        width: 7.1rem;height: 1.5rem;display: flex;justify-content: space-between;padding: 0 0.2rem;
    }
    .jin{
        width: 1.9rem;height: 0.9rem;
    }
    .jin>.zhi{
        font-family: "苹方";
        color: #fff;
    }
    .jin>.zhi1{
        color: #fff;font-size: 0.4rem;
    }
    .bck1{
        height: 6.8rem;width: 7.1rem;padding: 0.2rem 0.2rem;background: #e0fefd;
        position: relative;
    }
    .jian{
        position: absolute;width: 1.18rem;height: 0.4rem;left:0;right:0;
        margin-left: auto;margin-right: auto;
        top: -0.24rem;background-image: url("/src/assets/img/zyx/jian.png");
        background-size: 1.18rem 0.4rem;
    }
    .jyb{
        width: 100%;height: 1.5rem;display: flex;justify-content: space-between;
    }
    .jyb1{
        width: 3.4rem;height: 100%;background-image: url("/src/assets/img/zyx/jbz.png");
        background-size: 7.5rem 1.5rem
    }
    .jyb2{
        background-position: 3.4rem 0;
    }
    .zd{
        width: 100%;height: 0.88rem;background-image: url("/src/assets/img/zyx/zd.png");
        background-size: 7.1rem 0.88rem
    }
    .date{
        width: 100%;height: 0.27rem;
    }
    .date>span{
        color: #39a6de;font-size: 0.2rem;float: left;margin-left: 0.2rem;
    }
    .info{
        width: 100%;height: 0.9rem;border-radius: 0.1rem;background: #39a6de;margin-top: 0.15rem;padding-top: 0.1rem;
    }
    .infoBox{
        width: 0.8rem;height: 0.8rem;background: url("/src/assets/img/zyx/sma.png");
        background-size: 3.8rem 0.75rem;float: left;
    }
    .info>span{
        float: left;font-size: 0.2rem;color: #fff;line-height: 0.8rem;margin-left: 0.3rem;
    }
    .rig{
        width: 2rem;height: 100%;float: right;line-height: 0.8rem;color: #fff;
    }
    .rig>span{
        float: left;color: #fff;margin-right: 0.1rem;
    }
    /*弹出款*/

</style>
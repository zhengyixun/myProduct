<template>
    <div>
        <div class="header">
            <div class="header1"></div>
            <back class="back"></back>
            <span>搜索</span>
            <div class="searchInput">
                <div class="spot"></div>
                <input type="text" placeholder="请输入你想要的内容">
                <div class="mai"></div>
            </div>
        </div>
        <!--搜索热词-->
        <div class="part">
            <div class="part-head">
                <div class="line line1"></div>
                <span class="en">SOUSUORECI</span>
                <span class="cn">搜索热词</span>
            </div>
            <ul class="part-nei">
                <li>热词</li>
                <li>热词</li>
                <li class="hot_1">热词</li>
                <li class="hot_2">热词</li>
            </ul>
        </div>
        <div class="part">
            <div class="part-head">
                <div class="line line2"></div>
                <span class="en">REMENTUIJIAN</span>
                <span class="cn cn1">热门推荐</span>
            </div>
            <div class="part-nei">
                <img src="/src/assets/img/sou (13).png" class="back">
                <searchlist></searchlist>
                <img src="/src/assets/img/sou (11).png" alt="" class="wenhao">
                <div class="detail">
                    <p class="title_1">你的钱都去哪里了？</p>
                    <p class="title_2">生活中发现我们的钱不知不觉的少了</p>
                    <div class="ad">
                        <div class="spote"></div>
                        <div class="author">by.James</div>
                    </div>
                    <div class="ad">
                        <div class="spote spote1"></div>
                        <div class="date">11.3  2017</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="part">
            <div class="part-head">
                <div class="line line2"></div>
                <span class="en">REMENTUIJIAN</span>
                <span class="cn cn1">热门推荐</span>
            </div>
            <div class="part-nei">
                <img src="/src/assets/img/sou (13).png" class="back">
                <searchlist></searchlist>
                <div class="detail">
                    <p class="title_1">你的钱都去哪里了？</p>
                    <p class="title_2">生活中发现我们的钱不知不觉的少了</p>
                    <div class="ad">
                        <div class="spote"></div>
                        <div class="author">by.James</div>
                    </div>
                    <div class="ad">
                        <div class="spote spote1"></div>
                        <div class="date">11.3  2017</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="part">
            <div class="part-nei">
                <img src="/src/assets/img/sou (13).png" class="back">
                <searchlist></searchlist>
                <div class="detail">
                    <p class="title_1">你的钱都去哪里了？</p>
                    <p class="title_2">生活中发现我们的钱不知不觉的少了</p>
                    <div class="ad">
                        <div class="spote"></div>
                        <div class="author">by.James</div>
                    </div>
                    <div class="ad">
                        <div class="spote spote1"></div>
                        <div class="date">11.3  2017</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import back from "./back";
    import searchlist from "./searchlist";
    export default {
        components:{ back,searchlist },
        methods:{

        }
    }
</script>
<style scoped>
    .part-nei .back{
        width:6.7rem; height:1.62rem; float:right;
    }
    .part-nei .wenhao{
        width:0.41rem; height:0.41rem; position:absolute; left: 1.8rem;
        top:0.22rem;
    }
    .header{
        width: 100%;height:2.9rem;
    }
    .header1{
        width: 100%; height:0.4rem; margin-bottom: 0.22rem;
        background: url("/src/assets/img/sou (4).png") no-repeat center center;
    }
    .back{
        margin-left: 0.24rem;
    }
    span{
        font-size: 0.4rem; padding-top: 0.02rem; color:#fff; float:right;
        margin-right:3.35rem; margin-top: -0.48rem;
    }
    .searchInput{
        width:6.54rem; height:0.56rem; background: #fff; margin:0 auto;
        border-radius: 0.28rem;margin-top: 0.86rem;
    }
    .searchInput>input{
        outline: none; border:none;  float:left; margin-left:0.1rem;
        color:#ddd; font-size: 0.21rem; font-weight: 500;line-height: 0.6rem;
        background: none;
    }
    .spot{
        width:0.11rem; height:0.11rem; float:left; margin-left:0.16rem;
        margin-top:0.22rem;background: url("/src/assets/img/sou (15).png");
        background-size: 0.11rem 0.11rem;
    }
    .mai{
        background: url("/src/assets/img/sou (10).png"); width:0.74rem;
        height:0.4rem; float:right; margin-right:0.16rem;margin-top:0.05rem;
        background-size: 0.74rem 0.4rem;
    }
    .part{
        width:100%; height:auto;  margin:0 auto;background: #FAFAFA;
    }
    .line {
        width: 0.06rem;  height: 0.7rem;  border-radius: 0.03rem;
        float: left;  margin-right: 0.08rem;margin-left: 4%;
    }
    .line1{
        background: #1ecc3f;
    }
    .line2{
        background: #2ca3ff;
    }
    .en{
        font-size: 0.2rem; font-weight: 400; float: left; color:#daeae1;margin-top: -0.03rem;
    }
    .cn{
        font-size: 0.2rem; font-weight: 900; float: left; color:#717171;margin-top: -0.05rem;
    }
    .part-head{
        width:100%; height:0.7rem;  margin-bottom: 0.24rem;padding-top: 0.1rem;
    }
    .part-nei{
        width:100%; height:1.87rem; position:relative;
    }
    .part-nei li{
        width:1.47rem; height:0.54rem; border:0.03rem solid #b5dffc;
        border-radius: 0.27rem; color:#179fff; font-size: 0.24rem;
        text-align: center; line-height: 0.54rem;
        float:left;  margin-bottom: 0.12rem;margin-left: 0.4rem;
    }
    .part-nei .hot_2{
        border:none; background: #fff; box-shadow:0 0 0.3rem 0.05rem #ddd;
    }
    .part-nei .detail{
        width:auto; height:1.02rem;position:absolute; left: 1.85rem;
        top:0.24rem; z-index: 1;
    }
    .detail .title_1{
        font-size: 0.27rem; color:#737373; margin-bottom: 0.05rem;
    }
    .detail .title_2{
        font-size: 0.21rem; color:#b8b8b8; margin-right: 0.2rem;
        margin-bottom: 0.05rem;
    }
    .detail .ad{
        float: left; margin-right:0.5rem;
        position: relative;
    }
    .ad .spote{
        width:0.06rem; height:0.06rem; background:#ffc62b ;
        margin-right: 0.06rem; border-radius: 50%;
        float: left;
        position: absolute;
        top: 50%;
        left:0;
    }
    .ad .spote1{
        background:#2dcb56;
    }
    .ad .author{
        font-size: 0.16rem; color:#ddd; float: left;
        margin-left: 0.2rem;
    }
    .ad .date{
        font-size: 0.12rem; color:#ddd; float: left;
        margin-left: 0.2rem;
    }
</style>
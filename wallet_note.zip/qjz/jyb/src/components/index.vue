<template>
<div>
    <transition name="opa">
        <router-view></router-view>
    </transition>
<!--底部-->
    <floor1></floor1>
</div>
</template>
<script>
    import floor1 from "@/components/wzd/floor"

    export default {
        components:{ floor1 },
    }
</script>

<style scoped>

</style>
Vue.component("customs",{
    props:{
        names:String,
    },
    data:function(){
        return {
            mynames:this.names
        }
    },
    template:"<div class='custombtn' @click='change()'>{{this.mynames}}</div>",
    methods:{
        change(){
            this.mynames="abcd"
        }
    }
});
//搜索框的组件
Vue.component("custom-search",{
    props:{
        listData:{
            default:function(){
                return [];
            }
        }
    },
    data(){
      return {
          val:""
      }
    },
    template:`<div class="custom-search">
<input type="text" v-model="val">
<list :listData="listData" @aa="bb"></list>
</div>`,
    methods:{
        bb(val){
            this.val=val;
        }
    }
});
Vue.component("list",{
    props:{
        listData:{
            default:function(){
                return [];
            }
        }
    },
    template:`<ul>
             <li v-for="item in listData" @click="click(item)">{{item}}</li>
        </ul>`,
    methods:{
        click(val){
            //"触发事件"
            this.$emit("aa",val);
        }
    }
});
//二级菜单的组件
Vue.component("custom-menu",{
    props:["menuData"],
    template:`
        <div class="custom-menu">
            <son :menu-data="menuData"></son>
        </div>
`
});
Vue.component("son",{
    props:['menuData'],
    template:`<ul>
<li v-for="item in menuData" @click.stop="show(item)">
{{item.title}}
<son v-if="item.child" v-show="item.flag" :menu-data="item.child"></son>
</li>

</ul>`,
    methods:{
       show(item){
           item.flag=!item.flag;
       }
    }
})
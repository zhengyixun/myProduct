var express = require('express');
var router = express.Router();
var mysql=require("./mysql.js");


router.get('/', function(req, res) {
  res.render('index');
});
// router.get('/fetch', function(req, res, next) {
//     mysql.query("select * from category",function(err,result){
//         res.send(JSON.stringify(result));
//     })
//
// });
//
// router.get('/fetch/:id', function(req, res, next) {
//     mysql.query("select * from list where cid="+req.params.id,function(err,result){
//         res.send(JSON.stringify(result));
//     })
//
// });
module.exports = router;

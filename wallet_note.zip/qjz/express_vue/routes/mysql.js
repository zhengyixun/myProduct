var mysql=require("mysql");
var connects=mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '123456',
    database : 'qjz',
});
connects.connect();
module.exports=connects;
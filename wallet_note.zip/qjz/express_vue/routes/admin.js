var express = require('express');
var router = express.Router();
var mysql = require('./mysql.js');
var md5 = require('./md5.js');
router.get('/', function(req, res, next) {
    res.send('ok');
});
router.post('/checkAdmin', function(req, res, next) {
    mysql.query("select * from admin",function(err,result){
        if(err){
            res.send("err");
        }else{
            res.send(result);
        }
    })
});
router.get('/news',function(req,res){
    var num=10;
    var page=req.query.page;
    var start=num*page;
    mysql.query(`select * from news limit ${start},${num}`,function(err,result){
        if(err){
            res.send("err");
        }else{
            res.send(result);
        }
    })
});

module.exports = router;
var express = require('express');
var router = express.Router();
var mysql = require('./mysql.js');
var md5 = require('./md5.js');
//注册用户
router.post("/reguser",function(req,res){
   var uphone=req.body.uphone;
   var upass1=req.body.upass1;
   var upass2=req.body.upass2;
   var uname="用户"
   if(uphone==""){
       return
   }
    if(upass1==""){
        return
    }
    if(upass2==""){
        return
    }
    if(upass1!=upass2){
        return
    }
    mysql.query(`insert into user (uname,upass,uphone) values ('${uname}','${md5(upass1)}',${uphone})`,function(err,result){
        if(err){
            res.send("err")
        }else{
            res.send("ok")
        }
    })
});
router.post("/loginUser",function(req,res){
    var uphone=req.body.uphone;
    var upass=req.body.upass;
    mysql.query(`select * from user where uphone=${uphone} and upass='${md5(upass)}'`,function(err,result){
        if(err){
            var obj={};
            obj.message=err;
            res.send(obj)
        }else{
            res.send(result);
        }
    })
});

router.post("/goal",function(req,res){
    var uid=req.body.uid;
    mysql.query(`select * from goal where uid=${uid}`,function(err,result){
        if(err){
            res.send("err");
        }else{

            res.send(result);
        }
    });
});

router.post("/updateGoal",function(req,res){
    var uid=req.body.uid;
    var gsheng=req.body.gsheng;
    var gmax=req.body.gmax;
    mysql.query(`update goal set gsheng=${gsheng},gmax=${gmax} where uid=${uid}`,function(err,result){
        if(err){
            res.send("err");
        }else{
            res.send("ok");
        }
    });
});
//查询 账单
router.post("/zhangdan",function(req,res){
    var uid=req.body.uid;
    mysql.query(`select * from zhangdan where uid=${uid}`,function(err,result){
        if(err){
            res.send("err")
        }else{
            res.send(result);
        }
    })
});
//添加账单

router.post("/insZhangDan",function(req,res){
   var uid=req.body.uid;
   var zthing=req.body.zthing;
   var zmoney=req.body.zmoney;
   mysql.query(`insert into zhangdan (zmoney,zthing,zimg,uid) values (${zmoney},'${zthing}',"",${uid})`,function(err,result){
       if(err){
           res.send("err")
       }else{
           res.send("ok");
       }
   })
});
module.exports = router;
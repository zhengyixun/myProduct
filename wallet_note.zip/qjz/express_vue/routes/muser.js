var express = require('express');
var router = express.Router();
var mysql = require('./mysql.js');
var md5 = require('./md5.js');

router.post('/mlogins', function(req, res, next) {
    var number=req.body.number;
    var pass=md5(req.body.pass);
    mysql.query(`select * from worker where number=${number} and pass="${pass}"`,function(err,result){
        var obj={};
        if(err){
            obj.message="err";
            res.send(JSON.stringify(obj));
        }else{
            if(result.length>0){
                obj.message="ok";
                obj.name=result[0].name;
                obj.number=result[0].number;
                obj.id=result[0].id;
                res.send(JSON.stringify(obj));
            }else{
                obj.message="errs";
                // obj.a="'"+result.affectedRows+"'";
                res.send(JSON.stringify(obj));
            }
        }
    });

});
router.post("/worker",function(req,res){
    mysql.query(`select * from worker`,function(err,result){
        if(err){
            var obj={};
            obj.message="err";
            res.send(JSON.stringify(obj))
        }else{
            res.send(result);
        }
    })
});
//发送日志
router.post("/goto",function(req,res){
    var m1=req.body.m1;
    var m2=req.body.m2;
    var con=req.body.con;
    mysql.query(`insert into logs (m1,m2,con) values (${m1},${m2},'${con}')`,function(err,result){
        if(err){
            res.send("err")
        }else{
            res.send("ok");
        }
    })
});
//修改密码
router.post("/resetPass",function(req,res){
    var pass1=req.body.pass1;
    var pass2=req.body.pass2;
    var pass3=req.body.pass3;
    var id=req.body.id;

    if(pass1==""){
        res.send("err")
    }else if(pass2==""){
        res.send("err")
    }else if(pass3==""){
        res.send("err")
    }else if(pass2!=pass3){
        res.send("err")
    }else{
        mysql.query(`update worker set pass='${md5(pass2)}' where id=${id}`,function(err,result){
            if(err){
                res.send("err")
            }else{
                res.send("ok");
            }
        })
    }
});
router.post("/echarts",function(req,res){
    var arrs=[5,3];
    res.send(JSON.stringify(arrs));
});
module.exports = router;
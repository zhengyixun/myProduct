var express = require('express');
var multer = require('multer');
var router = express.Router();
var mysql = require('./mysql.js');
var md5 = require('./md5.js');

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads')
    },
    filename: function (req, file, cb) {
        var str="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
       if( str.indexOf(file.mimetype)){
           cb(null,new Date().getTime()+file.originalname);
       }else{
           return false
       }

    }
});
var uploads = multer({ storage: storage });
router.post('/uploads',uploads.single('files'),function(req,res){
    var xlsx=require("node-xlsx");
    var excalPath=req.file.path;//
    var data=xlsx.parse(excalPath);
    var info=data[0].data;
    info=info.filter(function(a){
        return a.length>0;
    });

    for(var i=1;i<info.length;i++){
        var data=info[i];
        data.push(md5("123456"));
    }
    var arr=info.slice(1);
    // console.log(arr);
    mysql.query("replace into worker (number,name,phone,pass) values ?",[arr],function(err,result){
        if(err){
            res.send("错误");
            res.end();
        } else{
            var arrs=[];
            for(vari=0;i<arr.length;i++){
                var obj={};
                obj.name=arr[i][0];
                obj.number=arr[i][1];
                obj.phone=arr[i][3];
                arrs.push(obj);
            }
            res.send("ok");
        }
    });
});
/*
* 1.上传什么文件 验证
* 2.上传上去的文件如何解析（文件如何书写）
* 3.解析完成后如何存储
* */
/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});
//登录
router.post('/checkLogin', function(req, res, next) {
  var aname=req.body.aname;
  var apass=md5(req.body.apass);
// console.log(uname,upass);
  mysql.query(`select aid,aname from admin where aname='${aname}' and apass='${apass}'`,function(err,result){
    var obj={};
    if(err){
      obj.message="error";
      res.send(JSON.stringify(obj))
    }else{
      if(result.length>0){
          result.message="ok";
          obj.message="ok";
          for(var i in result[0]){
              obj[i]=result[0][i];
          }

          res.send(JSON.stringify(obj));
      }else{
          obj.message="error";
          res.send(JSON.stringify(obj))
      }

    }
  });
});
router.post("/loginOut",function(req,res){
    res.send("ok");
});
//查数据
router.get("/selects",function(req, res, next){
    mysql.query("select * from worker",function(err,result){
        if(err){
            res.send("err");
        }else{
            res.send(result);
        }
    })
});
//添加用户
router.post("/add",function(req,res){
   var number=req.body.number;
   var phones=req.body.phone;
   var name=req.body.name;
   var pass=md5("123456");
   // console.log(number,phones,name,pass);
   mysql.query(`replace into worker (name,pass,number,phone) values (${name},'${pass}',${number},${phones})`,function(err,result){
       if(err){
           res.send("error")
       }else{
           res.send("ok")
       }
   })
});
//编辑用户
router.post("/updates",function(req,res){
    var number=req.body.number;
    var phones=req.body.phone;
    var name=req.body.name;
    var id=req.body.id;
    mysql.query(`update worker set name=${name},number=${number},phone=${phones} where id=${id}`,function(err,result){
        if(err){
            res.send("error")
        }else{
            res.send("ok")
        }
    })
});
//删除用户
router.post("/del",function(req,res){
    var id=req.body.id;
    mysql.query(`delete from worker where id=${id}`,function(err,result){
        if(err){
            res.send("error")
        }else{
            res.send("ok")
        }
    })
});

module.exports = router;
